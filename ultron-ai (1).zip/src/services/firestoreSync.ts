import {
  collection,
  doc,
  setDoc,
  getDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  where,
  getDocs,
  writeBatch,
} from 'firebase/firestore';
import { db } from './firebase';
import { Conversation, ChatMessage, ProductivityTask, AppSettings } from '../types';

export const GUEST_TRIAL_DURATION_MS = 10 * 60 * 1000; // 10 minutes

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  isGuest: boolean;
  guestTrialStartedAt?: number;
  guestTrialExpiresAt?: number;
  createdAt: number;
  updatedAt: number;
}

export function isAllowedGmail(email: string | null): boolean {
  if (!email) return false;
  const lower = email.trim().toLowerCase();
  return lower.endsWith('@gmail.com') || lower.endsWith('@googlemail.com');
}

export async function syncUserProfile(
  uid: string,
  email: string | null,
  displayName: string | null,
  photoURL: string | null,
  isGuest: boolean
): Promise<UserProfile> {
  const userRef = doc(db, 'users', uid);
  const snap = await getDoc(userRef);

  const now = Date.now();
  let profile: UserProfile;

  if (snap.exists()) {
    const existing = snap.data() as UserProfile;
    profile = {
      ...existing,
      email: email || existing.email,
      displayName: displayName || existing.displayName,
      photoURL: photoURL || existing.photoURL,
      isGuest,
      updatedAt: now,
    };
    if (isGuest && !profile.guestTrialStartedAt) {
      profile.guestTrialStartedAt = now;
      profile.guestTrialExpiresAt = now + GUEST_TRIAL_DURATION_MS;
    }
  } else {
    profile = {
      uid,
      email,
      displayName: displayName || (isGuest ? 'Guest Explorer' : 'Ultron Operator'),
      photoURL,
      isGuest,
      createdAt: now,
      updatedAt: now,
    };
    if (isGuest) {
      profile.guestTrialStartedAt = now;
      profile.guestTrialExpiresAt = now + GUEST_TRIAL_DURATION_MS;
    }
  }

  await setDoc(userRef, profile, { merge: true });
  return profile;
}

export async function saveConversationToCloud(userId: string, conversation: Conversation) {
  try {
    const ref = doc(db, 'users', userId, 'conversations', conversation.id);
    await setDoc(
      ref,
      {
        ...conversation,
        userId,
        updatedAt: Date.now(),
      },
      { merge: true }
    );
  } catch (err) {
    console.warn('Failed to save conversation to cloud:', err);
  }
}

export async function deleteConversationFromCloud(userId: string, conversationId: string) {
  try {
    const ref = doc(db, 'users', userId, 'conversations', conversationId);
    await deleteDoc(ref);
  } catch (err) {
    console.warn('Failed to delete conversation from cloud:', err);
  }
}

export async function saveMessageToCloud(userId: string, message: ChatMessage) {
  try {
    const ref = doc(
      db,
      'users',
      userId,
      'conversations',
      message.conversationId,
      'messages',
      message.id
    );
    await setDoc(
      ref,
      {
        ...message,
        userId,
      },
      { merge: true }
    );
  } catch (err) {
    console.warn('Failed to save message to cloud:', err);
  }
}

export async function fetchConversationMessages(userId: string, conversationId: string): Promise<ChatMessage[]> {
  try {
    const msgsRef = collection(db, 'users', userId, 'conversations', conversationId, 'messages');
    const q = query(msgsRef, orderBy('timestamp', 'asc'));
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as ChatMessage);
  } catch (err) {
    console.warn('Failed to fetch messages for conversation:', err);
    return [];
  }
}

export async function saveTaskToCloud(userId: string, task: ProductivityTask) {
  try {
    const ref = doc(db, 'users', userId, 'tasks', task.id);
    await setDoc(
      ref,
      {
        ...task,
        userId,
        updatedAt: Date.now(),
      },
      { merge: true }
    );
  } catch (err) {
    console.warn('Failed to save task to cloud:', err);
  }
}

export async function deleteTaskFromCloud(userId: string, taskId: string) {
  try {
    const ref = doc(db, 'users', userId, 'tasks', taskId);
    await deleteDoc(ref);
  } catch (err) {
    console.warn('Failed to delete task from cloud:', err);
  }
}

export async function saveSettingsToCloud(userId: string, settings: AppSettings) {
  try {
    const ref = doc(db, 'users', userId, 'settings', 'preferences');
    await setDoc(
      ref,
      {
        userId,
        operatingMode: settings.operatingMode,
        geminiModel: settings.geminiModel,
        thinkingMode: settings.thinkingMode,
        personalityTone: settings.personalityTone,
        autoSpeak: settings.autoSpeak,
        speechRate: settings.speechRate,
        speechPitch: settings.speechPitch,
        cloudSyncKey: settings.cloudSyncKey,
        updatedAt: Date.now(),
      },
      { merge: true }
    );
  } catch (err) {
    console.warn('Failed to save settings to cloud:', err);
  }
}

export function subscribeToUserData(
  userId: string,
  callbacks: {
    onConversations: (conversations: Conversation[]) => void;
    onTasks: (tasks: ProductivityTask[]) => void;
    onSettings?: (settings: Partial<AppSettings>) => void;
  }
) {
  const convsRef = collection(db, 'users', userId, 'conversations');
  const convQuery = query(convsRef, orderBy('updatedAt', 'desc'));

  const unsubConvs = onSnapshot(
    convQuery,
    (snapshot) => {
      const list: Conversation[] = [];
      snapshot.forEach((docSnap) => {
        list.push(docSnap.data() as Conversation);
      });
      callbacks.onConversations(list);
    },
    (err) => console.warn('Conversations snapshot listener error:', err)
  );

  const tasksRef = collection(db, 'users', userId, 'tasks');
  const taskQuery = query(tasksRef, orderBy('createdAt', 'desc'));

  const unsubTasks = onSnapshot(
    taskQuery,
    (snapshot) => {
      const list: ProductivityTask[] = [];
      snapshot.forEach((docSnap) => {
        list.push(docSnap.data() as ProductivityTask);
      });
      callbacks.onTasks(list);
    },
    (err) => console.warn('Tasks snapshot listener error:', err)
  );

  const settingsRef = doc(db, 'users', userId, 'settings', 'preferences');
  const unsubSettings = onSnapshot(
    settingsRef,
    (snap) => {
      if (snap.exists()) {
        callbacks.onSettings?.(snap.data() as Partial<AppSettings>);
      }
    },
    (err) => console.warn('Settings snapshot listener error:', err)
  );

  return () => {
    unsubConvs();
    unsubTasks();
    unsubSettings();
  };
}

// Migrate guest items to registered Gmail account
export async function migrateGuestDataToUser(
  guestUid: string,
  targetUid: string,
  localConversations: Conversation[],
  localMessages: ChatMessage[],
  localTasks: ProductivityTask[]
) {
  try {
    for (const c of localConversations) {
      await saveConversationToCloud(targetUid, c);
    }
    for (const m of localMessages) {
      await saveMessageToCloud(targetUid, m);
    }
    for (const t of localTasks) {
      await saveTaskToCloud(targetUid, t);
    }
  } catch (err) {
    console.warn('Migration of guest data failed:', err);
  }
}
