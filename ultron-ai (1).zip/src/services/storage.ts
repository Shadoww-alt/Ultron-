import { Conversation, ChatMessage, ProductivityTask, AppSettings } from '../types';

const STORAGE_KEYS = {
  CONVERSATIONS: 'ultron_conversations',
  MESSAGES: 'ultron_messages',
  TASKS: 'ultron_tasks',
  SETTINGS: 'ultron_settings',
  SYNC_KEY: 'ultron_cloud_sync_key',
  DEVICE_ID: 'ultron_device_id',
};

export const DEFAULT_SETTINGS: AppSettings = {
  operatingMode: 'ONLINE',
  geminiModel: 'gemini-3.1-flash-lite',
  thinkingMode: false,
  ollamaUrl: 'http://localhost:11434',
  ollamaModel: 'llama3',
  personalityTone: 'CASUAL_WIT',
  autoSpeak: true,
  speechRate: 1.0,
  speechPitch: 0.95,
  selectedVoice: '',
  elevenLabsApiKey: 'sk_afbf5bfbb325bbcff327527ee3c21309f3d328c67019c607',
  elevenLabsVoiceId: '6Up7VdyJXU6KJm2SQKKx',
  cloudSyncKey: '',
  autoCloudSync: true,
  lastSyncedAt: null,
  orbGlowIntensity: 0.85,
  hapticFeedback: true,
  reducedBlur: false,
  agentPermissions: {
    microphoneAccess: true,
    cameraAccess: true,
    webSearchAccess: true,
    taskAutomation: true,
    backgroundSync: true,
  },
};

export function getOrCreateDeviceId(): string {
  if (typeof window === 'undefined') return 'server';
  let id = localStorage.getItem(STORAGE_KEYS.DEVICE_ID);
  if (!id) {
    id = 'dev_' + Math.random().toString(36).substring(2, 10) + '_' + Date.now().toString(36);
    localStorage.setItem(STORAGE_KEYS.DEVICE_ID, id);
  }
  return id;
}

export function generateSyncKey(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const part1 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  const part2 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `ULTRON-${part1}-${part2}`;
}

export function loadSettings(): AppSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) {
      const generated = generateSyncKey();
      const initial = { ...DEFAULT_SETTINGS, cloudSyncKey: generated };
      saveSettings(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);
    if (!parsed.cloudSyncKey) {
      parsed.cloudSyncKey = generateSyncKey();
      saveSettings(parsed);
    }
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch (e) {
    console.error('Failed to load settings from storage', e);
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings', e);
  }
}

export function loadConversations(): Conversation[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load conversations', e);
    return [];
  }
}

export function saveConversations(conversations: Conversation[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(conversations));
  } catch (e) {
    console.error('Failed to save conversations', e);
  }
}

export function loadMessages(): ChatMessage[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    if (!raw) return [];
    const parsed: ChatMessage[] = JSON.parse(raw);
    return parsed.map((m) => {
      if (m.id === 'msg_welcome' || /powered by\s+gemini/i.test(m.content || '')) {
        return {
          ...m,
          content:
            m.id === 'msg_welcome'
              ? "Hey. I'm Ultron — ready with real-time cross-device sync. What are we tackling today?"
              : m.content.replace(/powered by\s+gemini[^.,—]*/gi, 'Ultron Neural Core'),
          modelUsed: m.modelUsed?.replace(/gemini/gi, 'ultron') || 'ultron-3.1-lite',
        };
      }
      return m;
    });
  } catch (e) {
    console.error('Failed to load messages', e);
    return [];
  }
}

export function saveMessages(messages: ChatMessage[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
  } catch (e) {
    console.error('Failed to save messages', e);
  }
}

export function loadTasks(): ProductivityTask[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TASKS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load tasks', e);
    return [];
  }
}

export function saveTasks(tasks: ProductivityTask[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  } catch (e) {
    console.error('Failed to save tasks', e);
  }
}
