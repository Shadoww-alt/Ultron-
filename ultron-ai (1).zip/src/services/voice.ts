export class VoiceService {
  private recognition: any = null;
  private isListening: boolean = false;
  private isSpeaking: boolean = false;
  private continuousMode: boolean = false;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private microphoneStream: MediaStream | null = null;
  private animFrameId: number | null = null;
  private currentAmplitude: number = 0;
  private onAmplitudeChange: ((amp: number) => void) | null = null;
  private speechSimulatorTimer: ReturnType<typeof setInterval> | null = null;

  // Active callbacks
  private onResultCallback: ((finalText: string) => void) | null = null;
  private onPartialCallback: ((partialText: string) => void) | null = null;
  private onErrorCallback: ((err: string) => void) | null = null;

  // Silence detection timer to allow natural pauses
  private silenceTimer: ReturnType<typeof setTimeout> | null = null;
  private accumulatedTranscript: string = '';
  private restartTimeout: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    this.initRecognition();
  }

  private initRecognition() {
    if (typeof window === 'undefined') return;
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) return;

    try {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 1;
      this.recognition.lang = 'en-US';

      this.recognition.onstart = () => {
        this.isListening = true;
      };

      this.recognition.onresult = (event: any) => {
        let interim = '';
        let finalSegment = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const trans = event.results[i][0]?.transcript || '';
          if (event.results[i].isFinal) {
            finalSegment += ' ' + trans;
          } else {
            interim += ' ' + trans;
          }
        }

        if (finalSegment.trim()) {
          this.accumulatedTranscript = (this.accumulatedTranscript + ' ' + finalSegment).trim();
        }

        const currentText = (this.accumulatedTranscript + ' ' + interim).trim();

        if (currentText && this.onPartialCallback) {
          this.onPartialCallback(currentText);
        }

        // Reset silence timer on every spoken token
        if (this.silenceTimer) {
          clearTimeout(this.silenceTimer);
        }

        // Wait 1.4 seconds of silence before committing user's utterance
        this.silenceTimer = setTimeout(() => {
          const finalResult = (this.accumulatedTranscript + ' ' + interim).trim();
          if (finalResult.length > 0) {
            this.accumulatedTranscript = '';
            if (this.onResultCallback) {
              this.onResultCallback(finalResult);
            }
          }
        }, 1400);
      };

      this.recognition.onerror = (event: any) => {
        const errType = event.error;
        console.warn('Speech recognition event error:', errType);

        if (errType === 'no-speech') {
          // Normal silence, keep listening
          return;
        }

        if (errType === 'aborted') {
          return;
        }

        if (errType === 'network' || errType === 'audio-capture') {
          this.scheduleRestart(600);
          return;
        }

        if (errType === 'not-allowed') {
          this.isListening = false;
          this.onErrorCallback?.('Microphone permission blocked. Please allow mic in browser settings.');
        }
      };

      this.recognition.onend = () => {
        // If we should still be listening (e.g. continuous or active session), restart seamlessly
        if (this.isListening && !this.isSpeaking) {
          this.scheduleRestart(300);
        } else {
          this.isListening = false;
          this.stopMicrophoneAnalysis();
        }
      };
    } catch (e) {
      console.warn('SpeechRecognition setup error:', e);
    }
  }

  private scheduleRestart(delayMs: number = 300) {
    if (this.restartTimeout) clearTimeout(this.restartTimeout);
    this.restartTimeout = setTimeout(() => {
      if (this.isListening && !this.isSpeaking && this.recognition) {
        try {
          this.recognition.start();
        } catch (_) {}
      }
    }, delayMs);
  }

  public isVoiceRecognitionSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }

  public setAmplitudeListener(listener: (amp: number) => void) {
    this.onAmplitudeChange = listener;
  }

  public setContinuousMode(continuous: boolean) {
    this.continuousMode = continuous;
  }

  public async startListening(
    onResult: (finalText: string) => void,
    onPartial?: (partialText: string) => void,
    onError?: (err: string) => void
  ): Promise<boolean> {
    this.stopSpeaking();

    if (!this.recognition) {
      this.initRecognition();
      if (!this.recognition) {
        onError?.('Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.');
        return false;
      }
    }

    this.onResultCallback = onResult;
    this.onPartialCallback = onPartial || null;
    this.onErrorCallback = onError || null;
    this.accumulatedTranscript = '';
    this.isListening = true;

    // Start background audio analysis for visualizer waveform
    this.startMicrophoneAnalysis().catch(() => {});

    try {
      this.recognition.start();
      return true;
    } catch (err: any) {
      // If already started, it's fine
      if (err?.message?.includes('already started') || err?.name === 'InvalidStateError') {
        return true;
      }
      console.warn('SpeechRecognition start error:', err);
      this.isListening = false;
      onError?.(err?.message || 'Failed to start microphone');
      return false;
    }
  }

  public stopListening() {
    this.isListening = false;
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
    if (this.restartTimeout) {
      clearTimeout(this.restartTimeout);
      this.restartTimeout = null;
    }
    if (this.recognition) {
      try {
        this.recognition.abort();
      } catch (_) {}
    }
    this.stopMicrophoneAnalysis();
    this.currentAmplitude = 0;
    this.onAmplitudeChange?.(0);
  }

  // Commit whatever is currently spoken immediately
  public commitCurrentSpeech() {
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
    const text = this.accumulatedTranscript.trim();
    if (text && this.onResultCallback) {
      this.accumulatedTranscript = '';
      this.onResultCallback(text);
    }
  }

  private async startMicrophoneAnalysis() {
    if (typeof window === 'undefined') return;
    if (!navigator.mediaDevices?.getUserMedia) return;
    if (this.microphoneStream) return; // already active

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      this.microphoneStream = stream;

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.audioContext = new AudioCtx();
      const source = this.audioContext.createMediaStreamSource(stream);
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 64;
      source.connect(this.analyser);

      const bufferLength = this.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const checkVolume = () => {
        if (!this.analyser || !this.isListening) {
          this.onAmplitudeChange?.(0);
          return;
        }
        this.analyser.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;
        const normalized = Math.min(1, Math.max(0, avg / 110));
        this.currentAmplitude = normalized;
        this.onAmplitudeChange?.(normalized);

        this.animFrameId = requestAnimationFrame(checkVolume);
      };

      checkVolume();
    } catch (err) {
      // Audio stream analysis is optional, do not kill recognition
    }
  }

  private stopMicrophoneAnalysis() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.microphoneStream) {
      this.microphoneStream.getTracks().forEach((track) => track.stop());
      this.microphoneStream = null;
    }
    if (this.audioContext && this.audioContext.state !== 'closed') {
      try {
        this.audioContext.close();
      } catch (_) {}
      this.audioContext = null;
    }
    this.analyser = null;
  }

  public async speak(
    text: string,
    options?: {
      elevenLabsApiKey?: string;
      elevenLabsVoiceId?: string;
      onEnd?: () => void;
    }
  ) {
    this.stopSpeaking();

    const clean = text
      .replace(/```[\s\S]*?```/g, 'Code snippet omitted.')
      .replace(/[*#`_~>]/g, '')
      .replace(/\[(.*?)\]\(.*?\)/g, '$1')
      .trim();

    if (!clean) {
      options?.onEnd?.();
      return;
    }

    if (this.recognition && this.isListening) {
      try {
        this.recognition.abort();
      } catch (_) {}
    }

    const apiKey = options?.elevenLabsApiKey || 'sk_afbf5bfbb325bbcff327527ee3c21309f3d328c67019c607';
    const voiceId = options?.elevenLabsVoiceId || '6Up7VdyJXU6KJm2SQKKx';

    try {
      this.isSpeaking = true;
      this.startSpeakingSimulation();

      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: clean,
          apiKey,
          voiceId,
        }),
      });

      if (!res.ok) {
        throw new Error('ElevenLabs TTS request failed');
      }

      const audioBlob = await res.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      const audioElement = new Audio(audioUrl);

      audioElement.onended = () => {
        this.isSpeaking = false;
        this.stopSpeakingSimulation();
        this.currentAmplitude = 0;
        this.onAmplitudeChange?.(0);
        options?.onEnd?.();
      };

      audioElement.onerror = () => {
        this.isSpeaking = false;
        this.stopSpeakingSimulation();
        this.currentAmplitude = 0;
        this.onAmplitudeChange?.(0);
        options?.onEnd?.();
      };

      await audioElement.play();
    } catch (err) {
      console.error('ElevenLabs TTS error:', err);
      this.isSpeaking = false;
      this.stopSpeakingSimulation();
      this.currentAmplitude = 0;
      this.onAmplitudeChange?.(0);
      options?.onEnd?.();
    }
  }

  public stopSpeaking() {
    this.isSpeaking = false;
    this.stopSpeakingSimulation();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (_) {}
    }
  }

  private startSpeakingSimulation() {
    this.stopSpeakingSimulation();
    this.speechSimulatorTimer = setInterval(() => {
      if (!this.isSpeaking) {
        this.stopSpeakingSimulation();
        return;
      }
      const fakeAmp = 0.25 + Math.random() * 0.65;
      this.currentAmplitude = fakeAmp;
      this.onAmplitudeChange?.(fakeAmp);
    }, 80);
  }

  private stopSpeakingSimulation() {
    if (this.speechSimulatorTimer) {
      clearInterval(this.speechSimulatorTimer);
      this.speechSimulatorTimer = null;
    }
  }

  public getAvailableVoices(): SpeechSynthesisVoice[] {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return [];
    return window.speechSynthesis.getVoices();
  }
}
