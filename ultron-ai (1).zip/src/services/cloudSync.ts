import { Conversation, ChatMessage, ProductivityTask, AppSettings, SyncPayload } from '../types';
import { getDeviceType, getDevicePlatformName } from '../utils/device';
import { getOrCreateDeviceId } from './storage';

export type SyncState = 'idle' | 'syncing' | 'synced' | 'error' | 'offline';

export class CloudSyncService {
  private syncKey: string = '';
  private state: SyncState = 'idle';
  private lastSynced: number | null = null;
  private listeners: Set<(state: SyncState, lastSynced: number | null) => void> = new Set();
  private debounceTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(initialSyncKey: string) {
    this.syncKey = initialSyncKey;
  }

  public setSyncKey(key: string) {
    this.syncKey = key.trim().toUpperCase();
  }

  public getSyncKey(): string {
    return this.syncKey;
  }

  public subscribe(callback: (state: SyncState, lastSynced: number | null) => void) {
    this.listeners.add(callback);
    callback(this.state, this.lastSynced);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify() {
    this.listeners.forEach((cb) => cb(this.state, this.lastSynced));
  }

  public async push(
    conversations: Conversation[],
    messages: ChatMessage[],
    tasks: ProductivityTask[],
    settings: AppSettings
  ): Promise<boolean> {
    if (!this.syncKey) return false;
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      this.state = 'offline';
      this.notify();
      return false;
    }

    this.state = 'syncing';
    this.notify();

    const payload: SyncPayload = {
      syncKey: this.syncKey,
      deviceId: getOrCreateDeviceId(),
      deviceName: `${getDevicePlatformName()} (${getDeviceType()})`,
      deviceType: getDeviceType(),
      conversations,
      messages,
      tasks,
      settings: {
        operatingMode: settings.operatingMode,
        geminiModel: settings.geminiModel,
        thinkingMode: settings.thinkingMode,
        personalityTone: settings.personalityTone,
        autoSpeak: settings.autoSpeak,
        speechRate: settings.speechRate,
        speechPitch: settings.speechPitch,
      },
      timestamp: Date.now(),
    };

    try {
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`Sync push error: ${res.statusText}`);
      }

      this.lastSynced = Date.now();
      this.state = 'synced';
      this.notify();
      return true;
    } catch (err) {
      console.warn('Cloud sync push failed:', err);
      this.state = 'error';
      this.notify();
      return false;
    }
  }

  public async pull(targetSyncKey?: string): Promise<{
    success: boolean;
    data?: {
      conversations: Conversation[];
      messages: ChatMessage[];
      tasks: ProductivityTask[];
      settings: Partial<AppSettings>;
      timestamp: number;
      deviceName?: string;
    };
    error?: string;
  }> {
    const keyToUse = (targetSyncKey || this.syncKey).trim().toUpperCase();
    if (!keyToUse) {
      return { success: false, error: 'No Sync Key provided' };
    }

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      this.state = 'offline';
      this.notify();
      return { success: false, error: 'Device is offline' };
    }

    this.state = 'syncing';
    this.notify();

    try {
      const res = await fetch(`/api/sync/pull?syncKey=${encodeURIComponent(keyToUse)}`);
      if (!res.ok) {
        if (res.status === 404) {
          this.state = 'synced';
          this.notify();
          return { success: false, error: 'No cloud record found for this Sync Key yet. It will be initialized on first push.' };
        }
        throw new Error(`Sync pull error: ${res.statusText}`);
      }

      const json = await res.json();
      this.lastSynced = Date.now();
      this.state = 'synced';
      this.notify();

      return {
        success: true,
        data: json.data,
      };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown sync error';
      console.warn('Cloud sync pull failed:', message);
      this.state = 'error';
      this.notify();
      return { success: false, error: message };
    }
  }

  public scheduleAutoSync(
    conversations: Conversation[],
    messages: ChatMessage[],
    tasks: ProductivityTask[],
    settings: AppSettings,
    delayMs: number = 1800
  ) {
    if (!settings.autoCloudSync) return;
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }
    this.debounceTimer = setTimeout(() => {
      this.push(conversations, messages, tasks, settings);
    }, delayMs);
  }
}
