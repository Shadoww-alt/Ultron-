import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  modalBackdropVariants,
  modalSheetVariants,
  IOS_SPRING_SNAPPY,
} from '../utils/motionSystem';
import {
  Camera,
  Settings,
  Clock,
  Youtube,
  Search,
  FileText,
  X,
  ExternalLink,
  Smartphone,
  Laptop,
  CheckCircle2,
} from 'lucide-react';
import { getDevicePlatformName, getDeviceType } from '../utils/device';

interface DeviceAppsModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeAppId?: string | null;
  onTriggerCommand?: (cmd: string) => void;
}

export const DeviceAppsModal: React.FC<DeviceAppsModalProps> = ({
  isOpen,
  onClose,
  activeAppId = null,
  onTriggerCommand,
}) => {
  const [selectedApp, setSelectedApp] = useState<string>(activeAppId || 'camera');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const platform = getDevicePlatformName();
  const deviceType = getDeviceType();

  useEffect(() => {
    if (activeAppId) {
      setSelectedApp(activeAppId);
    }
  }, [activeAppId]);

  useEffect(() => {
    if (!isOpen && streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      setCameraActive(false);
    }
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
    } catch (e: any) {
      setCameraError('Webcam / Camera access could not be acquired or was denied.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const apps = [
    { id: 'camera', label: 'Camera', icon: Camera, desc: 'Hardware camera feed & capture' },
    { id: 'youtube', label: 'YouTube', icon: Youtube, desc: 'Launch media & streams' },
    { id: 'clock', label: 'Clock & Alarms', icon: Clock, desc: 'Device timers & schedule' },
    { id: 'search', label: 'Web Search', icon: Search, desc: 'Query search index' },
    { id: 'notes', label: 'Notes & Memos', icon: FileText, desc: 'Quick scratchpad sync' },
    { id: 'settings', label: 'Settings', icon: Settings, desc: 'System configuration' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          variants={modalBackdropVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
          onClick={() => {
            stopCamera();
            onClose();
          }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6"
        >
          <motion.div
            variants={modalSheetVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-2xl max-h-[90vh] ios-glass-elevated rounded-3xl flex flex-col overflow-hidden text-white"
          >
            {/* Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center border border-white/15">
                  <Smartphone className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-bold tracking-wide">Device Apps & Hardware</h3>
                  <p className="text-[11px] text-neutral-400">
                    Connected to {platform} ({deviceType})
                  </p>
                </div>
              </div>
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={() => {
                  stopCamera();
                  onClose();
                }}
                className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 transition"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </motion.button>
            </div>

            {/* Content Body */}
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
              {/* App Selector Tabs */}
              <div className="w-full md:w-56 p-2 border-b md:border-b-0 md:border-r border-white/10 bg-black/40 overflow-x-auto md:overflow-y-auto flex md:flex-col gap-1 shrink-0 no-scrollbar">
                {apps.map((app) => {
                  const Icon = app.icon;
                  const isSelected = selectedApp === app.id;
                  return (
                    <button
                      key={app.id}
                      onClick={() => {
                        if (selectedApp === 'camera' && app.id !== 'camera') {
                          stopCamera();
                        }
                        setSelectedApp(app.id);
                      }}
                      className={`relative flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-colors text-left shrink-0 md:shrink ${
                        isSelected
                          ? 'text-white'
                          : 'text-neutral-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      {isSelected && (
                        <motion.span
                          layoutId="deviceAppsTabPill"
                          transition={IOS_SPRING_SNAPPY}
                          className="absolute inset-0 rounded-xl bg-white/15 border border-white/20"
                        />
                      )}
                      <Icon className="w-4 h-4 shrink-0 relative z-10" />
                      <div className="truncate relative z-10">
                        <p className="font-semibold">{app.label}</p>
                        <p className="text-[10px] text-neutral-400 hidden md:block">{app.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>

          {/* Active App Screen */}
          <div className="flex-1 p-5 overflow-y-auto">
            {selectedApp === 'camera' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold">Live Camera Stream</h4>
                  {cameraActive ? (
                    <button
                      onClick={stopCamera}
                      className="px-3 py-1 rounded-lg bg-white/15 hover:bg-white/25 border border-white/25 text-xs font-medium text-white transition"
                    >
                      Stop Camera
                    </button>
                  ) : (
                    <button
                      onClick={startCamera}
                      className="px-3 py-1 rounded-lg bg-white text-black hover:bg-neutral-200 text-xs font-medium transition"
                    >
                      Enable Hardware Camera
                    </button>
                  )}
                </div>

                <div className="relative aspect-video rounded-xl bg-black border border-white/20 overflow-hidden flex items-center justify-center">
                  <video
                    ref={videoRef}
                    playsInline
                    muted
                    className={`w-full h-full object-cover ${cameraActive ? 'block' : 'hidden'}`}
                  />
                  {!cameraActive && (
                    <div className="text-center p-6 text-neutral-400 space-y-2">
                      <Camera className="w-10 h-10 mx-auto text-neutral-500" />
                      <p className="text-xs font-medium">Camera Sensor Standby</p>
                      <p className="text-[11px] text-neutral-500 max-w-xs">
                        Say "Open Camera" to Ultron or tap above to test live video capture.
                      </p>
                    </div>
                  )}
                  {cameraError && (
                    <div className="absolute inset-0 bg-black/90 p-4 flex items-center justify-center text-neutral-200 text-xs text-center">
                      {cameraError}
                    </div>
                  )}
                </div>
              </div>
            )}

            {selectedApp === 'youtube' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold">YouTube Launcher</h4>
                  <a
                    href="https://www.youtube.com"
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-xs text-neutral-300 hover:text-white underline"
                  >
                    Open YouTube <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Ultron can directly query and play videos on YouTube. Try asking:
                </p>
                <div className="grid gap-2">
                  {[
                    'Open YouTube and play lo-fi coding beats',
                    'Search YouTube for SpaceX rocket launch',
                    'Open YouTube for React 19 tutorial',
                  ].map((cmd) => (
                    <button
                      key={cmd}
                      onClick={() => {
                        stopCamera();
                        onClose();
                        onTriggerCommand?.(cmd);
                      }}
                      className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-xs font-mono transition text-neutral-300 hover:text-white"
                    >
                      "{cmd}"
                    </button>
                  ))}
                </div>
              </div>
            )}

            {selectedApp === 'clock' && (
              <div className="space-y-4 text-center py-6">
                <Clock className="w-12 h-12 mx-auto text-white" />
                <div>
                  <h4 className="text-2xl font-mono font-bold tracking-widest">
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </h4>
                  <p className="text-xs text-neutral-400 mt-1 font-mono">
                    {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
                  </p>
                </div>
                <div className="p-3 bg-white/5 border border-white/10 rounded-xl text-left text-xs text-neutral-300">
                  <p className="font-semibold text-white mb-1">Voice Commands Available:</p>
                  <p>• "Set a timer for 15 minutes"</p>
                  <p>• "What time is it in Tokyo?"</p>
                </div>
              </div>
            )}

            {selectedApp === 'search' && (
              <div className="space-y-4">
                <h4 className="text-sm font-semibold">Web Search Engine</h4>
                <p className="text-xs text-neutral-400">
                  Execute web search intents straight through your browser session.
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    id="search-input-field"
                    placeholder="Search query..."
                    className="flex-1 py-2 px-3 bg-neutral-900 rounded-xl border border-white/20 text-xs text-white focus:outline-none focus:border-white"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        const val = (e.target as HTMLInputElement).value;
                        if (val) window.open(`https://www.google.com/search?q=${encodeURIComponent(val)}`, '_blank');
                      }
                    }}
                  />
                  <button
                    onClick={() => {
                      const input = document.getElementById('search-input-field') as HTMLInputElement;
                      if (input && input.value) {
                        window.open(`https://www.google.com/search?q=${encodeURIComponent(input.value)}`, '_blank');
                      }
                    }}
                    className="px-4 py-2 bg-white text-black font-semibold rounded-xl text-xs hover:bg-neutral-200 transition"
                  >
                    Search
                  </button>
                </div>
              </div>
            )}

            {selectedApp === 'notes' && (
              <div className="space-y-3">
                <h4 className="text-sm font-semibold">Quick Scratchpad (Auto-Synced)</h4>
                <textarea
                  placeholder="Type temporary notes or drafts here..."
                  rows={6}
                  className="w-full p-3 bg-neutral-900 rounded-xl border border-white/20 text-xs text-white focus:outline-none focus:border-white resize-none"
                  defaultValue="Ultron is configured and synced across your mobile, tablet, and PC devices."
                />
                <p className="text-[11px] text-neutral-500">
                  All notes persist locally and sync across devices through your Cloud Sync Key.
                </p>
              </div>
            )}

            {selectedApp === 'settings' && (
              <div className="space-y-3">
                <h4 className="text-sm font-semibold">System Hardware Diagnostics</h4>
                <div className="space-y-2 text-xs font-mono">
                  <div className="p-2.5 rounded-lg bg-white/5 border border-white/10 flex justify-between">
                    <span className="text-neutral-400">Device Platform:</span>
                    <span className="text-white">{platform}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-white/5 border border-white/10 flex justify-between">
                    <span className="text-neutral-400">Form Factor:</span>
                    <span className="text-white capitalize">{deviceType}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-white/5 border border-white/10 flex justify-between">
                    <span className="text-neutral-400">Display Density:</span>
                    <span className="text-white">{typeof window !== 'undefined' ? `${window.devicePixelRatio}x Retina` : '1x'}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-white/5 border border-white/10 flex justify-between">
                    <span className="text-neutral-400">Orientation:</span>
                    <span className="text-white">{typeof window !== 'undefined' && window.innerWidth > window.innerHeight ? 'Landscape' : 'Portrait'}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
