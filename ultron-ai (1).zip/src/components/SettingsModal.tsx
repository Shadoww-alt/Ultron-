import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  modalBackdropVariants,
  modalSheetVariants,
  IOS_SPRING_SNAPPY,
} from '../utils/motionSystem';
import {
  Settings,
  Palette,
  Bot,
  Mic,
  Volume2,
  Keyboard,
  Shield,
  Database,
  Info,
  X,
  Cloud,
  RefreshCw,
  Copy,
  Check,
  Smartphone,
  Laptop,
  Monitor,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { AppSettings, OperatingMode, PersonalityTone } from '../types';
import { SyncState } from '../services/cloudSync';
import { UserProfile } from '../services/firestoreSync';
import { getDevicePlatformName, getDeviceType } from '../utils/device';
import { APP_URLS } from '../utils/appUrl';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  cloudSyncState: SyncState;
  lastSyncedAt: number | null;
  onTriggerSync: () => Promise<boolean>;
  onPullFromSyncKey: (key: string) => Promise<{ success: boolean; error?: string }>;
  onClearHistory: () => void;
  onClearTasks: () => void;
  availableVoices: SpeechSynthesisVoice[];
  initialSection?: string;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  appUrl: string;
  guestTimeRemainingMs: number;
  isTrialExpired: boolean;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  cloudSyncState,
  lastSyncedAt,
  onTriggerSync,
  onPullFromSyncKey,
  onClearHistory,
  onClearTasks,
  availableVoices,
  initialSection = 'general',
  currentUser,
  onOpenAuth,
  appUrl,
  guestTimeRemainingMs,
  isTrialExpired,
}) => {
  const [activeSection, setActiveSection] = useState<string>(initialSection);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedAppUrl, setCopiedAppUrl] = useState(false);
  const [inputSyncKey, setInputSyncKey] = useState('');
  const [syncStatusMsg, setSyncStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isPulling, setIsPulling] = useState(false);

  const platform = getDevicePlatformName();
  const deviceType = getDeviceType();

  useEffect(() => {
    if (isOpen && initialSection) {
      setActiveSection(initialSection);
    }
  }, [isOpen, initialSection]);

  const sections = [
    { id: 'general', label: 'General', icon: Settings },
    { id: 'sync', label: 'Cloud Sync', icon: Cloud },
    { id: 'ai_model', label: 'AI Model', icon: Bot },
    { id: 'voice', label: 'Voice & TTS', icon: Volume2 },
    { id: 'microphone', label: 'Microphone', icon: Mic },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'shortcuts', label: 'Shortcuts', icon: Keyboard },
    { id: 'privacy', label: 'Privacy', icon: Shield },
    { id: 'data', label: 'Data & Backup', icon: Database },
    { id: 'about', label: 'About', icon: Info },
  ];

  const handleCopySyncKey = () => {
    navigator.clipboard.writeText(settings.cloudSyncKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleConnectSyncKey = async () => {
    if (!inputSyncKey.trim()) return;
    setIsPulling(true);
    setSyncStatusMsg(null);
    const res = await onPullFromSyncKey(inputSyncKey.trim());
    setIsPulling(false);
    if (res.success) {
      setSyncStatusMsg({
        type: 'success',
        text: 'Successfully paired and synchronized all data from cloud!',
      });
      setInputSyncKey('');
    } else {
      setSyncStatusMsg({
        type: 'error',
        text: res.error || 'Failed to pull cloud sync data',
      });
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          variants={modalBackdropVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
          onClick={onClose}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6"
        >
          <motion.div
            variants={modalSheetVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-3xl max-h-[92vh] ios-glass-elevated rounded-3xl flex flex-col overflow-hidden text-white"
          >
            {/* Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold tracking-wide">Settings & Preferences</h3>
                <p className="text-xs text-neutral-400">System Configuration & Cloud Sync Engine</p>
              </div>
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={onClose}
                className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 transition"
                aria-label="Close settings"
              >
                <X className="w-4 h-4" />
              </motion.button>
            </div>

            {/* Content with Tabs */}
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
              {/* Section Nav Bar */}
              <div className="w-full md:w-56 p-2 border-b md:border-b-0 md:border-r border-white/10 bg-black/40 overflow-x-auto md:overflow-y-auto flex md:flex-col gap-1 shrink-0 no-scrollbar">
                {sections.map((sec) => {
                  const Icon = sec.icon;
                  const isSelected = activeSection === sec.id;
                  return (
                    <button
                      key={sec.id}
                      onClick={() => setActiveSection(sec.id)}
                      className={`relative flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-colors text-left shrink-0 md:shrink ${
                        isSelected
                          ? 'text-white font-semibold'
                          : 'text-neutral-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      {isSelected && (
                        <motion.span
                          layoutId="settingsTabPill"
                          transition={IOS_SPRING_SNAPPY}
                          className="absolute inset-0 rounded-xl bg-white/15 border border-white/20"
                        />
                      )}
                      <Icon className="w-4 h-4 shrink-0 relative z-10" />
                      <span className="relative z-10 whitespace-nowrap">{sec.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Tab Content Body */}
              <div className="flex-1 p-5 overflow-y-auto space-y-6">
            {/* GENERAL */}
            {activeSection === 'general' && (
              <div className="space-y-5">
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">Operating Mode</h4>
                  <p className="text-xs text-neutral-400 mb-3">
                    Choose how Ultron executes neural queries.
                  </p>
                  <div className="grid gap-2">
                    {[
                      {
                        mode: 'ONLINE' as OperatingMode,
                        title: 'Online Mode (Cloud Neural Core)',
                        desc: 'Full cloud intellect with Ultron 3.1 Lite, 3.8 Flash & Pro.',
                      },
                      {
                        mode: 'OFFLINE' as OperatingMode,
                        title: 'Offline Matrix (Local Ollama)',
                        desc: 'Zero network transfer. Private local execution on your machine.',
                      },
                      {
                        mode: 'AUTO' as OperatingMode,
                        title: 'Auto Intelligent Switching',
                        desc: 'Uses Cloud Neural Core online; smoothly fails over to offline if disconnected.',
                      },
                    ].map((opt) => (
                      <div
                        key={opt.mode}
                        onClick={() => onUpdateSettings({ operatingMode: opt.mode })}
                        className={`p-3 rounded-xl border cursor-pointer transition text-left ${
                          settings.operatingMode === opt.mode
                            ? 'bg-white/15 border-white text-white'
                            : 'bg-white/5 border-white/10 hover:border-white/20 text-neutral-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-semibold">{opt.title}</p>
                          {settings.operatingMode === opt.mode && (
                            <CheckCircle2 className="w-4 h-4 text-white" />
                          )}
                        </div>
                        <p className="text-[11px] text-neutral-400 mt-0.5">{opt.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white mb-1">Personality Demeanor</h4>
                  <p className="text-xs text-neutral-400 mb-3">
                    Ultron talks like a normal, highly intelligent human: calm, witty, and concise.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      { tone: 'CASUAL_WIT' as PersonalityTone, label: 'Smart & Witty (Natural Banter)' },
                      { tone: 'BALANCED_SMART' as PersonalityTone, label: 'Balanced & Concise (Solution-First)' },
                      { tone: 'DEEP_MENTOR' as PersonalityTone, label: 'Intuitive Mentor (Clear Concepts)' },
                      { tone: 'SERIOUS_WORK' as PersonalityTone, label: 'Serious Work (Laser Execution)' },
                    ].map((item) => (
                      <button
                        key={item.tone}
                        onClick={() => onUpdateSettings({ personalityTone: item.tone })}
                        className={`p-3 rounded-xl border text-left text-xs transition ${
                          settings.personalityTone === item.tone
                            ? 'bg-white/15 border-white text-white font-semibold'
                            : 'bg-white/5 border-white/10 hover:border-white/20 text-neutral-400'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* CLOUD SYNC */}
            {activeSection === 'sync' && (
              <div className="space-y-5">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Cloud className="w-4 h-4 text-emerald-400" />
                    Cloud Data Synchronization & Platform Access
                  </h4>
                  <p className="text-xs text-neutral-400 mt-1">
                    Keep your conversations, tasks, notes, and settings synchronized in the cloud across all your devices
                    (iPhone, iPad, Android phone, MacBook, Windows PC, or Work laptop).
                  </p>
                </div>

                {/* Application Access URL */}
                <div className="p-4 rounded-xl bg-neutral-900 border border-white/20 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-white flex items-center gap-1.5">
                      <ExternalLink className="w-3.5 h-3.5 text-white" />
                      Application URL (Open on Mobile, Tablet, Laptop, or PC)
                    </p>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(appUrl);
                        setCopiedAppUrl(true);
                        setTimeout(() => setCopiedAppUrl(false), 2000);
                      }}
                      className="px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 text-white text-[11px] font-mono flex items-center gap-1 transition"
                    >
                      {copiedAppUrl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedAppUrl ? 'Copied' : 'Copy Link'}</span>
                    </button>
                  </div>

                  <div className="p-2.5 bg-black rounded-lg border border-white/15 text-xs font-mono text-neutral-300 break-all select-all">
                    {appUrl}
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2 pt-1 text-[11px] font-mono text-neutral-400">
                    <div className="truncate">
                      <span className="text-neutral-500">Shared URL: </span>
                      <a href={APP_URLS.SHARED_URL} target="_blank" rel="noreferrer" className="text-neutral-300 hover:text-white underline">
                        {APP_URLS.SHARED_URL.slice(0, 48)}...
                      </a>
                    </div>
                  </div>
                </div>

                {/* Account & Authentication Status */}
                <div className="p-4 rounded-xl bg-neutral-900 border border-white/15 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-semibold text-white">Cloud Authentication Status</p>
                      <p className="text-[11px] text-neutral-400">
                        {currentUser
                          ? currentUser.isGuest
                            ? `Guest Account (${isTrialExpired ? 'Trial Expired' : '10-minute trial active'})`
                            : `Signed in as ${currentUser.email}`
                          : 'Not signed in'}
                      </p>
                    </div>
                    <button
                      onClick={onOpenAuth}
                      className="px-3 py-1.5 rounded-lg bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition"
                    >
                      {currentUser?.isGuest ? 'Upgrade to @gmail' : currentUser ? 'Manage Account' : 'Sign In with @gmail'}
                    </button>
                  </div>

                  <div className="p-2.5 rounded-lg bg-white/5 border border-white/10 text-[11px] text-neutral-300 flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Database & cloud data synchronization secured with Firebase Firestore. Only @gmail.com accounts supported.</span>
                  </div>
                </div>

                {/* This Device's Sync Key */}
                <div className="p-4 rounded-xl bg-neutral-900 border border-white/15 space-y-2">
                  <p className="text-xs font-semibold text-neutral-300">Your Universal Cloud Sync Key</p>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 py-2 px-3 bg-black rounded-lg border border-white/20 font-mono text-sm tracking-wider text-white select-all">
                      {settings.cloudSyncKey}
                    </code>
                    <button
                      onClick={handleCopySyncKey}
                      className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-medium flex items-center gap-1.5 transition"
                    >
                      {copiedKey ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-neutral-500">
                    Use this key on your other phone, tablet, or laptop to sync instantly with this session.
                  </p>
                </div>

                {/* Connect Device / Pair with Another Sync Key */}
                <div className="p-4 rounded-xl bg-neutral-900 border border-white/15 space-y-3">
                  <p className="text-xs font-semibold text-neutral-300">Pair With An Existing Device</p>
                  <p className="text-[11px] text-neutral-400">
                    Have Ultron running on your mobile or another PC? Enter its Sync Key here to download and merge your data.
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={inputSyncKey}
                      onChange={(e) => setInputSyncKey(e.target.value.toUpperCase())}
                      placeholder="e.g. ULTRON-ABCD-1234"
                      className="flex-1 py-2 px-3 bg-black rounded-lg border border-white/20 font-mono text-xs text-white uppercase focus:outline-none focus:border-white"
                    />
                    <button
                      onClick={handleConnectSyncKey}
                      disabled={isPulling || !inputSyncKey.trim()}
                      className="px-4 py-2 bg-white text-black font-semibold rounded-lg text-xs hover:bg-neutral-200 transition disabled:opacity-50 flex items-center gap-1.5"
                    >
                      {isPulling ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : 'Connect & Pull'}
                    </button>
                  </div>
                  {syncStatusMsg && (
                    <div
                      className={`p-2.5 rounded-lg text-xs flex items-center gap-2 ${
                        syncStatusMsg.type === 'success'
                          ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                          : 'bg-rose-950/60 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {syncStatusMsg.type === 'success' ? (
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                      ) : (
                        <AlertCircle className="w-4 h-4 shrink-0" />
                      )}
                      <span>{syncStatusMsg.text}</span>
                    </div>
                  )}
                </div>

                {/* Auto Sync Toggle & Manual Trigger */}
                <div className="p-4 rounded-xl bg-neutral-900/60 border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-semibold text-white">Continuous Auto-Sync</p>
                      <p className="text-[11px] text-neutral-400">Automatically backup changes in real-time.</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.autoCloudSync}
                      onChange={(e) => onUpdateSettings({ autoCloudSync: e.target.checked })}
                      className="w-4 h-4 accent-white rounded"
                    />
                  </div>

                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs">
                    <span className="text-neutral-400">
                      Status:{' '}
                      <strong className="text-white capitalize">
                        {cloudSyncState === 'syncing' ? 'Syncing...' : cloudSyncState}
                      </strong>{' '}
                      {lastSyncedAt && `(${new Date(lastSyncedAt).toLocaleTimeString()})`}
                    </span>
                    <button
                      onClick={onTriggerSync}
                      className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-xs flex items-center gap-1.5 transition"
                    >
                      <RefreshCw className={`w-3 h-3 ${cloudSyncState === 'syncing' ? 'animate-spin' : ''}`} />
                      Sync Cloud Now
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* AI MODEL */}
            {activeSection === 'ai_model' && (
              <div className="space-y-5">
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">Ultron Neural Model</h4>
                  <p className="text-xs text-neutral-400 mb-3">
                    Configured via server-side Ultron Neural Engine.
                  </p>
                  <div className="grid gap-2">
                    {[
                      { id: 'gemini-3.1-flash-lite', label: 'Ultron 3.1 Lite (Default)', desc: 'Lightning fast response times, optimized for rapid voice and neural interactions.' },
                      { id: 'gemini-3.8-flash', label: 'Ultron 3.8 Flash', desc: 'High intelligence, balanced speed and reasoning.' },
                      { id: 'gemini-3.1-pro-preview', label: 'Ultron 3.1 Pro (Deep Reasoning)', desc: 'Advanced STEM reasoning and deep synaptic analysis.' },
                    ].map((m) => (
                      <div
                        key={m.id}
                        onClick={() => onUpdateSettings({ geminiModel: m.id })}
                        className={`p-3 rounded-xl border cursor-pointer transition text-left ${
                          settings.geminiModel === m.id
                            ? 'bg-white/15 border-white text-white font-semibold'
                            : 'bg-white/5 border-white/10 hover:border-white/20 text-neutral-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <p className="text-xs">{m.label}</p>
                          {settings.geminiModel === m.id && <CheckCircle2 className="w-4 h-4 text-white" />}
                        </div>
                        <p className="text-[11px] text-neutral-400 mt-0.5">{m.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-white">Extended Thinking Mode</p>
                    <p className="text-[11px] text-neutral-400">Engages deep reasoning stream before formulating answers.</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.thinkingMode}
                    onChange={(e) => onUpdateSettings({ thinkingMode: e.target.checked })}
                    className="w-4 h-4 accent-white rounded"
                  />
                </div>
              </div>
            )}

            {/* VOICE & TTS */}
            {activeSection === 'voice' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white">Auto-Speak Responses</h4>
                    <p className="text-xs text-neutral-400">Read Ultron's answers aloud automatically.</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.autoSpeak}
                    onChange={(e) => onUpdateSettings({ autoSpeak: e.target.checked })}
                    className="w-4 h-4 accent-white rounded"
                  />
                </div>

                <div>
                  <label className="text-xs text-neutral-400 block mb-1">Synthesizer Voice</label>
                  <select
                    value={settings.selectedVoice}
                    onChange={(e) => onUpdateSettings({ selectedVoice: e.target.value })}
                    className="w-full p-2 bg-neutral-900 border border-white/20 rounded-xl text-xs text-white focus:outline-none"
                  >
                    <option value="">Default System Natural Voice</option>
                    {availableVoices.map((v) => (
                      <option key={v.name} value={v.name}>
                        {v.name} ({v.lang})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex justify-between text-xs text-neutral-400 mb-1">
                    <span>Speech Rate</span>
                    <span className="font-mono text-white">{settings.speechRate.toFixed(2)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.75"
                    max="1.5"
                    step="0.05"
                    value={settings.speechRate}
                    onChange={(e) => onUpdateSettings({ speechRate: parseFloat(e.target.value) })}
                    className="w-full accent-white"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-neutral-400 mb-1">
                    <span>Speech Pitch</span>
                    <span className="font-mono text-white">{settings.speechPitch.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.7"
                    max="1.3"
                    step="0.05"
                    value={settings.speechPitch}
                    onChange={(e) => onUpdateSettings({ speechPitch: parseFloat(e.target.value) })}
                    className="w-full accent-white"
                  />
                </div>

                <div className="pt-3 border-t border-white/10 space-y-3">
                  <h4 className="text-xs font-bold font-mono tracking-wider text-white uppercase">
                    ElevenLabs Neural Voice Engine
                  </h4>
                  <p className="text-[11px] text-neutral-400">
                    Provide your ElevenLabs API Key and Voice ID to synthesize ultra-realistic neural speech.
                  </p>

                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">ElevenLabs API Key</label>
                    <input
                      type="password"
                      placeholder="sk_..."
                      value={settings.elevenLabsApiKey}
                      onChange={(e) => onUpdateSettings({ elevenLabsApiKey: e.target.value })}
                      className="w-full p-2.5 bg-neutral-900 border border-white/20 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">ElevenLabs Voice ID</label>
                    <input
                      type="text"
                      placeholder="e.g. 21m00Tcm4TlvDq8ikWAM"
                      value={settings.elevenLabsVoiceId}
                      onChange={(e) => onUpdateSettings({ elevenLabsVoiceId: e.target.value })}
                      className="w-full p-2.5 bg-neutral-900 border border-white/20 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* MICROPHONE */}
            {activeSection === 'microphone' && (
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-white">Audio Hardware & Microphone</h4>
                <div className="space-y-2 text-xs text-neutral-300 font-mono">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex justify-between items-center">
                    <span>Web Audio Context:</span>
                    <span className="text-emerald-400 font-semibold">Active & Calibrated</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex justify-between items-center">
                    <span>AnalyserNode Sampling:</span>
                    <span className="text-white">64-FFT Real-Time Amplitude</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex justify-between items-center">
                    <span>Speech Recognition:</span>
                    <span className="text-emerald-400 font-semibold">Supported</span>
                  </div>
                </div>
              </div>
            )}

            {/* APPEARANCE */}
            {activeSection === 'appearance' && (
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-white">Visual Matrix & Holographic Core</h4>
                <div className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-2 text-xs">
                  <p className="font-semibold text-white">Core Preset: Quantum Flux Singularity</p>
                  <p className="text-neutral-400">
                    High-density 4-lobed wireframe manifold with 4 inclined orbital rings, traveling beacon nodes, and cosmic dust starfield.
                  </p>
                </div>
                <div className="space-y-2 text-xs font-mono">
                  <div className="p-2.5 rounded-lg bg-neutral-900 border border-white/10 flex justify-between">
                    <span className="text-neutral-400">Theme:</span>
                    <span className="text-white">Deep Obsidian Space (#000000)</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-neutral-900 border border-white/10 flex justify-between">
                    <span className="text-neutral-400">Typography:</span>
                    <span className="text-white">Syne + Plus Jakarta Sans + JetBrains Mono</span>
                  </div>
                </div>
              </div>
            )}

            {/* SHORTCUTS */}
            {activeSection === 'shortcuts' && (
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-white">Keyboard Shortcuts (Laptop & PC)</h4>
                <div className="space-y-2 text-xs">
                  {[
                    { key: 'Enter', desc: 'Send prompt message' },
                    { key: 'Shift + Enter', desc: 'Insert newline in prompt bar' },
                    { key: 'Click / Tap Core', desc: 'Toggle real-time voice input' },
                    { key: 'Cmd/Ctrl + K', desc: 'Focus conversation search' },
                    { key: 'Escape', desc: 'Close open modals and sidebars' },
                  ].map((s) => (
                    <div key={s.key} className="p-2.5 rounded-lg bg-white/5 border border-white/10 flex justify-between items-center">
                      <kbd className="px-2 py-1 bg-black rounded border border-white/30 text-white font-mono text-[11px]">
                        {s.key}
                      </kbd>
                      <span className="text-neutral-400">{s.desc}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* PRIVACY */}
            {activeSection === 'privacy' && (
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-emerald-400">Privacy & Data Sovereignity</h4>
                <div className="space-y-2 text-xs text-neutral-300">
                  <p>• Data resides in your browser and on your private synchronized cloud store.</p>
                  <p>• Zero telemetry, tracking cookies, or third-party ad beacons.</p>
                  <p>• Offline mode does not send any tokens across the public internet.</p>
                  <p>• Cloud Sync keys are user-controlled and can be reset at any time.</p>
                </div>
              </div>
            )}

            {/* DATA & BACKUP */}
            {activeSection === 'data' && (
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-white">Data Management & Reset</h4>
                <div className="space-y-3">
                  <button
                    onClick={() => {
                      if (window.confirm('Clear all conversation history? This cannot be undone.')) {
                        onClearHistory();
                      }
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs font-semibold hover:bg-rose-900/60 transition text-left"
                  >
                    Clear All Chat Conversations
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm('Clear all tasks in productivity?')) {
                        onClearTasks();
                      }
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-white/5 border border-white/10 text-neutral-300 text-xs font-semibold hover:bg-white/10 transition text-left"
                  >
                    Clear Productivity Database
                  </button>
                </div>
              </div>
            )}

            {/* ABOUT */}
            {activeSection === 'about' && (
              <div className="space-y-4 text-xs text-neutral-300">
                <h4 className="text-sm font-bold text-white font-mono">ULTRON NEURAL SYSTEM</h4>
                <p>
                  Cross-platform smart assistant designed for mobile (iOS & Android), tablets, laptops, and desktop PCs with seamless cloud synchronization.
                </p>

                {/* Direct App Downloads */}
                <div className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-2.5">
                  <p className="font-semibold text-white font-mono text-[11px]">NATIVE DOWNLOADS</p>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <a
                      href="/api/download/android"
                      download="UltronAI-v3.8-universal.apk"
                      className="flex-1 py-2 px-3 rounded-lg bg-white text-black font-bold text-center text-xs hover:bg-neutral-200 transition"
                    >
                      Download Android APK (.apk)
                    </a>
                    <a
                      href="/api/download/windows-exe"
                      download="UltronAI-Setup.exe"
                      className="flex-1 py-2 px-3 rounded-lg bg-white/15 hover:bg-white/25 text-white border border-white/20 font-medium text-center text-xs transition"
                    >
                      Download for Windows (.exe)
                    </a>
                  </div>
                </div>

                {/* Developer Credits */}
                <div className="p-3.5 bg-cyan-950/20 border border-cyan-500/20 rounded-xl space-y-2">
                  <p className="font-semibold text-cyan-300 font-mono text-[11px] uppercase tracking-wider">CREATORS & CREDITS</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div className="p-2 rounded-lg bg-white/5 border border-white/10">
                      <p className="text-[10px] text-neutral-400 font-mono">Core System Architecture</p>
                      <p className="font-bold text-white">Coded by sibtain</p>
                    </div>
                    <div className="p-2 rounded-lg bg-white/5 border border-white/10">
                      <p className="text-[10px] text-neutral-400 font-mono">Neural Assistant Core</p>
                      <p className="font-bold text-white">assistant code by shreyash</p>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-1 font-mono text-[11px]">
                  <p>Client: React 19 + TypeScript + Tailwind CSS</p>
                  <p>Backend: Express + Ultron Neural Core</p>
                  <p>PWA: Workbox Service Worker + Standalone Manifest</p>
                  <p>Default Engine: Ultron 3.1 Lite</p>
                  <p>Packages: Android APK v3.8 • Windows x64 Desktop</p>
                </div>
              </div>
            )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
