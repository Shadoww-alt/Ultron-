import React from 'react';
import { Clock, ShieldAlert, Sparkles, UserCheck } from 'lucide-react';
import { GUEST_TRIAL_DURATION_MS } from '../services/firestoreSync';

interface GuestTrialBannerProps {
  isGuest: boolean;
  timeRemainingMs: number;
  isExpired: boolean;
  onOpenAuth: () => void;
}

export const GuestTrialBanner: React.FC<GuestTrialBannerProps> = ({
  isGuest,
  timeRemainingMs,
  isExpired,
  onOpenAuth,
}) => {
  if (!isGuest) return null;

  const totalSeconds = Math.max(0, Math.floor(timeRemainingMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const formattedTime = `${minutes}:${seconds.toString().padStart(2, '0')}`;

  const progressPercent = Math.max(
    0,
    Math.min(100, (timeRemainingMs / GUEST_TRIAL_DURATION_MS) * 100)
  );

  return (
    <aside
      aria-label="Guest trial status"
      className={`w-full px-3 sm:px-4 py-2 border-b flex items-center justify-between text-xs z-30 transition-colors select-none backdrop-blur-xl ${
        isExpired
          ? 'bg-neutral-900/95 border-white/25 text-white'
          : 'bg-black/80 border-white/10 text-neutral-300'
      }`}
    >
      <div className="flex items-center gap-2.5 truncate pr-2">
        {isExpired ? (
          <ShieldAlert className="w-4 h-4 text-white shrink-0" />
        ) : (
          <Clock className="w-4 h-4 text-neutral-300 shrink-0 animate-pulse" />
        )}
        <div className="flex items-center gap-2 font-mono text-[11px] truncate tabular-nums">
          <span>
            {isExpired ? '10-Minute Guest Trial Concluded' : 'Guest Trial:'}
          </span>
          <span
            className={`font-semibold text-[10px] ${
              isExpired ? 'text-white underline underline-offset-4' : 'text-white'
            }`}
          >
            {isExpired ? 'EXPIRED' : formattedTime}
          </span>
          <span className="hidden sm:inline text-neutral-400">
            {isExpired
              ? '— Sign in with @gmail to resume and sync your cloud data.'
              : '— Connect @gmail account to preserve data across devices.'}
          </span>
        </div>
      </div>

      <button
        onClick={onOpenAuth}
        className="px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 bg-white hover:bg-neutral-200 text-black shadow"
      >
        <UserCheck className="w-3.5 h-3.5" />
        <span>Sign In with @gmail</span>
      </button>
    </aside>
  );
};
