import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { modalBackdropVariants, modalSheetVariants } from '../utils/motionSystem';
import {
  Shield,
  X,
  Mail,
  Clock,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  LogOut,
  User,
  ArrowRight,
} from 'lucide-react';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInAnonymously,
  signOut,
} from '../services/firebase';
import { UserProfile, isAllowedGmail, GUEST_TRIAL_DURATION_MS } from '../services/firestoreSync';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  guestTimeRemainingMs: number;
  isTrialExpired: boolean;
  onSignInSuccess: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  guestTimeRemainingMs,
  isTrialExpired,
  onSignInSuccess,
}) => {
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGoogleSignIn = async () => {
    setErrorMsg(null);
    setIsLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const email = result.user.email;

      if (!isAllowedGmail(email)) {
        await signOut(auth);
        setErrorMsg('Access Restricted: Only @gmail.com accounts are supported.');
        setIsLoading(false);
        return;
      }

      setIsLoading(false);
      onSignInSuccess();
      onClose();
    } catch (err: any) {
      console.warn('Gmail sign-in error:', err);
      if (err.code !== 'auth/popup-closed-by-user') {
        setErrorMsg(err.message || 'Authentication failed');
      }
      setIsLoading(false);
    }
  };

  const handleGuestTrialSignIn = async () => {
    if (isTrialExpired) {
      setErrorMsg('Your 10-minute guest trial has expired. Please sign in with your @gmail account.');
      return;
    }

    setErrorMsg(null);
    setIsLoading(true);
    try {
      await signInAnonymously(auth);
      setIsLoading(false);
      onSignInSuccess();
      onClose();
    } catch (err: any) {
      console.warn('Anonymous guest sign-in error:', err);
      setErrorMsg(err.message || 'Failed to start guest trial');
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      onClose();
    } catch (err: any) {
      console.warn('Sign out error:', err);
    }
  };

  const formatRemainingTime = (ms: number) => {
    const totalSec = Math.max(0, Math.floor(ms / 1000));
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          variants={modalBackdropVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
          onClick={() => {
            if (!isTrialExpired) onClose();
          }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
        >
          <motion.div
            variants={modalSheetVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md ios-glass-elevated rounded-3xl p-6 text-white relative"
          >
            {/* Close Button (disabled if trial is expired and user must authenticate) */}
            {!isTrialExpired && (
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={onClose}
                className="absolute top-4 right-4 p-1.5 text-neutral-400 hover:text-white hover:bg-white/10 rounded-xl transition"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </motion.button>
            )}

        {/* Brand Header */}
        <div className="text-center space-y-2 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center mx-auto shadow-inner">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-base font-bold tracking-wide font-mono">
            {isTrialExpired ? 'GUEST TRIAL EXPIRED' : 'ULTRON CLOUD ACCOUNT'}
          </h2>
          <p className="text-xs text-neutral-400 max-w-xs mx-auto">
            {isTrialExpired
              ? 'Your 10-minute guest trial has concluded. Sign in with your @gmail account to preserve and sync all cloud data.'
              : 'Secure cloud data synchronization across iOS, Android, laptops, and PCs.'}
          </p>
        </div>

        {/* If user is currently signed in */}
        {currentUser && !isTrialExpired ? (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2 text-xs">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div className="truncate">
                  <p className="font-semibold text-white">{currentUser.displayName}</p>
                  <p className="text-[11px] text-neutral-400 font-mono truncate">
                    {currentUser.isGuest ? 'Guest Trial Account' : currentUser.email}
                  </p>
                </div>
              </div>

              {currentUser.isGuest && (
                <div className="pt-2 border-t border-white/10 flex items-center justify-between text-neutral-300 font-mono text-[11px] tabular-nums">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-white" />
                    Trial Time Remaining:
                  </span>
                  <span className="font-bold text-white">{formatRemainingTime(guestTimeRemainingMs)}</span>
                </div>
              )}
            </div>

            {currentUser.isGuest ? (
              <div className="space-y-2">
                <button
                  onClick={handleGoogleSignIn}
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 rounded-xl bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition flex items-center justify-center gap-2 shadow-lg"
                >
                  <Mail className="w-4 h-4" />
                  <span>Upgrade to Permanent @gmail Account</span>
                </button>
                <p className="text-[10px] text-neutral-500 text-center">
                  All guest conversations and tasks will be migrated to your Gmail account.
                </p>
              </div>
            ) : (
              <button
                onClick={handleSignOut}
                className="w-full py-2 px-4 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-neutral-300 hover:text-white text-xs font-medium transition flex items-center justify-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            )}
          </div>
        ) : (
          /* Sign In Options */
          <div className="space-y-4">
            {errorMsg && (
              <div className="p-3 rounded-xl bg-white/10 border border-white/25 text-white text-xs flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-white" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Gmail Sign In (@gmail only) */}
            <div className="space-y-2">
              <button
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full py-3 px-4 rounded-xl bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition flex items-center justify-center gap-2.5 shadow-xl"
              >
                <Mail className="w-4 h-4" />
                <span>Sign in with @gmail.com</span>
              </button>

              <div className="flex items-center gap-1.5 justify-center text-[11px] text-neutral-400">
                <CheckCircle2 className="w-3 h-3 text-white" />
                <span>Exclusively supports @gmail.com accounts</span>
              </div>
            </div>

            {/* Divider */}
            <div className="relative flex items-center justify-center py-2">
              <div className="border-t border-white/10 w-full" />
              <span className="bg-neutral-950 px-3 text-[10px] text-neutral-500 font-mono uppercase">
                Or Trial Option
              </span>
            </div>

            {/* Guest 10-Min Trial Option */}
            <div className="space-y-2">
              <button
                onClick={handleGuestTrialSignIn}
                disabled={isLoading || isTrialExpired}
                className={`w-full py-2.5 px-4 rounded-xl border text-xs font-medium transition flex items-center justify-center gap-2 ${
                  isTrialExpired
                    ? 'opacity-40 cursor-not-allowed border-white/10 text-neutral-500 bg-white/5'
                    : 'bg-white/5 hover:bg-white/10 border-white/20 text-neutral-200 hover:text-white'
                }`}
              >
                <Clock className="w-4 h-4 text-neutral-300" />
                <span>Continue as Guest (10-Minute Trial)</span>
              </button>

              <p className="text-[10px] text-neutral-400 text-center leading-relaxed">
                Guest mode grants instant access with a 10-minute trial timer. Once 10 minutes expire, you must connect a @gmail.com account to continue syncing data.
              </p>
            </div>
          </div>
        )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
