import React, { useEffect, useRef } from 'react';
import { UltronCoreState } from '../types';

interface QuantumCoreVisualizerProps {
  state: UltronCoreState;
  audioAmplitude?: number;
  className?: string;
  onClick?: () => void;
}

interface SmoothCoreMetrics {
  listenMix: number;
  thinkMix: number;
  speakMix: number;
  idleMix: number;
  smoothAmp: number;
  phase: number;
  cognitivePhase: number;
}

const buildOrganicCurvePoints = (
  cx: number,
  cy: number,
  baseR: number,
  time: number,
  pointsCount: number,
  harmonic2: number,
  harmonic3: number,
  harmonic4: number,
  phaseShift: number
): Array<{ x: number; y: number }> => {
  const pts: Array<{ x: number; y: number }> = [];
  for (let i = 0; i < pointsCount; i++) {
    const theta = (i / pointsCount) * Math.PI * 2;
    const d2 = harmonic2 * Math.cos(2 * theta - time * 0.85 + phaseShift);
    const d3 = harmonic3 * Math.sin(3 * theta + time * 0.62 - phaseShift * 0.7);
    const d4 = harmonic4 * Math.cos(4 * theta - time * 1.1 + phaseShift * 1.3);
    const r = baseR * (1 + d2 + d3 + d4);
    pts.push({
      x: cx + Math.cos(theta) * r,
      y: cy + Math.sin(theta) * r,
    });
  }
  return pts;
};

const traceClosedSmoothCurve = (
  ctx: CanvasRenderingContext2D,
  pts: Array<{ x: number; y: number }>
) => {
  const len = pts.length;
  if (len < 3) return;
  ctx.beginPath();
  const firstMidX = (pts[len - 1].x + pts[0].x) * 0.5;
  const firstMidY = (pts[len - 1].y + pts[0].y) * 0.5;
  ctx.moveTo(firstMidX, firstMidY);
  for (let i = 0; i < len; i++) {
    const curr = pts[i];
    const next = pts[(i + 1) % len];
    const midX = (curr.x + next.x) * 0.5;
    const midY = (curr.y + next.y) * 0.5;
    ctx.quadraticCurveTo(curr.x, curr.y, midX, midY);
  }
  ctx.closePath();
};

export const QuantumCoreVisualizer: React.FC<QuantumCoreVisualizerProps> = ({
  state,
  audioAmplitude = 0,
  className = '',
  onClick,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animRef = useRef<number | null>(null);
  const stateRef = useRef<UltronCoreState>(state);
  const ampRef = useRef<number>(audioAmplitude);

  stateRef.current = state;
  ampRef.current = audioAmplitude;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

    const metrics: SmoothCoreMetrics = {
      listenMix: stateRef.current === 'LISTENING' ? 1 : 0,
      thinkMix: stateRef.current === 'THINKING' ? 1 : 0,
      speakMix: stateRef.current === 'SPEAKING' ? 1 : 0,
      idleMix: stateRef.current === 'IDLE' ? 1 : 0,
      smoothAmp: 0,
      phase: 0,
      cognitivePhase: 0,
    };

    let width = 0;
    let height = 0;
    let dpr = 1;
    let lastTs = performance.now();

    const syncSize = () => {
      const rect = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);
      const targetW = Math.round(width * dpr);
      const targetH = Math.round(height * dpr);
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }
    };

    syncSize();
    const resizeObserver =
      typeof ResizeObserver !== 'undefined' ? new ResizeObserver(syncSize) : null;
    resizeObserver?.observe(canvas);
    window.addEventListener('resize', syncSize);

    const drawFrame = (now: number) => {
      const dt = Math.min(0.05, Math.max(0.001, (now - lastTs) / 1000));
      lastTs = now;

      const currentState = stateRef.current;
      const targetAmp = Math.min(1, Math.max(0, ampRef.current || 0));

      // Frame-rate-independent smooth exponential interpolation between states
      const blendRate = 1 - Math.exp(-dt * 4.5);
      metrics.idleMix += ((currentState === 'IDLE' ? 1 : 0) - metrics.idleMix) * blendRate;
      metrics.listenMix += ((currentState === 'LISTENING' ? 1 : 0) - metrics.listenMix) * blendRate;
      metrics.thinkMix += ((currentState === 'THINKING' ? 1 : 0) - metrics.thinkMix) * blendRate;
      metrics.speakMix += ((currentState === 'SPEAKING' ? 1 : 0) - metrics.speakMix) * blendRate;

      // Fast-attack, velvety-decay audio amplitude envelope
      const ampRate = targetAmp > metrics.smoothAmp ? 1 - Math.exp(-dt * 18) : 1 - Math.exp(-dt * 6.5);
      metrics.smoothAmp += (targetAmp - metrics.smoothAmp) * ampRate;

      const motionScale = prefersReducedMotion ? 0.15 : 1;
      const baseTempo =
        0.52 * metrics.idleMix +
        (0.85 + metrics.smoothAmp * 1.1) * metrics.listenMix +
        1.45 * metrics.thinkMix +
        (1.15 + metrics.smoothAmp * 1.45) * metrics.speakMix;

      metrics.phase += dt * baseTempo * motionScale;
      metrics.cognitivePhase += dt * (0.4 + metrics.thinkMix * 1.65 + metrics.speakMix * 0.9) * motionScale;

      const t = metrics.phase;
      const ct = metrics.cognitivePhase;
      const amp = metrics.smoothAmp;

      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, width, height);

      const cx = width * 0.5;
      const cy = height * 0.5;
      const minDim = Math.min(width, height);
      const isCompact = minDim <= 64;

      // Breathing + reactive scale
      const breath = Math.sin(t * 1.15) * 0.018;
      const voiceExpansion =
        metrics.listenMix * (0.03 + amp * 0.085) +
        metrics.speakMix * (0.02 + amp * 0.095);
      const thinkPoise = metrics.thinkMix * (Math.sin(ct * 1.8) * 0.016);
      const radius = minDim * (isCompact ? 0.37 : 0.345) * (1 + breath + voiceExpansion + thinkPoise);

      // 1. Ambient Monochrome Atmospheric Depth Halo
      const haloRadius = radius * (1.72 + metrics.listenMix * 0.12 + metrics.speakMix * amp * 0.22);
      const haloAlpha =
        0.11 * metrics.idleMix +
        (0.16 + amp * 0.14) * metrics.listenMix +
        (0.17 + 0.04 * Math.sin(ct * 2)) * metrics.thinkMix +
        (0.16 + amp * 0.18) * metrics.speakMix;

      const ambientGrad = ctx.createRadialGradient(cx, cy, radius * 0.25, cx, cy, haloRadius);
      ambientGrad.addColorStop(0, `rgba(255, 255, 255, ${haloAlpha.toFixed(3)})`);
      ambientGrad.addColorStop(0.55, `rgba(210, 212, 220, ${(haloAlpha * 0.35).toFixed(3)})`);
      ambientGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = ambientGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, haloRadius, 0, Math.PI * 2);
      ctx.fill();

      // 2. Sculpted Outer Liquid Glass Vessel Contour
      const h2 =
        0.022 * metrics.idleMix +
        (0.026 + amp * 0.038) * metrics.listenMix +
        0.048 * metrics.thinkMix +
        (0.03 + amp * 0.05) * metrics.speakMix;
      const h3 =
        0.014 * metrics.idleMix +
        (0.02 + amp * 0.028) * metrics.listenMix +
        0.018 * metrics.thinkMix +
        (0.024 + amp * 0.034) * metrics.speakMix;
      const h4 =
        0.006 * metrics.idleMix +
        (0.012 + amp * 0.018) * metrics.listenMix +
        0.008 * metrics.thinkMix +
        (0.014 + amp * 0.022) * metrics.speakMix;

      const outerPts = buildOrganicCurvePoints(
        cx,
        cy,
        radius,
        t,
        isCompact ? 28 : 48,
        h2,
        h3,
        h4,
        ct * 0.35
      );

      // Clip interior fluid glass dynamics inside the organic vessel
      ctx.save();
      traceClosedSmoothCurve(ctx, outerPts);

      // Obsidian Liquid Glass Interior Base
      const vesselBaseGrad = ctx.createRadialGradient(
        cx - radius * 0.26,
        cy - radius * 0.28,
        radius * 0.08,
        cx,
        cy,
        radius * 1.12
      );
      vesselBaseGrad.addColorStop(0, 'rgba(54, 54, 58, 0.92)');
      vesselBaseGrad.addColorStop(0.52, 'rgba(20, 20, 23, 0.94)');
      vesselBaseGrad.addColorStop(1, 'rgba(8, 8, 10, 0.98)');
      ctx.fillStyle = vesselBaseGrad;
      ctx.fill();

      ctx.clip();

      // 3. Internal Abstract Fluid Energy Forms (Soft Translucent Silver & Pearl Veils)
      ctx.globalCompositeOperation = 'screen';

      // Primary flowing silver veil
      const lobe1X =
        cx +
        Math.cos(t * 0.9) * radius * (0.24 + metrics.thinkMix * 0.16) +
        Math.sin(ct * 1.3) * radius * 0.08;
      const lobe1Y =
        cy +
        Math.sin(t * 0.72) * radius * (0.22 - metrics.thinkMix * 0.08) -
        radius * 0.06;
      const lobe1R = radius * (0.86 + amp * 0.18 + metrics.speakMix * 0.08);
      const lobe1Grad = ctx.createRadialGradient(lobe1X, lobe1Y, 0, lobe1X, lobe1Y, lobe1R);
      const l1Alpha = 0.28 + metrics.listenMix * (0.08 + amp * 0.18) + metrics.speakMix * (0.1 + amp * 0.22) + metrics.thinkMix * 0.12;
      lobe1Grad.addColorStop(0, `rgba(255, 255, 255, ${Math.min(0.68, l1Alpha).toFixed(3)})`);
      lobe1Grad.addColorStop(0.45, `rgba(212, 214, 220, ${(l1Alpha * 0.45).toFixed(3)})`);
      lobe1Grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = lobe1Grad;
      ctx.beginPath();
      ctx.arc(lobe1X, lobe1Y, lobe1R, 0, Math.PI * 2);
      ctx.fill();

      // Counter-drifting frosted quartz veil
      const lobe2X = cx - Math.cos(t * 0.78 + 1.2) * radius * (0.26 + metrics.thinkMix * 0.15);
      const lobe2Y = cy - Math.sin(t * 0.95 + 0.6) * radius * 0.22 + radius * 0.08;
      const lobe2R = radius * (0.76 + metrics.thinkMix * 0.12 + amp * 0.14);
      const lobe2Grad = ctx.createRadialGradient(lobe2X, lobe2Y, 0, lobe2X, lobe2Y, lobe2R);
      const l2Alpha = 0.22 + metrics.thinkMix * 0.16 + metrics.speakMix * (0.08 + amp * 0.16);
      lobe2Grad.addColorStop(0, `rgba(235, 236, 240, ${Math.min(0.55, l2Alpha).toFixed(3)})`);
      lobe2Grad.addColorStop(0.55, `rgba(145, 148, 155, ${(l2Alpha * 0.36).toFixed(3)})`);
      lobe2Grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = lobe2Grad;
      ctx.beginPath();
      ctx.arc(lobe2X, lobe2Y, lobe2R, 0, Math.PI * 2);
      ctx.fill();

      // Dynamic Acoustic / Cognitive Inner Membrane (sculpted fluid wave inside glass)
      const membraneR =
        radius *
        (0.52 +
          0.04 * Math.sin(t * 1.4) +
          metrics.listenMix * (0.06 + amp * 0.16) +
          metrics.speakMix * (0.08 + amp * 0.2) -
          metrics.thinkMix * 0.04);

      const innerPts = buildOrganicCurvePoints(
        cx + Math.sin(ct * 1.2) * radius * 0.05 * metrics.thinkMix,
        cy + Math.cos(ct * 1.4) * radius * 0.04 * metrics.thinkMix,
        membraneR,
        t * 1.35 + 1.4,
        isCompact ? 24 : 40,
        h2 * 1.65 + metrics.thinkMix * 0.06,
        h3 * 1.8 + metrics.speakMix * (0.02 + amp * 0.05),
        h4 * 1.5,
        -ct * 0.65
      );
      traceClosedSmoothCurve(ctx, innerPts);

      const membraneGrad = ctx.createLinearGradient(
        cx - membraneR,
        cy - membraneR,
        cx + membraneR,
        cy + membraneR
      );
      const memAlpha = 0.16 + metrics.listenMix * 0.12 + metrics.thinkMix * 0.18 + metrics.speakMix * (0.14 + amp * 0.22);
      membraneGrad.addColorStop(0, `rgba(255, 255, 255, ${Math.min(0.55, memAlpha).toFixed(3)})`);
      membraneGrad.addColorStop(0.5, `rgba(180, 182, 188, ${(memAlpha * 0.38).toFixed(3)})`);
      membraneGrad.addColorStop(1, `rgba(255, 255, 255, ${(memAlpha * 0.72).toFixed(3)})`);
      ctx.fillStyle = membraneGrad;
      ctx.fill();

      // Soft internal focal luminosity (pure pearl center)
      const nucleusScale =
        0.24 +
        metrics.idleMix * 0.02 * Math.sin(t * 1.6) +
        metrics.listenMix * (0.04 + amp * 0.1) +
        metrics.thinkMix * (0.05 * (0.5 + 0.5 * Math.sin(ct * 2.4))) +
        metrics.speakMix * (0.05 + amp * 0.14);

      const nucleusR = radius * nucleusScale;
      const nucleusGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, nucleusR * 2.2);
      nucleusGrad.addColorStop(0, 'rgba(255, 255, 255, 0.96)');
      nucleusGrad.addColorStop(0.32, 'rgba(244, 244, 248, 0.56)');
      nucleusGrad.addColorStop(0.68, 'rgba(180, 182, 188, 0.12)');
      nucleusGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = nucleusGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, nucleusR * 2.2, 0, Math.PI * 2);
      ctx.fill();

      // Subtle Apple-style upper-left Liquid Glass specular crescent refraction
      if (!isCompact) {
        const specGrad = ctx.createLinearGradient(
          cx - radius * 0.78,
          cy - radius * 0.82,
          cx + radius * 0.1,
          cy - radius * 0.08
        );
        specGrad.addColorStop(0, 'rgba(255, 255, 255, 0.28)');
        specGrad.addColorStop(0.55, 'rgba(255, 255, 255, 0.05)');
        specGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');

        ctx.fillStyle = specGrad;
        ctx.beginPath();
        ctx.ellipse(
          cx - radius * 0.2,
          cy - radius * 0.34,
          radius * 0.62,
          radius * 0.32,
          -Math.PI * 0.18,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }

      ctx.restore();

      // 4. Precision Liquid Glass Specular Rim Highlight
      traceClosedSmoothCurve(ctx, outerPts);
      const rimGrad = ctx.createLinearGradient(
        cx - radius,
        cy - radius,
        cx + radius,
        cy + radius
      );
      const rimBoost = metrics.listenMix * (0.12 + amp * 0.2) + metrics.speakMix * (0.1 + amp * 0.22) + metrics.thinkMix * 0.12;
      rimGrad.addColorStop(0, `rgba(255, 255, 255, ${Math.min(0.9, 0.56 + rimBoost).toFixed(3)})`);
      rimGrad.addColorStop(0.45, `rgba(205, 208, 214, ${(0.22 + rimBoost * 0.4).toFixed(3)})`);
      rimGrad.addColorStop(0.78, `rgba(120, 122, 128, ${(0.12 + rimBoost * 0.25).toFixed(3)})`);
      rimGrad.addColorStop(1, `rgba(255, 255, 255, ${(0.24 + rimBoost * 0.5).toFixed(3)})`);
      ctx.strokeStyle = rimGrad;
      ctx.lineWidth = isCompact ? 1.15 : 1.45;
      ctx.stroke();

      // Subtle inner hairline glass bezel
      if (!isCompact) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.scale(0.955, 0.955);
        ctx.translate(-cx, -cy);
        traceClosedSmoothCurve(ctx, outerPts);
        ctx.strokeStyle = `rgba(255, 255, 255, ${(0.07 + rimBoost * 0.18).toFixed(3)})`;
        ctx.lineWidth = 0.75;
        ctx.stroke();
        ctx.restore();
      }

      ctx.restore();
      animRef.current = requestAnimationFrame(drawFrame);
    };

    animRef.current = requestAnimationFrame(drawFrame);

    return () => {
      resizeObserver?.disconnect();
      window.removeEventListener('resize', syncSize);
      if (animRef.current !== null) {
        cancelAnimationFrame(animRef.current);
      }
    };
  }, []);

  return (
    <div
      onClick={onClick}
      onKeyDown={(e) => {
        if (onClick && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          onClick();
        }
      }}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      aria-label="ULTRON Neural Core"
      className={`relative flex items-center justify-center select-none touch-manipulation transition-transform duration-200 ${
        onClick ? 'cursor-pointer active:scale-[0.97]' : ''
      } ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full max-w-[420px] max-h-[420px] aspect-square block" />
    </div>
  );
};
