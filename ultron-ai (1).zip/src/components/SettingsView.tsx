import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeft,
  Check,
  Copy,
  RefreshCw,
  Download,
  User,
  Trash2,
  Mic,
  Camera,
  Globe,
  CheckSquare,
  Cloud,
  Sparkles,
  Volume2,
  Palette,
  Cpu,
  Shield,
  Sliders,
  Info,
  ExternalLink,
} from 'lucide-react';
import { AppSettings, OperatingMode, PersonalityTone, AgentPermissions } from '../types';
import { SyncState } from '../services/cloudSync';
import { UserProfile } from '../services/firestoreSync';
import { getDevicePlatformName, getDeviceType } from '../utils/device';
import { IOSGroupedSection, IOSSwitch, triggerHaptic } from './ios/IOSControls';
import { IOS_SPRING } from '../utils/motionSystem';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  cloudSyncState: SyncState;
  lastSyncedAt: number | null;
  onTriggerSync: () => Promise<boolean>;
  onPullFromSyncKey: (key: string) => Promise<{ success: boolean; error?: string }>;
  onClearHistory: () => void;
  onClearTasks: () => void;
  availableVoices: SpeechSynthesisVoice[];
  initialSection?: string;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  appUrl: string;
  isTrialExpired: boolean;
  onOpenDownloadModal: () => void;
  onBack: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  cloudSyncState,
  lastSyncedAt,
  onTriggerSync,
  onPullFromSyncKey,
  onClearHistory,
  onClearTasks,
  availableVoices,
  initialSection = 'general',
  currentUser,
  onOpenAuth,
  appUrl,
  isTrialExpired,
  onOpenDownloadModal,
  onBack,
}) => {
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [inputSyncKey, setInputSyncKey] = useState('');
  const [syncStatusMsg, setSyncStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isPulling, setIsPulling] = useState(false);
  const [confirmClearChat, setConfirmClearChat] = useState(false);
  const [confirmClearTasks, setConfirmClearTasks] = useState(false);

  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const haptic = settings.hapticFeedback ?? true;
  const platform = getDevicePlatformName();
  const deviceType = getDeviceType();

  const permissions: AgentPermissions = settings.agentPermissions || {
    microphoneAccess: true,
    cameraAccess: true,
    webSearchAccess: true,
    taskAutomation: true,
    backgroundSync: true,
  };

  useEffect(() => {
    if (initialSection && sectionRefs.current[initialSection]) {
      sectionRefs.current[initialSection]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [initialSection]);

  const updatePermission = (key: keyof AgentPermissions, val: boolean) => {
    onUpdateSettings({
      agentPermissions: {
        ...permissions,
        [key]: val,
      },
    });
  };

  const handleCopySyncKey = () => {
    triggerHaptic(haptic);
    navigator.clipboard.writeText(settings.cloudSyncKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleCopyAppUrl = () => {
    triggerHaptic(haptic);
    navigator.clipboard.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleConnectSyncKey = async () => {
    if (!inputSyncKey.trim()) return;
    triggerHaptic(haptic);
    setIsPulling(true);
    setSyncStatusMsg(null);
    const res = await onPullFromSyncKey(inputSyncKey.trim());
    setIsPulling(false);
    if (res.success) {
      setSyncStatusMsg({ type: 'success', text: 'Cloud data paired and merged.' });
      setInputSyncKey('');
    } else {
      setSyncStatusMsg({ type: 'error', text: res.error || 'Could not pair sync key.' });
    }
  };

  const scrollToSection = (key: string) => {
    triggerHaptic(haptic, 5);
    sectionRefs.current[key]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const quickNav = [
    { id: 'personality', label: 'Personality', icon: Sparkles },
    { id: 'voice', label: 'Voice', icon: Volume2 },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'ai_model', label: 'Model', icon: Cpu },
    { id: 'sync', label: 'Privacy & Sync', icon: Shield },
    { id: 'permissions', label: 'Permissions', icon: Sliders },
    { id: 'about', label: 'About', icon: Info },
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-black text-white overflow-hidden select-none">
      {/* iOS Sticky Glass Header */}
      <header
        className="px-4 sm:px-6 py-3 border-b border-white/10 bg-black/75 backdrop-blur-2xl shrink-0 z-20"
        style={{ paddingTop: 'max(0.75rem, var(--sat))' }}
      >
        <div className="max-w-3xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.92 }}
              onClick={() => {
                triggerHaptic(haptic);
                onBack();
              }}
              className="min-h-[38px] min-w-[38px] rounded-full ios-glass flex items-center justify-center text-neutral-300 hover:text-white transition"
              aria-label="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </motion.button>
            <div>
              <h1 className="text-lg font-semibold tracking-tight text-white">Settings</h1>
            </div>
          </div>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              triggerHaptic(haptic);
              onOpenAuth();
            }}
            className="min-h-[36px] px-3 py-1.5 rounded-full ios-glass text-xs font-medium text-white flex items-center gap-1.5"
          >
            <User className="w-3.5 h-3.5" />
            <span className="truncate max-w-[130px]">
              {currentUser
                ? currentUser.isGuest
                  ? isTrialExpired
                    ? 'Trial Expired'
                    : 'Guest'
                  : currentUser.email?.split('@')[0]
                : 'Sign In'}
            </span>
          </motion.button>
        </div>

        {/* Quick Section Anchor Pills */}
        <div className="max-w-3xl mx-auto mt-3 flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
          {quickNav.map((item) => {
            const Icon = item.icon;
            return (
              <motion.button
                key={item.id}
                whileTap={{ scale: 0.95 }}
                onClick={() => scrollToSection(item.id)}
                className="px-3 py-1.5 rounded-full ios-glass hover:bg-white/10 text-[11px] font-medium text-neutral-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap shrink-0 transition"
              >
                <Icon className="w-3 h-3" />
                <span>{item.label}</span>
              </motion.button>
            );
          })}
        </div>
      </header>

      {/* Scrollable Grouped iOS Settings Body */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-5">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={IOS_SPRING}
          className="max-w-3xl mx-auto space-y-7 pb-6"
        >
          {/* 1. AI PERSONALITY / MOOD */}
          <div
            ref={(el) => {
              sectionRefs.current.personality = el;
              sectionRefs.current.general = el;
            }}
            className="space-y-4 scroll-mt-4"
          >
            <IOSGroupedSection
              title="AI Personality & Mood"
              footer="Sets Ultron's conversational tone across text and voice."
            >
              {[
                { tone: 'CASUAL_WIT' as PersonalityTone, title: 'Smart & Witty', desc: 'Natural banter with concise, clever responses' },
                { tone: 'BALANCED_SMART' as PersonalityTone, title: 'Balanced & Concise', desc: 'Calm, solution-first precision' },
                { tone: 'DEEP_MENTOR' as PersonalityTone, title: 'Intuitive Mentor', desc: 'Clear explanations in plain language' },
                { tone: 'SERIOUS_WORK' as PersonalityTone, title: 'Executive Focus', desc: 'Direct execution with zero fluff' },
              ].map((item) => {
                const selected = settings.personalityTone === item.tone;
                return (
                  <button
                    key={item.tone}
                    type="button"
                    onClick={() => {
                      triggerHaptic(haptic);
                      onUpdateSettings({ personalityTone: item.tone });
                    }}
                    className="w-full px-4 py-3.5 flex items-center justify-between gap-3 text-left hover:bg-white/[0.04] transition"
                  >
                    <div>
                      <p className="text-sm font-medium text-white">{item.title}</p>
                      <p className="text-xs text-neutral-400 mt-0.5">{item.desc}</p>
                    </div>
                    {selected && <Check className="w-4 h-4 text-white shrink-0" />}
                  </button>
                );
              })}
            </IOSGroupedSection>

            <IOSGroupedSection title="Execution Mode">
              {[
                { mode: 'ONLINE' as OperatingMode, title: 'Cloud Neural Core', desc: 'Full cloud intelligence and real-time sync' },
                { mode: 'OFFLINE' as OperatingMode, title: 'Offline Matrix (Local)', desc: 'Private on-device fallback without external transfer' },
                { mode: 'AUTO' as OperatingMode, title: 'Automatic Failover', desc: 'Seamless switch to offline when disconnected' },
              ].map((opt) => {
                const selected = settings.operatingMode === opt.mode;
                return (
                  <button
                    key={opt.mode}
                    type="button"
                    onClick={() => {
                      triggerHaptic(haptic);
                      onUpdateSettings({ operatingMode: opt.mode });
                    }}
                    className="w-full px-4 py-3.5 flex items-center justify-between gap-3 text-left hover:bg-white/[0.04] transition"
                  >
                    <div>
                      <p className="text-sm font-medium text-white">{opt.title}</p>
                      <p className="text-xs text-neutral-400 mt-0.5">{opt.desc}</p>
                    </div>
                    {selected && <Check className="w-4 h-4 text-white shrink-0" />}
                  </button>
                );
              })}
            </IOSGroupedSection>
          </div>

          {/* 2. VOICE SETTINGS */}
          <div
            ref={(el) => {
              sectionRefs.current.voice = el;
            }}
            className="scroll-mt-4"
          >
            <IOSGroupedSection
              title="Voice Settings"
              footer="Speech synthesis uses ElevenLabs neural voice exclusively for consistent clarity."
            >
              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-white">Auto-Speak Responses</p>
                  <p className="text-xs text-neutral-400 mt-0.5">Speak Ultron replies automatically</p>
                </div>
                <IOSSwitch
                  checked={settings.autoSpeak}
                  onChange={(val) => onUpdateSettings({ autoSpeak: val })}
                  ariaLabel="Auto-Speak Responses"
                  hapticEnabled={haptic}
                />
              </div>

              <div className="px-4 py-3.5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-sm font-medium text-white">Speech Rate</span>
                  <span className="font-mono text-neutral-300 tabular-nums">{settings.speechRate.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.75"
                  max="1.5"
                  step="0.05"
                  value={settings.speechRate}
                  onChange={(e) => onUpdateSettings({ speechRate: parseFloat(e.target.value) })}
                  className="w-full ios-slider"
                />
              </div>

              <div className="px-4 py-3.5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-sm font-medium text-white">Speech Pitch</span>
                  <span className="font-mono text-neutral-300 tabular-nums">{settings.speechPitch.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.7"
                  max="1.3"
                  step="0.05"
                  value={settings.speechPitch}
                  onChange={(e) => onUpdateSettings({ speechPitch: parseFloat(e.target.value) })}
                  className="w-full ios-slider"
                />
              </div>

              <div className="px-4 py-3.5 space-y-2">
                <label className="text-xs font-medium text-neutral-300 block">ElevenLabs Voice ID</label>
                <input
                  type="text"
                  value={settings.elevenLabsVoiceId}
                  onChange={(e) => onUpdateSettings({ elevenLabsVoiceId: e.target.value })}
                  placeholder="6Up7VdyJXU6KJm2SQKKx"
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-white/50"
                />
              </div>

              <div className="px-4 py-3.5 space-y-2">
                <label className="text-xs font-medium text-neutral-300 block">ElevenLabs API Key</label>
                <input
                  type="password"
                  value={settings.elevenLabsApiKey}
                  onChange={(e) => onUpdateSettings({ elevenLabsApiKey: e.target.value })}
                  placeholder="sk_..."
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-xs text-white font-mono focus:outline-none focus:border-white/50"
                />
              </div>

              {availableVoices.length > 0 && (
                <div className="px-4 py-3.5 space-y-1.5">
                  <label className="text-xs font-medium text-neutral-300 block">Fallback Voice Profile</label>
                  <select
                    value={settings.selectedVoice}
                    onChange={(e) => onUpdateSettings({ selectedVoice: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-xs text-white focus:outline-none"
                  >
                    <option value="">Default Neural Voice</option>
                    {availableVoices.map((v) => (
                      <option key={v.name} value={v.name}>
                        {v.name} ({v.lang})
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </IOSGroupedSection>
          </div>

          {/* 3. APPEARANCE */}
          <div
            ref={(el) => {
              sectionRefs.current.appearance = el;
            }}
            className="scroll-mt-4"
          >
            <IOSGroupedSection title="Appearance">
              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-white">Theme</p>
                  <p className="text-xs text-neutral-400 mt-0.5">Pure monochrome obsidian & liquid glass</p>
                </div>
                <span className="text-xs text-neutral-300 font-medium">Monochrome Dark</span>
              </div>

              <div className="px-4 py-3.5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-sm font-medium text-white">AI Orb Glow Intensity</span>
                  <span className="font-mono text-neutral-300 tabular-nums">
                    {Math.round((settings.orbGlowIntensity ?? 0.85) * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="1.2"
                  step="0.05"
                  value={settings.orbGlowIntensity ?? 0.85}
                  onChange={(e) => onUpdateSettings({ orbGlowIntensity: parseFloat(e.target.value) })}
                  className="w-full ios-slider"
                />
              </div>

              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-white">Haptic Feedback</p>
                  <p className="text-xs text-neutral-400 mt-0.5">Subtle tactile pulse on navigation and toggles</p>
                </div>
                <IOSSwitch
                  checked={settings.hapticFeedback ?? true}
                  onChange={(val) => onUpdateSettings({ hapticFeedback: val })}
                  ariaLabel="Haptic Feedback"
                  hapticEnabled={true}
                />
              </div>
            </IOSGroupedSection>
          </div>

          {/* 4. MODEL SETTINGS */}
          <div
            ref={(el) => {
              sectionRefs.current.ai_model = el;
            }}
            className="scroll-mt-4"
          >
            <IOSGroupedSection title="Model Settings">
              {[
                { id: 'gemini-3.1-flash-lite', title: 'Ultron 3.1 Lite', desc: 'Default · Ultra-low latency for voice and chat' },
                { id: 'gemini-3.8-flash', title: 'Ultron 3.8 Flash', desc: 'Balanced everyday reasoning and speed' },
                { id: 'gemini-3.1-pro-preview', title: 'Ultron 3.1 Pro', desc: 'Deep multi-step reasoning and architecture' },
              ].map((m) => {
                const selected = settings.geminiModel === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      triggerHaptic(haptic);
                      onUpdateSettings({
                        geminiModel: m.id,
                        thinkingMode: m.id === 'gemini-3.1-pro-preview',
                      });
                    }}
                    className="w-full px-4 py-3.5 flex items-center justify-between gap-3 text-left hover:bg-white/[0.04] transition"
                  >
                    <div>
                      <p className="text-sm font-medium text-white">{m.title}</p>
                      <p className="text-xs text-neutral-400 mt-0.5">{m.desc}</p>
                    </div>
                    {selected && <Check className="w-4 h-4 text-white shrink-0" />}
                  </button>
                );
              })}

              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-white">Extended Thinking Mode</p>
                  <p className="text-xs text-neutral-400 mt-0.5">Deep synaptic pass before responding</p>
                </div>
                <IOSSwitch
                  checked={settings.thinkingMode}
                  onChange={(val) => onUpdateSettings({ thinkingMode: val })}
                  ariaLabel="Extended Thinking Mode"
                  hapticEnabled={haptic}
                />
              </div>
            </IOSGroupedSection>
          </div>

          {/* 5. PRIVACY & CLOUD SYNC */}
          <div
            ref={(el) => {
              sectionRefs.current.sync = el;
              sectionRefs.current.privacy = el;
            }}
            className="space-y-4 scroll-mt-4"
          >
            <IOSGroupedSection
              title="Privacy & Cloud Sync"
              footer="Zero ad tracking or third-party telemetry. Conversations and tasks sync privately under your key and @gmail.com account."
            >
              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-white">Cloud Account</p>
                  <p className="text-xs text-neutral-400 mt-0.5 truncate">
                    {currentUser
                      ? currentUser.isGuest
                        ? `Guest Session (${isTrialExpired ? 'Expired' : '10m Trial'})`
                        : currentUser.email
                      : 'Not connected'}
                  </p>
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    triggerHaptic(haptic);
                    onOpenAuth();
                  }}
                  className="px-3.5 py-1.5 rounded-full bg-white text-black text-xs font-semibold hover:bg-neutral-200 transition shrink-0"
                >
                  {currentUser?.isGuest ? 'Upgrade' : currentUser ? 'Manage' : 'Sign In'}
                </motion.button>
              </div>

              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-white">Continuous Auto-Sync</p>
                  <p className="text-xs text-neutral-400 mt-0.5 tabular-nums">
                    {cloudSyncState === 'syncing'
                      ? 'Synchronizing...'
                      : lastSyncedAt
                      ? `Last synced ${new Date(lastSyncedAt).toLocaleTimeString()}`
                      : 'Real-time cloud backup'}
                  </p>
                </div>
                <div className="flex items-center gap-2.5">
                  <motion.button
                    whileTap={{ scale: 0.92 }}
                    onClick={() => {
                      triggerHaptic(haptic);
                      onTriggerSync();
                    }}
                    className="p-2 rounded-full bg-white/10 hover:bg-white/15 text-white transition"
                    title="Sync now"
                    aria-label="Sync now"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${cloudSyncState === 'syncing' ? 'animate-spin' : ''}`} />
                  </motion.button>
                  <IOSSwitch
                    checked={settings.autoCloudSync}
                    onChange={(val) => onUpdateSettings({ autoCloudSync: val })}
                    ariaLabel="Continuous Auto-Sync"
                    hapticEnabled={haptic}
                  />
                </div>
              </div>

              <div className="px-4 py-3.5 space-y-2">
                <p className="text-xs font-medium text-neutral-300">Universal Cloud Sync Key</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 py-2 px-3 rounded-xl bg-black/60 border border-white/15 font-mono text-xs text-white select-all">
                    {settings.cloudSyncKey}
                  </code>
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={handleCopySyncKey}
                    className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white flex items-center gap-1.5 transition"
                  >
                    {copiedKey ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey ? 'Copied' : 'Copy'}</span>
                  </motion.button>
                </div>
              </div>

              <div className="px-4 py-3.5 space-y-2">
                <p className="text-xs font-medium text-neutral-300">Pair With Existing Device</p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={inputSyncKey}
                    onChange={(e) => setInputSyncKey(e.target.value.toUpperCase())}
                    placeholder="ULTRON-XXXX-XXXX"
                    className="flex-1 py-2 px-3 rounded-xl bg-black/60 border border-white/15 font-mono text-xs text-white uppercase focus:outline-none focus:border-white/50"
                  />
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={handleConnectSyncKey}
                    disabled={isPulling || !inputSyncKey.trim()}
                    className="px-3.5 py-2 rounded-xl bg-white text-black font-semibold text-xs disabled:opacity-40 transition"
                  >
                    {isPulling ? 'Pairing...' : 'Pair'}
                  </motion.button>
                </div>
                {syncStatusMsg && (
                  <p className="text-xs text-neutral-300 pt-1">{syncStatusMsg.text}</p>
                )}
              </div>

              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-white">Clear Conversation History</p>
                  <p className="text-xs text-neutral-400 mt-0.5">Remove all messages on this device</p>
                </div>
                {confirmClearChat ? (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setConfirmClearChat(false)}
                      className="px-2.5 py-1 rounded-full bg-white/10 text-xs text-neutral-300"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        triggerHaptic(haptic, 12);
                        onClearHistory();
                        setConfirmClearChat(false);
                      }}
                      className="px-3 py-1 rounded-full bg-white text-black text-xs font-semibold"
                    >
                      Confirm
                    </button>
                  </div>
                ) : (
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setConfirmClearChat(true)}
                    className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-medium text-white flex items-center gap-1.5 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear</span>
                  </motion.button>
                )}
              </div>

              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-white">Clear Tasks & Notes</p>
                  <p className="text-xs text-neutral-400 mt-0.5">Reset productivity list</p>
                </div>
                {confirmClearTasks ? (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setConfirmClearTasks(false)}
                      className="px-2.5 py-1 rounded-full bg-white/10 text-xs text-neutral-300"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        triggerHaptic(haptic, 12);
                        onClearTasks();
                        setConfirmClearTasks(false);
                      }}
                      className="px-3 py-1 rounded-full bg-white text-black text-xs font-semibold"
                    >
                      Confirm
                    </button>
                  </div>
                ) : (
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setConfirmClearTasks(true)}
                    className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-medium text-white flex items-center gap-1.5 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear</span>
                  </motion.button>
                )}
              </div>
            </IOSGroupedSection>
          </div>

          {/* 6. AGENT PERMISSIONS */}
          <div
            ref={(el) => {
              sectionRefs.current.permissions = el;
            }}
            className="scroll-mt-4"
          >
            <IOSGroupedSection
              title="Agent Permissions"
              footer="Control which device capabilities and automations Ultron can access."
            >
              {[
                {
                  key: 'microphoneAccess' as keyof AgentPermissions,
                  icon: Mic,
                  title: 'Microphone Access',
                  desc: 'Allow live voice input and Voice Mode',
                },
                {
                  key: 'cameraAccess' as keyof AgentPermissions,
                  icon: Camera,
                  title: 'Camera Hardware',
                  desc: 'Allow Phone Actions camera preview & capture',
                },
                {
                  key: 'webSearchAccess' as keyof AgentPermissions,
                  icon: Globe,
                  title: 'Web Search & Links',
                  desc: 'Allow Ultron to launch searches and external links',
                },
                {
                  key: 'taskAutomation' as keyof AgentPermissions,
                  icon: CheckSquare,
                  title: 'Task Automation',
                  desc: 'Create tasks automatically from chat or voice',
                },
                {
                  key: 'backgroundSync' as keyof AgentPermissions,
                  icon: Cloud,
                  title: 'Background Cloud Sync',
                  desc: 'Keep conversations and tasks updated across devices',
                },
              ].map((perm) => {
                const Icon = perm.icon;
                return (
                  <div key={perm.key} className="px-4 py-3.5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-white/[0.08] border border-white/10 flex items-center justify-center shrink-0">
                        <Icon className="w-4 h-4 text-white" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-white">{perm.title}</p>
                        <p className="text-xs text-neutral-400 truncate">{perm.desc}</p>
                      </div>
                    </div>
                    <IOSSwitch
                      checked={permissions[perm.key]}
                      onChange={(val) => updatePermission(perm.key, val)}
                      ariaLabel={perm.title}
                      hapticEnabled={haptic}
                    />
                  </div>
                );
              })}
            </IOSGroupedSection>
          </div>

          {/* 7. ABOUT ULTRON */}
          <div
            ref={(el) => {
              sectionRefs.current.about = el;
            }}
            className="scroll-mt-4"
          >
            <IOSGroupedSection title="About ULTRON">
              <div className="p-4 flex items-center gap-3.5">
                <img
                  src="/assets/aistudio/Ultron_AI_Agent_Icon_f1242b8c.png"
                  alt="ULTRON AI"
                  className="w-14 h-14 rounded-2xl border border-white/20 object-cover shrink-0"
                />
                <div className="min-w-0">
                  <h4 className="text-base font-semibold tracking-tight text-white">ULTRON AI</h4>
                  <p className="text-xs text-neutral-400">
                    Monochrome Neural Agent · {platform} ({deviceType})
                  </p>
                  <p className="text-[11px] text-neutral-500 mt-0.5">
                    Default Engine: Ultron 3.1 Lite
                  </p>
                </div>
              </div>

              <div className="px-4 py-3.5 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-white">App Link</p>
                  <p className="text-xs text-neutral-400 font-mono truncate">{appUrl}</p>
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleCopyAppUrl}
                  className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-medium text-white flex items-center gap-1.5 transition shrink-0"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
                </motion.button>
              </div>

              <button
                type="button"
                onClick={() => {
                  triggerHaptic(haptic);
                  onOpenDownloadModal();
                }}
                className="w-full px-4 py-3.5 flex items-center justify-between gap-3 text-left hover:bg-white/[0.04] transition"
              >
                <div className="flex items-center gap-3">
                  <Download className="w-4 h-4 text-white" />
                  <div>
                    <p className="text-sm font-medium text-white">Install & Native Packages</p>
                    <p className="text-xs text-neutral-400">Android APK, Windows x64, and iOS Web App</p>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-neutral-400" />
              </button>

              <div className="px-4 py-3.5 flex items-center justify-between text-xs">
                <span className="text-neutral-400">Core Architecture</span>
                <span className="font-medium text-white">Coded by sibtain</span>
              </div>

              <div className="px-4 py-3.5 flex items-center justify-between text-xs">
                <span className="text-neutral-400">Assistant Core</span>
                <span className="font-medium text-white">assistant code by shreyash</span>
              </div>
            </IOSGroupedSection>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
