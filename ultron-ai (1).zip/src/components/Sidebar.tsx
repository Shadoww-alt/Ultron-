import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Home,
  MessageSquare,
  Plus,
  Search,
  CheckSquare,
  Mic,
  Settings,
  X,
  MoreVertical,
  Edit2,
  Trash2,
  RefreshCw,
  AppWindow,
  Check,
  User,
  Share2,
  Download,
} from 'lucide-react';
import { Conversation, ActiveScreen } from '../types';
import { SyncState } from '../services/cloudSync';
import { UserProfile } from '../services/firestoreSync';
import {
  IOS_SPRING_SNAPPY,
  modalBackdropVariants,
  modalSheetVariants,
  popoverVariants,
} from '../utils/motionSystem';
import { triggerHaptic } from './ios/IOSControls';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  conversations: Conversation[];
  activeConversationId: string;
  activeScreen: ActiveScreen;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onRenameConversation: (id: string, newTitle: string) => void;
  onDeleteConversation: (id: string) => void;
  onNavigateScreen: (screen: ActiveScreen) => void;
  onOpenSettings: (initialSection?: string) => void;
  onOpenDeviceApps: () => void;
  cloudSyncState: SyncState;
  lastSyncedAt: number | null;
  cloudSyncKey: string;
  onTriggerSync: () => void;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  appUrl: string;
  onOpenDownloadModal: () => void;
  hapticEnabled?: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  conversations,
  activeConversationId,
  activeScreen,
  searchQuery,
  onSearchChange,
  onSelectConversation,
  onNewConversation,
  onRenameConversation,
  onDeleteConversation,
  onNavigateScreen,
  onOpenSettings,
  onOpenDeviceApps,
  cloudSyncState,
  onTriggerSync,
  currentUser,
  onOpenAuth,
  appUrl,
  onOpenDownloadModal,
  hapticEnabled = true,
}) => {
  const [menuConvId, setMenuConvId] = useState<string | null>(null);
  const [editingConvId, setEditingConvId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState(false);

  const handleCopyUrl = () => {
    triggerHaptic(hapticEnabled);
    navigator.clipboard.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const filtered = conversations.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const groupConversations = (list: Conversation[]) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStart = today.getTime();
    const yesterdayStart = todayStart - 24 * 60 * 60 * 1000;
    const sevenDaysAgo = todayStart - 7 * 24 * 60 * 60 * 1000;

    const groups: { label: string; items: Conversation[] }[] = [
      { label: 'Today', items: [] },
      { label: 'Yesterday', items: [] },
      { label: 'Previous 7 Days', items: [] },
      { label: 'Older', items: [] },
    ];

    list.forEach((c) => {
      const time = c.updatedAt || c.createdAt;
      if (time >= todayStart) groups[0].items.push(c);
      else if (time >= yesterdayStart) groups[1].items.push(c);
      else if (time >= sevenDaysAgo) groups[2].items.push(c);
      else groups[3].items.push(c);
    });

    return groups.filter((g) => g.items.length > 0);
  };

  const grouped = groupConversations(filtered);

  const startRename = (conv: Conversation) => {
    setEditingConvId(conv.id);
    setEditTitle(conv.title);
    setMenuConvId(null);
  };

  const saveRename = (id: string) => {
    if (editTitle.trim()) {
      onRenameConversation(id, editTitle.trim());
    }
    setEditingConvId(null);
  };

  const navItems: { id: ActiveScreen; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'HOME', label: 'Home', icon: Home },
    { id: 'ASSISTANT', label: 'Chat', icon: MessageSquare },
    { id: 'VOICE_MODE', label: 'Voice', icon: Mic },
    { id: 'PRODUCTIVITY', label: 'Tasks', icon: CheckSquare },
    { id: 'SETTINGS', label: 'Settings', icon: Settings },
  ];

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            variants={modalBackdropVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={onClose}
            className="fixed inset-0 z-40 bg-black/75 backdrop-blur-sm lg:hidden"
          />
        )}
      </AnimatePresence>

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-[300px] bg-black/95 backdrop-blur-2xl border-r border-white/[0.08] flex flex-col transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] select-none ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
        style={{
          paddingTop: 'var(--sat)',
          paddingBottom: 'var(--sab)',
        }}
      >
        {/* Header */}
        <div className="p-4 border-b border-white/[0.08] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/Ultron_AI_Agent_Icon_f1242b8c.png"
              alt="ULTRON"
              className="w-10 h-10 rounded-2xl border border-white/20 bg-black object-cover"
            />
            <div>
              <h2 className="text-sm font-semibold tracking-[0.14em] text-white uppercase">ULTRON</h2>
              <p className="text-[11px] text-neutral-400">Personal AI Agent</p>
            </div>
          </div>
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={onClose}
            className="lg:hidden min-h-[36px] min-w-[36px] rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition flex items-center justify-center"
            aria-label="Close sidebar"
          >
            <X className="w-4 h-4" />
          </motion.button>
        </div>

        {/* New Chat & Search */}
        <div className="p-3 space-y-2 border-b border-white/[0.08]">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              triggerHaptic(hapticEnabled);
              onNewConversation();
              onNavigateScreen('ASSISTANT');
              if (window.innerWidth < 1024) onClose();
            }}
            className="w-full py-2.5 px-3.5 rounded-2xl bg-white text-black hover:bg-neutral-200 transition flex items-center justify-center gap-2 text-xs font-semibold"
          >
            <Plus className="w-4 h-4" />
            <span>New Thread</span>
          </motion.button>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search threads..."
              className="w-full py-2 pl-8 pr-3 bg-white/[0.05] text-white placeholder-neutral-500 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-white/30 transition"
            />
          </div>
        </div>

        {/* Conversation List */}
        <div className="flex-1 overflow-y-auto px-3 py-2.5 space-y-4">
          {grouped.length === 0 ? (
            <div className="text-center py-8 text-neutral-500 text-xs">
              {searchQuery ? 'No matching threads' : 'No threads yet'}
            </div>
          ) : (
            grouped.map((group) => (
              <div key={group.label} className="space-y-1">
                <p className="px-2.5 text-[11px] font-medium text-neutral-500">
                  {group.label}
                </p>
                {group.items.map((conv) => {
                  const isSelected = activeScreen === 'ASSISTANT' && conv.id === activeConversationId;
                  const isEditing = editingConvId === conv.id;

                  return (
                    <motion.div
                      key={conv.id}
                      layout="position"
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.18 }}
                      className={`group relative flex items-center justify-between rounded-xl px-2.5 py-2 text-xs transition cursor-pointer ${
                        isSelected
                          ? 'bg-white/15 text-white font-medium border border-white/20'
                          : 'text-neutral-300 hover:bg-white/[0.06] hover:text-white border border-transparent'
                      }`}
                      onClick={() => {
                        triggerHaptic(hapticEnabled, 5);
                        onSelectConversation(conv.id);
                        onNavigateScreen('ASSISTANT');
                        if (window.innerWidth < 1024) onClose();
                      }}
                    >
                      {isEditing ? (
                        <div
                          className="flex items-center gap-1.5 w-full"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <input
                            type="text"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') saveRename(conv.id);
                              if (e.key === 'Escape') setEditingConvId(null);
                            }}
                            autoFocus
                            className="flex-1 bg-black text-white text-xs px-2 py-1 rounded-lg border border-white/40 focus:outline-none"
                          />
                          <button
                            onClick={() => saveRename(conv.id)}
                            className="p-1 text-white"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-2 min-w-0 flex-1 pr-2">
                            <MessageSquare className="w-3.5 h-3.5 shrink-0 opacity-60" />
                            <span className="truncate">{conv.title}</span>
                          </div>

                          <div className="relative shrink-0" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => setMenuConvId(menuConvId === conv.id ? null : conv.id)}
                              className="p-1 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-white/10 transition text-neutral-400 hover:text-white"
                              aria-label="Thread options"
                            >
                              <MoreVertical className="w-3.5 h-3.5" />
                            </button>

                            <AnimatePresence>
                              {menuConvId === conv.id && (
                                <motion.div
                                  variants={popoverVariants}
                                  initial="hidden"
                                  animate="visible"
                                  exit="exit"
                                  className="absolute right-0 top-full mt-1 w-32 rounded-xl ios-glass-elevated p-1 z-30 origin-top-right"
                                >
                                  <button
                                    onClick={() => startRename(conv)}
                                    className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-neutral-200 hover:bg-white/10 rounded-lg transition text-left"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                    <span>Rename</span>
                                  </button>
                                  <button
                                    onClick={() => {
                                      setDeleteConfirmId(conv.id);
                                      setMenuConvId(null);
                                    }}
                                    className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-neutral-300 hover:bg-white/10 hover:text-white rounded-lg transition text-left"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                    <span>Delete</span>
                                  </button>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        </>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            ))
          )}
        </div>

        {/* Delete Confirmation Modal */}
        <AnimatePresence>
          {deleteConfirmId && (
            <motion.div
              variants={modalBackdropVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
            >
              <motion.div
                variants={modalSheetVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className="w-full max-w-xs rounded-3xl ios-glass-elevated p-5 text-white"
              >
                <h3 className="text-sm font-semibold">Delete Thread?</h3>
                <p className="mt-1 text-xs text-neutral-400">This action cannot be undone.</p>
                <div className="mt-4 flex gap-2 justify-end">
                  <motion.button
                    whileTap={{ scale: 0.96 }}
                    onClick={() => setDeleteConfirmId(null)}
                    className="px-3.5 py-1.5 text-xs rounded-full border border-white/15 hover:bg-white/10 text-neutral-300"
                  >
                    Cancel
                  </motion.button>
                  <motion.button
                    whileTap={{ scale: 0.96 }}
                    onClick={() => {
                      triggerHaptic(hapticEnabled, 10);
                      onDeleteConversation(deleteConfirmId);
                      setDeleteConfirmId(null);
                    }}
                    className="px-3.5 py-1.5 text-xs rounded-full bg-white text-black hover:bg-neutral-200 font-semibold"
                  >
                    Delete
                  </motion.button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation Links */}
        <div className="p-3 border-t border-white/[0.08] space-y-1 bg-black/60">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            return (
              <motion.button
                key={item.id}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  triggerHaptic(hapticEnabled, 5);
                  if (item.id === 'SETTINGS') {
                    onOpenSettings();
                  } else {
                    onNavigateScreen(item.id);
                  }
                  if (window.innerWidth < 1024) onClose();
                }}
                className={`relative w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                  isActive ? 'text-white' : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="sidebarNavPill"
                    transition={IOS_SPRING_SNAPPY}
                    className="absolute inset-0 rounded-xl bg-white/15 border border-white/15"
                  />
                )}
                <Icon className="w-4 h-4 relative z-10" />
                <span className="relative z-10">{item.label}</span>
              </motion.button>
            );
          })}

          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => {
              triggerHaptic(hapticEnabled);
              onOpenDeviceApps();
              if (window.innerWidth < 1024) onClose();
            }}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-neutral-400 hover:text-white hover:bg-white/5 transition"
          >
            <AppWindow className="w-4 h-4" />
            <span>Phone Actions</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => {
              triggerHaptic(hapticEnabled);
              onOpenDownloadModal();
              if (window.innerWidth < 1024) onClose();
            }}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-neutral-300 hover:text-white hover:bg-white/[0.08] border border-white/10 transition"
          >
            <Download className="w-4 h-4" />
            <span>Download APK & PC App</span>
          </motion.button>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-white/[0.08] bg-black space-y-2">
          <div className="flex items-center justify-between">
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-2 text-left min-w-0 flex-1 hover:opacity-80 transition"
            >
              <div className="w-7 h-7 rounded-full bg-white/10 border border-white/15 flex items-center justify-center shrink-0">
                <User className="w-3.5 h-3.5 text-white" />
              </div>
              <div className="truncate pr-1">
                <p className="text-xs font-semibold text-white truncate">
                  {currentUser ? (currentUser.isGuest ? 'Guest Trial' : currentUser.displayName || 'User') : 'Not Connected'}
                </p>
                <p className="text-[10px] text-neutral-400 font-mono truncate">
                  {currentUser ? (currentUser.isGuest ? '10m Trial Session' : currentUser.email) : 'Sign in with @gmail'}
                </p>
              </div>
            </button>

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={onOpenAuth}
              className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-white text-[11px] font-medium border border-white/15 transition shrink-0"
            >
              {currentUser?.isGuest ? 'Upgrade' : currentUser ? 'Account' : 'Login'}
            </motion.button>
          </div>

          <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-neutral-400">
            <button
              onClick={handleCopyUrl}
              className="flex items-center gap-1.5 hover:text-white transition truncate max-w-[180px]"
            >
              <Share2 className="w-3 h-3 shrink-0" />
              <span className="truncate text-[11px]">
                {copiedUrl ? 'Link Copied' : 'Share Link'}
              </span>
            </button>

            <button
              onClick={() => {
                triggerHaptic(hapticEnabled);
                onTriggerSync();
              }}
              className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white transition flex items-center gap-1"
              title="Sync with cloud now"
            >
              <RefreshCw className={`w-3 h-3 ${cloudSyncState === 'syncing' ? 'animate-spin' : ''}`} />
              <span className="font-mono text-[10px] capitalize">{cloudSyncState}</span>
            </button>
          </div>

          <div className="pt-2 border-t border-white/5 text-center">
            <p className="text-[10px] text-neutral-500 font-mono tracking-tight leading-tight">
              Coded by <span className="text-white font-medium">sibtain</span> · Assistant code by <span className="text-white font-medium">shreyash</span>
            </p>
          </div>
        </div>
      </aside>
    </>
  );
};
