import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckSquare,
  Plus,
  Trash2,
  Bot,
  Search,
  ArrowLeft,
  BookOpen,
  FolderGit2,
  FileText,
  CheckCircle2,
  Check,
  X,
} from 'lucide-react';
import { ProductivityTask } from '../types';
import {
  taskItemVariants,
  modalBackdropVariants,
  modalSheetVariants,
  IOS_SPRING,
  IOS_SPRING_SNAPPY,
} from '../utils/motionSystem';
import { triggerHaptic } from './ios/IOSControls';

interface ProductivityViewProps {
  tasks: ProductivityTask[];
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onAddTask: (title: string, category: ProductivityTask['category'], description?: string) => void;
  onAskUltron: (taskTitle: string) => void;
  onBack: () => void;
  hapticEnabled?: boolean;
}

export const ProductivityView: React.FC<ProductivityViewProps> = ({
  tasks,
  onToggleTask,
  onDeleteTask,
  onAddTask,
  onAskUltron,
  onBack,
  hapticEnabled = true,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [quickTitle, setQuickTitle] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCat, setNewCat] = useState<ProductivityTask['category']>('Task');

  const categories = ['All', 'Task', 'Learning', 'Project', 'Note'];

  const filteredTasks = tasks.filter((t) => {
    const matchesCat = selectedCategory === 'All' || t.category === selectedCategory;
    const matchesSearch =
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const activeCount = tasks.filter((t) => !t.isCompleted).length;
  const completedCount = tasks.filter((t) => t.isCompleted).length;

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTitle.trim()) return;
    triggerHaptic(hapticEnabled);
    const targetCategory: ProductivityTask['category'] =
      selectedCategory === 'All' ? 'Task' : (selectedCategory as ProductivityTask['category']);
    onAddTask(quickTitle.trim(), targetCategory);
    setQuickTitle('');
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    triggerHaptic(hapticEnabled);
    onAddTask(newTitle.trim(), newCat, newDesc.trim());
    setNewTitle('');
    setNewDesc('');
    setIsAddOpen(false);
  };

  const getCategoryMeta = (cat: ProductivityTask['category']) => {
    switch (cat) {
      case 'Learning':
        return { label: 'Learning', icon: BookOpen };
      case 'Project':
        return { label: 'Project', icon: FolderGit2 };
      case 'Note':
        return { label: 'Note', icon: FileText };
      case 'Task':
      default:
        return { label: 'Task', icon: CheckCircle2 };
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-black text-white overflow-hidden select-none">
      {/* Top Bar */}
      <header
        className="px-4 sm:px-6 py-3 border-b border-white/10 flex items-center justify-between gap-3 bg-black/75 backdrop-blur-2xl shrink-0"
        style={{ paddingTop: 'max(0.75rem, var(--sat))' }}
      >
        <div className="flex items-center gap-3 min-w-0">
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => {
              triggerHaptic(hapticEnabled);
              onBack();
            }}
            className="min-h-[38px] min-w-[38px] rounded-full ios-glass text-neutral-300 hover:text-white transition flex items-center justify-center shrink-0"
            aria-label="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </motion.button>
          <div className="min-w-0">
            <h1 className="text-base font-semibold tracking-tight truncate">Tasks & Notes</h1>
            <p className="text-xs text-neutral-400 tabular-nums">
              {activeCount} active · {completedCount} completed · {tasks.length} total
            </p>
          </div>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => {
            triggerHaptic(hapticEnabled);
            setIsAddOpen(true);
          }}
          className="min-h-[38px] px-4 py-1.5 rounded-full bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition flex items-center gap-1.5 shadow-lg whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New</span>
        </motion.button>
      </header>

      {/* Segmented Category Filter, Search & Quick Add */}
      <div className="px-4 sm:px-6 py-3 border-b border-white/[0.08] space-y-3 bg-black/50 backdrop-blur-md shrink-0">
        <div className="max-w-3xl mx-auto space-y-3">
          <div className="flex items-center gap-1 p-1 rounded-2xl bg-white/[0.06] border border-white/10 overflow-x-auto no-scrollbar">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => {
                    triggerHaptic(hapticEnabled, 5);
                    setSelectedCategory(cat);
                  }}
                  className={`relative px-3.5 py-1.5 rounded-xl text-xs font-medium transition-colors shrink-0 ${
                    isActive ? 'text-black font-semibold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="productivityCategoryPill"
                      transition={IOS_SPRING_SNAPPY}
                      className="absolute inset-0 rounded-xl bg-white shadow-sm"
                    />
                  )}
                  <span className="relative z-10">{cat}</span>
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tasks and notes..."
                className="w-full py-2.5 pl-9 pr-3 bg-white/[0.05] text-white placeholder-neutral-500 rounded-2xl border border-white/10 text-xs focus:outline-none focus:border-white/30 transition"
              />
            </div>

            <form onSubmit={handleQuickAdd} className="flex items-center gap-2">
              <input
                type="text"
                value={quickTitle}
                onChange={(e) => setQuickTitle(e.target.value)}
                placeholder={`Quick add ${selectedCategory === 'All' ? 'task' : selectedCategory.toLowerCase()}...`}
                className="flex-1 py-2.5 px-3.5 bg-white/[0.05] text-white placeholder-neutral-500 rounded-2xl border border-white/10 text-xs focus:outline-none focus:border-white/30 transition"
              />
              <motion.button
                whileTap={{ scale: 0.94 }}
                type="submit"
                disabled={!quickTitle.trim()}
                className="min-h-[38px] px-4 py-2 rounded-2xl bg-white/15 hover:bg-white/25 disabled:opacity-35 text-white text-xs font-medium border border-white/15 transition shrink-0"
              >
                Add
              </motion.button>
            </form>
          </div>
        </div>
      </div>

      {/* Animated Monochrome Task List */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-4">
        <div className="max-w-3xl mx-auto space-y-2.5">
          {filteredTasks.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={IOS_SPRING}
              className="text-center py-16 text-neutral-500 space-y-2"
            >
              <CheckSquare className="w-10 h-10 mx-auto opacity-30" />
              <p className="text-sm font-medium text-neutral-300">No items found</p>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Add an item above or tell Ultron: &ldquo;Add task: Review release deployment&rdquo;.
              </p>
            </motion.div>
          ) : (
            <AnimatePresence mode="popLayout" initial={false}>
              {filteredTasks.map((item, index) => {
                const meta = getCategoryMeta(item.category);
                const Icon = meta.icon;

                return (
                  <motion.div
                    key={item.id}
                    layout
                    custom={index}
                    variants={taskItemVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    className={`p-3.5 sm:p-4 rounded-[22px] border transition-colors flex items-start gap-3 ${
                      item.isCompleted
                        ? 'bg-neutral-950/70 border-white/[0.06] opacity-55'
                        : 'ios-glass-card hover:border-white/20'
                    }`}
                  >
                    {/* Monochrome Completion Circle */}
                    <motion.button
                      whileTap={{ scale: 0.84 }}
                      onClick={() => {
                        triggerHaptic(hapticEnabled, 7);
                        onToggleTask(item.id);
                      }}
                      className={`mt-0.5 w-6 h-6 rounded-full border flex items-center justify-center transition-colors shrink-0 ${
                        item.isCompleted
                          ? 'bg-white border-white text-black'
                          : 'border-white/30 hover:border-white text-transparent hover:bg-white/5'
                      }`}
                      aria-label={item.isCompleted ? 'Mark incomplete' : 'Mark complete'}
                    >
                      <motion.span
                        initial={false}
                        animate={{ scale: item.isCompleted ? 1 : 0, opacity: item.isCompleted ? 1 : 0 }}
                        transition={IOS_SPRING_SNAPPY}
                      >
                        <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                      </motion.span>
                    </motion.button>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 text-[11px] text-neutral-400 mb-1">
                        <Icon className="w-3 h-3 text-neutral-300" />
                        <span className="font-medium text-neutral-300">{meta.label}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums text-neutral-500">
                          {new Date(item.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      <p
                        className={`text-xs sm:text-sm font-medium text-white transition-colors ${
                          item.isCompleted ? 'line-through text-neutral-500' : ''
                        }`}
                      >
                        {item.title}
                      </p>

                      {item.description && (
                        <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                          {item.description}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => {
                          triggerHaptic(hapticEnabled);
                          onAskUltron(`Help me solve and execute this task: "${item.title}"`);
                        }}
                        className="min-h-[36px] min-w-[36px] rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 transition flex items-center justify-center"
                        title="Ask Ultron"
                        aria-label="Ask Ultron"
                      >
                        <Bot className="w-4 h-4" />
                      </motion.button>
                      <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => {
                          triggerHaptic(hapticEnabled, 10);
                          onDeleteTask(item.id);
                        }}
                        className="min-h-[36px] min-w-[36px] rounded-xl text-neutral-500 hover:text-white hover:bg-white/10 transition flex items-center justify-center"
                        title="Delete task"
                        aria-label="Delete task"
                      >
                        <Trash2 className="w-4 h-4" />
                      </motion.button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>
      </div>

      {/* Add Task Modal */}
      <AnimatePresence>
        {isAddOpen && (
          <motion.div
            variants={modalBackdropVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={() => setIsAddOpen(false)}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
          >
            <motion.form
              variants={modalSheetVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              onClick={(e) => e.stopPropagation()}
              onSubmit={handleCreate}
              className="w-full max-w-md ios-glass-elevated rounded-3xl p-5 space-y-4 text-white"
            >
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <h3 className="text-sm font-semibold">New Entry</h3>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition"
                >
                  <X className="w-4 h-4" />
                </motion.button>
              </div>

              <div>
                <label className="text-xs text-neutral-300 block mb-1.5">Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="What do you want to accomplish?"
                  autoFocus
                  required
                  className="w-full py-2.5 px-3.5 bg-white/[0.06] border border-white/15 rounded-2xl text-xs text-white focus:outline-none focus:border-white/50"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-300 block mb-1.5">Category</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {(['Task', 'Learning', 'Project', 'Note'] as ProductivityTask['category'][]).map((cat) => (
                    <motion.button
                      key={cat}
                      whileTap={{ scale: 0.96 }}
                      type="button"
                      onClick={() => setNewCat(cat)}
                      className={`py-2 text-xs rounded-xl border font-medium transition ${
                        newCat === cat
                          ? 'bg-white text-black border-white font-semibold'
                          : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {cat}
                    </motion.button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-neutral-300 block mb-1.5">Notes (Optional)</label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Details or context..."
                  rows={3}
                  className="w-full p-3 bg-white/[0.06] border border-white/15 rounded-2xl text-xs text-white focus:outline-none focus:border-white/50 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 rounded-full border border-white/15 text-xs text-neutral-300 hover:text-white hover:bg-white/5 transition"
                >
                  Cancel
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  type="submit"
                  className="px-4 py-2 rounded-full bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition"
                >
                  Create
                </motion.button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
