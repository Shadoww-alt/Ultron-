import React from 'react';
import { motion } from 'motion/react';
import { Home, MessageSquare, Mic, CheckSquare, Settings } from 'lucide-react';
import { ActiveScreen } from '../types';
import { IOS_SPRING_SNAPPY } from '../utils/motionSystem';
import { triggerHaptic } from './ios/IOSControls';

interface FloatingBottomNavProps {
  activeScreen: ActiveScreen;
  onNavigate: (screen: ActiveScreen) => void;
  hapticEnabled?: boolean;
}

export const FloatingBottomNav: React.FC<FloatingBottomNavProps> = ({
  activeScreen,
  onNavigate,
  hapticEnabled = true,
}) => {
  const items: {
    id: ActiveScreen;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    { id: 'HOME', label: 'Home', icon: Home },
    { id: 'ASSISTANT', label: 'Chat', icon: MessageSquare },
    { id: 'VOICE_MODE', label: 'Voice', icon: Mic },
    { id: 'PRODUCTIVITY', label: 'Tasks', icon: CheckSquare },
    { id: 'SETTINGS', label: 'Settings', icon: Settings },
  ];

  return (
    <div
      className="w-full px-3 pt-1 pb-3 flex justify-center z-30 shrink-0 pointer-events-none"
      style={{ paddingBottom: 'max(0.75rem, var(--sab))' }}
    >
      <nav
        aria-label="Primary navigation"
        className="pointer-events-auto ios-glass-elevated rounded-full p-1.5 flex items-center gap-1 max-w-md w-full sm:w-auto shadow-[0_16px_44px_rgba(0,0,0,0.75)]"
      >
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = activeScreen === item.id;

          return (
            <motion.button
              key={item.id}
              type="button"
              whileTap={{ scale: 0.92 }}
              onClick={() => {
                triggerHaptic(hapticEnabled, 6);
                onNavigate(item.id);
              }}
              className={`relative flex-1 sm:flex-initial sm:min-w-[74px] min-h-[44px] px-3 py-1.5 rounded-full flex flex-col items-center justify-center gap-0.5 transition-colors whitespace-nowrap shrink-0 ${
                isActive ? 'text-black' : 'text-neutral-400 hover:text-white'
              }`}
              aria-current={isActive ? 'page' : undefined}
            >
              {isActive && (
                <motion.span
                  layoutId="iosFloatingNavPill"
                  transition={IOS_SPRING_SNAPPY}
                  className="absolute inset-0 rounded-full bg-white shadow-[0_2px_12px_rgba(255,255,255,0.22)]"
                />
              )}
              <Icon className="w-[18px] h-[18px] relative z-10 stroke-[2]" />
              <span className="text-[10px] font-semibold tracking-tight relative z-10">
                {item.label}
              </span>
            </motion.button>
          );
        })}
      </nav>
    </div>
  );
};
