import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Mic, MicOff, Volume2, Send } from 'lucide-react';
import { QuantumCoreVisualizer } from './QuantumCoreVisualizer';
import { UltronCoreState, ChatMessage } from '../types';
import { chatBubbleVariants, IOS_SPRING } from '../utils/motionSystem';
import { triggerHaptic } from './ios/IOSControls';

interface VoiceModeViewProps {
  coreState: UltronCoreState;
  audioAmplitude: number;
  latestUltronMessage?: ChatMessage | null;
  onSendVoiceQuery: (query: string) => void;
  onStartVoice: (onPartial: (text: string) => void, onEnd: (text: string) => void) => Promise<boolean>;
  onStopVoice: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  onBack: () => void;
  hapticEnabled?: boolean;
}

export const VoiceModeView: React.FC<VoiceModeViewProps> = ({
  coreState,
  audioAmplitude,
  latestUltronMessage,
  onSendVoiceQuery,
  onStartVoice,
  onStopVoice,
  isListening,
  isSpeaking,
  onBack,
  hapticEnabled = true,
}) => {
  const [transcription, setTranscription] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;

    const startSession = async () => {
      setErrorMessage(null);
      const ok = await onStartVoice(
        (partial) => {
          if (isMountedRef.current) setTranscription(partial);
        },
        (finalText) => {
          if (isMountedRef.current) {
            setTranscription(finalText);
            onSendVoiceQuery(finalText);
          }
        }
      );
      if (!ok && isMountedRef.current) {
        setErrorMessage('Microphone access is unavailable. Please check browser permissions.');
      }
    };

    startSession();

    return () => {
      isMountedRef.current = false;
      onStopVoice();
    };
  }, []);

  useEffect(() => {
    if (!isSpeaking && coreState === 'IDLE' && !isListening && isMountedRef.current) {
      const timer = setTimeout(() => {
        if (!isListening && !isSpeaking && isMountedRef.current) {
          onStartVoice(
            (partial) => {
              if (isMountedRef.current) setTranscription(partial);
            },
            (finalText) => {
              if (isMountedRef.current) {
                setTranscription(finalText);
                onSendVoiceQuery(finalText);
              }
            }
          );
        }
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isSpeaking, coreState, isListening]);

  const handleToggleMute = async () => {
    triggerHaptic(hapticEnabled, 10);
    if (isListening) {
      onStopVoice();
    } else {
      setErrorMessage(null);
      setTranscription('');
      const ok = await onStartVoice(
        (partial) => {
          if (isMountedRef.current) setTranscription(partial);
        },
        (finalText) => {
          if (isMountedRef.current) {
            setTranscription(finalText);
            onSendVoiceQuery(finalText);
          }
        }
      );
      if (!ok) {
        setErrorMessage('Could not activate microphone.');
      }
    }
  };

  const handleCommitNow = () => {
    if (transcription.trim()) {
      triggerHaptic(hapticEnabled);
      const text = transcription.trim();
      setTranscription('');
      onSendVoiceQuery(text);
    }
  };

  const statusKey = errorMessage
    ? 'error'
    : transcription
    ? 'transcription'
    : isSpeaking && latestUltronMessage
    ? 'speaking'
    : isListening
    ? 'listening'
    : 'muted';

  return (
    <div className="flex-1 flex flex-col h-full bg-black text-white relative overflow-hidden select-none">
      {/* Top Bar */}
      <div
        className="px-4 sm:px-6 py-3 flex items-center justify-between z-20"
        style={{ paddingTop: 'max(0.75rem, var(--sat))' }}
      >
        <motion.button
          whileTap={{ scale: 0.94 }}
          onClick={() => {
            triggerHaptic(hapticEnabled);
            onStopVoice();
            onBack();
          }}
          className="min-h-[38px] px-3.5 py-1.5 rounded-full ios-glass hover:bg-white/15 text-white transition flex items-center gap-2 text-xs font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </motion.button>

        <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full ios-glass text-xs font-medium">
          <span
            className={`w-2 h-2 rounded-full bg-white ${
              isListening || isSpeaking ? 'animate-ping' : 'opacity-60'
            }`}
          />
          <span>
            {coreState === 'LISTENING'
              ? 'Listening'
              : coreState === 'THINKING'
              ? 'Thinking'
              : coreState === 'SPEAKING'
              ? 'Speaking'
              : isListening
              ? 'Ready'
              : 'Muted'}
          </span>
        </div>
      </div>

      {/* Central Monochrome Liquid Glass Core */}
      <div className="flex-1 flex flex-col items-center justify-center relative p-6">
        <QuantumCoreVisualizer
          state={coreState}
          audioAmplitude={audioAmplitude}
          onClick={handleToggleMute}
          className="w-60 sm:w-76 md:w-88 h-60 sm:h-76 md:h-88 cursor-pointer"
        />

        {/* Smoothly Animated Transcription / Speech Display */}
        <div className="mt-5 max-w-lg w-full min-h-[96px] text-center flex flex-col items-center justify-center px-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={statusKey}
              variants={chatBubbleVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="w-full flex flex-col items-center"
            >
              {errorMessage ? (
                <p className="text-xs text-neutral-200 ios-glass p-3.5 rounded-2xl">
                  {errorMessage}
                </p>
              ) : transcription ? (
                <div className="space-y-2.5">
                  <span className="text-xs text-neutral-400">You are saying</span>
                  <p className="text-lg sm:text-xl font-light text-white leading-relaxed">
                    &ldquo;{transcription}&rdquo;
                  </p>
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={handleCommitNow}
                    className="mt-1 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full ios-glass hover:bg-white/15 text-white text-xs transition"
                  >
                    <Send className="w-3 h-3" />
                    <span>Send now</span>
                  </motion.button>
                </div>
              ) : isSpeaking && latestUltronMessage ? (
                <div className="space-y-2 max-h-36 overflow-y-auto ios-glass-card rounded-3xl px-5 py-3.5">
                  <span className="text-xs text-neutral-300 flex items-center justify-center gap-1.5 font-medium">
                    <Volume2 className="w-3.5 h-3.5" />
                    Ultron Speaking
                  </span>
                  <p className="text-sm sm:text-base text-white leading-relaxed font-normal">
                    {latestUltronMessage.content}
                  </p>
                </div>
              ) : isListening ? (
                <div className="space-y-1 text-neutral-400 text-xs">
                  <p className="text-white font-medium">Microphone Live</p>
                  <p className="text-xs text-neutral-400">Speak naturally at your own pace...</p>
                </div>
              ) : (
                <p className="text-xs sm:text-sm text-neutral-500">
                  Microphone paused. Tap below to resume.
                </p>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Bottom Monochrome Voice Controls */}
      <div className="p-4 pb-5 flex flex-col items-center justify-center gap-2 z-20">
        <motion.button
          whileTap={{ scale: 0.9 }}
          transition={IOS_SPRING}
          onClick={handleToggleMute}
          className={`w-16 h-16 rounded-full flex items-center justify-center border transition shadow-2xl ${
            isListening
              ? 'bg-white text-black border-white shadow-[0_0_30px_rgba(255,255,255,0.25)]'
              : 'ios-glass text-white border-white/25 hover:bg-white/15'
          }`}
          aria-label={isListening ? 'Mute microphone' : 'Unmute microphone'}
        >
          {isListening ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
        </motion.button>

        <span className="text-xs text-neutral-400">
          {isListening ? 'Listening · Tap to Mute' : 'Muted · Tap to Speak'}
        </span>
      </div>
    </div>
  );
};
