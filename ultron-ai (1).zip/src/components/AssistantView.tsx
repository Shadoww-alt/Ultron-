import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Menu,
  Mic,
  MicOff,
  ArrowUp,
  Volume2,
  Copy,
  Check,
  X,
  ExternalLink,
  ChevronDown,
  Paperclip,
  Camera,
  FileText,
  Plus,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import { QuantumCoreVisualizer } from './QuantumCoreVisualizer';
import { UltronCoreState, ChatMessage, AppSettings } from '../types';
import {
  chatBubbleVariants,
  popoverVariants,
  IOS_SPRING,
  IOS_SPRING_SNAPPY,
} from '../utils/motionSystem';
import { triggerHaptic } from './ios/IOSControls';

interface AssistantViewProps {
  onOpenSidebar: () => void;
  coreState: UltronCoreState;
  audioAmplitude: number;
  messages: ChatMessage[];
  latestUltronMessage?: ChatMessage | null;
  onSendMessage: (text: string) => void;
  onNewConversation: () => void;
  onStartVoice: (onPartial: (text: string) => void, onEnd: (text: string) => void) => Promise<boolean>;
  onStopVoice: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  onSpeakText: (text: string) => void;
  onOpenDeviceApps: (appId?: string) => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onOpenAuth: () => void;
  isTrialExpired: boolean;
  onOpenVoiceMode: () => void;
}

export const AssistantView: React.FC<AssistantViewProps> = ({
  onOpenSidebar,
  coreState,
  audioAmplitude,
  messages,
  onSendMessage,
  onNewConversation,
  onStartVoice,
  onStopVoice,
  isListening,
  isSpeaking,
  onSpeakText,
  onOpenDeviceApps,
  settings,
  onUpdateSettings,
  onOpenAuth,
  isTrialExpired,
  onOpenVoiceMode,
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isModelDropdownOpen, setIsModelDropdownOpen] = useState(false);
  const [isAttachMenuOpen, setIsAttachMenuOpen] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ name: string; content: string } | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const haptic = settings.hapticFeedback ?? true;

  const availableModels = [
    { id: 'gemini-3.1-flash-lite', label: '3.1 Lite', desc: 'Default · Fastest' },
    { id: 'gemini-3.8-flash', label: '3.8 Flash', desc: 'Balanced' },
    { id: 'gemini-3.1-pro-preview', label: '3.1 Pro', desc: 'Deep Reasoning' },
  ];

  const currentModelObj =
    availableModels.find((m) => m.id === settings.geminiModel) || availableModels[0];

  const formatModelLabel = (modelId?: string) => {
    if (!modelId) return 'Ultron 3.1 Lite';
    switch (modelId) {
      case 'gemini-3.1-flash-lite':
      case 'ultron-3.1-lite':
        return 'Ultron 3.1 Lite';
      case 'gemini-3.8-flash':
        return 'Ultron 3.8 Flash';
      case 'gemini-3.1-pro-preview':
        return 'Ultron 3.1 Pro';
      case 'gemini-flash-latest':
        return 'Ultron Flash';
      default:
        return modelId.replace(/gemini/gi, 'ultron');
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, coreState]);

  const handleSend = () => {
    const raw = inputText.trim();
    if (!raw && !attachedFile) return;

    triggerHaptic(haptic, 8);

    const payload = attachedFile
      ? `${raw ? raw + '\n\n' : ''}[Attached file: ${attachedFile.name}]\n${attachedFile.content.slice(0, 4000)}`
      : raw;

    setInputText('');
    setAttachedFile(null);
    onSendMessage(payload);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleToggleVoice = async () => {
    triggerHaptic(haptic, 10);
    if (isListening) {
      onStopVoice();
    } else {
      await onStartVoice(
        (partial) => {
          setInputText(partial);
        },
        (finalText) => {
          setInputText('');
          onSendMessage(finalText);
        }
      );
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    triggerHaptic(haptic, 6);
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId((prev) => (prev === id ? null : prev)), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      setAttachedFile({ name: file.name, content: content || `(Binary file: ${file.name})` });
    };
    reader.readAsText(file);
    e.target.value = '';
    setIsAttachMenuOpen(false);
  };

  const formatTime = (ts: number) =>
    new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const canSend = Boolean(inputText.trim() || attachedFile);

  return (
    <div className="flex-1 flex flex-col h-full bg-black text-white relative overflow-hidden select-none">
      {/* Hidden File Input for Attachments */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".txt,.md,.json,.ts,.tsx,.js,.jsx,.py,.csv,.html,.css,.log"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* 1. COMPACT iOS 20 MESSAGING HEADER */}
      <header
        className="w-full px-3.5 sm:px-6 py-2.5 flex items-center justify-between gap-2 border-b border-white/[0.08] bg-black/75 backdrop-blur-2xl z-20 shrink-0"
        style={{ paddingTop: 'max(0.625rem, var(--sat))' }}
      >
        {/* Left: Drawer & Mini Living Orb */}
        <div className="flex items-center gap-2.5 min-w-0">
          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => {
              triggerHaptic(haptic);
              onOpenSidebar();
            }}
            className="lg:hidden min-h-[38px] min-w-[38px] rounded-full ios-glass text-white flex items-center justify-center shrink-0"
            aria-label="Open conversation list"
          >
            <Menu className="w-4 h-4" />
          </motion.button>

          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-full bg-white/[0.04] border border-white/15 flex items-center justify-center overflow-hidden shrink-0">
              <QuantumCoreVisualizer
                state={coreState}
                audioAmplitude={audioAmplitude}
                onClick={onOpenVoiceMode}
                className="w-9 h-9"
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-semibold tracking-tight text-white">ULTRON</span>
                <span
                  className={`w-1.5 h-1.5 rounded-full bg-white ${
                    isListening || isSpeaking || coreState === 'THINKING' ? 'animate-ping' : 'opacity-60'
                  }`}
                />
              </div>
              <p className="text-[11px] text-neutral-400 truncate">
                {coreState === 'THINKING'
                  ? 'Thinking...'
                  : coreState === 'LISTENING'
                  ? 'Listening...'
                  : coreState === 'SPEAKING'
                  ? 'Speaking...'
                  : currentModelObj.label}
              </p>
            </div>
          </div>
        </div>

        {/* Right: Model Switcher & New Chat */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="relative">
            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                triggerHaptic(haptic);
                setIsModelDropdownOpen((v) => !v);
              }}
              className="min-h-[36px] px-3 py-1.5 rounded-full ios-glass text-xs font-medium text-neutral-200 hover:text-white flex items-center gap-1.5 transition whitespace-nowrap"
              title="Switch neural model"
            >
              <span>{currentModelObj.label}</span>
              <ChevronDown
                className={`w-3 h-3 text-neutral-400 transition-transform duration-200 ${
                  isModelDropdownOpen ? 'rotate-180' : ''
                }`}
              />
            </motion.button>

            <AnimatePresence>
              {isModelDropdownOpen && (
                <>
                  <div onClick={() => setIsModelDropdownOpen(false)} className="fixed inset-0 z-30" />
                  <motion.div
                    variants={popoverVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    className="absolute right-0 mt-2 w-56 rounded-2xl ios-glass-elevated p-1.5 z-40 origin-top-right space-y-1"
                  >
                    <div className="px-3 py-1.5 text-[11px] font-medium text-neutral-400 border-b border-white/10">
                      Neural Model
                    </div>
                    {availableModels.map((m) => {
                      const isSelected = settings.geminiModel === m.id;
                      return (
                        <button
                          key={m.id}
                          onClick={() => {
                            triggerHaptic(haptic);
                            onUpdateSettings({
                              geminiModel: m.id,
                              thinkingMode: m.id === 'gemini-3.1-pro-preview',
                            });
                            setIsModelDropdownOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-left transition ${
                            isSelected
                              ? 'bg-white/15 text-white font-semibold'
                              : 'text-neutral-300 hover:bg-white/[0.06] hover:text-white'
                          }`}
                        >
                          <div>
                            <p className="text-xs">{m.label}</p>
                            <p className="text-[11px] text-neutral-400">{m.desc}</p>
                          </div>
                          {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                        </button>
                      );
                    })}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => {
              triggerHaptic(haptic);
              onNewConversation();
            }}
            className="min-h-[36px] min-w-[36px] rounded-full ios-glass text-white flex items-center justify-center hover:bg-white/15 transition"
            title="New conversation"
            aria-label="New conversation"
          >
            <Plus className="w-4 h-4" />
          </motion.button>
        </div>
      </header>

      {/* 2. SCROLLABLE iOS MESSAGE STREAM */}
      <div className="flex-1 overflow-y-auto px-3.5 sm:px-6 py-4">
        <div className="max-w-3xl mx-auto space-y-3.5">
          {messages.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={IOS_SPRING}
              className="py-16 text-center space-y-2"
            >
              <p className="text-sm font-medium text-white">Start a conversation with Ultron</p>
              <p className="text-xs text-neutral-500">Type below, attach a file, or tap the mic.</p>
            </motion.div>
          )}

          <AnimatePresence initial={false}>
            {messages.map((msg) => {
              const isUser = msg.sender === 'USER';

              return (
                <motion.div
                  key={msg.id}
                  layout="position"
                  variants={chatBubbleVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  {isUser ? (
                    <div className="max-w-[82%] sm:max-w-[70%] rounded-[22px] rounded-br-[6px] bg-white text-black px-4 py-2.5 shadow-[0_8px_24px_rgba(255,255,255,0.08)]">
                      <p className="text-[13px] sm:text-sm leading-relaxed font-normal whitespace-pre-wrap break-words select-text">
                        {msg.content}
                      </p>
                      <p className="text-[10px] text-neutral-500 mt-1 text-right tabular-nums">
                        {formatTime(msg.timestamp)}
                      </p>
                    </div>
                  ) : (
                    <div className="max-w-[88%] sm:max-w-[76%] rounded-[22px] rounded-bl-[6px] ios-glass-card px-4 py-3 text-white group">
                      <div className="text-[13px] sm:text-sm text-neutral-100 leading-relaxed whitespace-pre-wrap break-words select-text">
                        {msg.content}
                      </div>

                      {msg.actionPayload && (
                        <div className="mt-2.5 pt-2.5 border-t border-white/10">
                          <motion.button
                            whileTap={{ scale: 0.98 }}
                            onClick={() => {
                              triggerHaptic(haptic);
                              if (msg.actionPayload?.startsWith('http')) {
                                window.open(msg.actionPayload, '_blank');
                              } else {
                                onOpenDeviceApps(msg.actionPayload || undefined);
                              }
                            }}
                            className="w-full py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-white font-medium text-xs flex items-center justify-center gap-2 transition"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>{msg.actionLabel || 'Open Action'}</span>
                          </motion.button>
                        </div>
                      )}

                      {/* Quiet Metadata & Actions Footer */}
                      <div className="mt-2 pt-1.5 border-t border-white/[0.06] flex items-center justify-between gap-3">
                        <div className="flex items-center gap-1.5 text-[10px] text-neutral-500 min-w-0">
                          <span className="truncate">{formatModelLabel(msg.modelUsed)}</span>
                          {msg.isOffline && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-neutral-300">Offline</span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums shrink-0">{formatTime(msg.timestamp)}</span>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <motion.button
                            whileTap={{ scale: 0.88 }}
                            onClick={() => {
                              triggerHaptic(haptic, 5);
                              onSpeakText(msg.content);
                            }}
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition"
                            title="Speak aloud"
                            aria-label="Speak aloud"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </motion.button>
                          <motion.button
                            whileTap={{ scale: 0.88 }}
                            onClick={() => handleCopyMessage(msg.id, msg.content)}
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition"
                            title="Copy"
                            aria-label="Copy message"
                          >
                            {copiedId === msg.id ? (
                              <Check className="w-3.5 h-3.5 text-white" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </motion.button>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              );
            })}

            {/* Monochrome iOS Typing Indicator */}
            {coreState === 'THINKING' && (
              <motion.div
                key="typing-indicator"
                layout="position"
                variants={chatBubbleVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className="flex items-start"
              >
                <div className="rounded-[22px] rounded-bl-[6px] ios-glass-card px-4 py-3 flex items-center gap-1.5">
                  {[0, 0.16, 0.32].map((delay, i) => (
                    <motion.span
                      key={i}
                      animate={{ opacity: [0.25, 1, 0.25], y: [0, -2, 0] }}
                      transition={{ duration: 0.9, repeat: Infinity, delay }}
                      className="w-1.5 h-1.5 rounded-full bg-white"
                    />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* 3. FLOATING GLASS INPUT BAR (Attachment + Input + Microphone + Send) */}
      <div className="w-full px-3.5 sm:px-6 pt-1 pb-2 z-20 shrink-0">
        <div className="max-w-3xl mx-auto space-y-2 relative">
          {/* Attached File Chip */}
          <AnimatePresence>
            {attachedFile && (
              <motion.div
                initial={{ opacity: 0, y: 6, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 4, scale: 0.96 }}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full ios-glass text-xs text-white"
              >
                <FileText className="w-3.5 h-3.5 text-neutral-300" />
                <span className="max-w-[200px] truncate">{attachedFile.name}</span>
                <button
                  type="button"
                  onClick={() => setAttachedFile(null)}
                  className="p-0.5 rounded-full hover:bg-white/15 text-neutral-400 hover:text-white"
                  aria-label="Remove attachment"
                >
                  <X className="w-3 h-3" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Attachment Popover */}
          <AnimatePresence>
            {isAttachMenuOpen && (
              <>
                <div onClick={() => setIsAttachMenuOpen(false)} className="fixed inset-0 z-30" />
                <motion.div
                  variants={popoverVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="absolute bottom-full left-0 mb-2 w-52 rounded-2xl ios-glass-elevated p-1.5 z-40 origin-bottom-left space-y-1"
                >
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-white hover:bg-white/10 transition text-left"
                  >
                    <FileText className="w-4 h-4 text-neutral-300" />
                    <span>Attach Text or Code</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsAttachMenuOpen(false);
                      onOpenDeviceApps('camera');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-white hover:bg-white/10 transition text-left"
                  >
                    <Camera className="w-4 h-4 text-neutral-300" />
                    <span>Open Camera</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsAttachMenuOpen(false);
                      setInputText((prev) =>
                        prev ? `${prev} Add task: ` : 'Add task: '
                      );
                      textareaRef.current?.focus();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-white hover:bg-white/10 transition text-left"
                  >
                    <Sparkles className="w-4 h-4 text-neutral-300" />
                    <span>Quick Task Prompt</span>
                  </button>
                </motion.div>
              </>
            )}
          </AnimatePresence>

          {isTrialExpired ? (
            <div className="rounded-[26px] ios-glass-elevated p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
              <div className="flex items-center gap-2.5">
                <ShieldAlert className="w-5 h-5 text-white shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-white">10-Minute Guest Trial Expired</p>
                  <p className="text-[11px] text-neutral-400">
                    Sign in with a @gmail.com account to continue chatting and syncing.
                  </p>
                </div>
              </div>
              <motion.button
                whileTap={{ scale: 0.96 }}
                onClick={onOpenAuth}
                className="px-4 py-2 rounded-full bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition shrink-0"
              >
                Sign In with @gmail
              </motion.button>
            </div>
          ) : (
            <div className="rounded-[28px] ios-glass-elevated focus-within:border-white/30 p-1.5 flex items-end gap-1.5 transition-colors">
              {/* Attachment Button */}
              <motion.button
                type="button"
                whileTap={{ scale: 0.9 }}
                onClick={() => {
                  triggerHaptic(haptic);
                  setIsAttachMenuOpen((v) => !v);
                }}
                className="w-10 h-10 rounded-full flex items-center justify-center text-neutral-300 hover:text-white hover:bg-white/10 transition shrink-0"
                aria-label="Attach file or tool"
                title="Attach"
              >
                <Paperclip className="w-[18px] h-[18px]" />
              </motion.button>

              {/* Text Input */}
              <textarea
                ref={textareaRef}
                rows={1}
                value={inputText}
                onChange={(e) => {
                  setInputText(e.target.value);
                  e.target.style.height = 'auto';
                  e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
                }}
                onKeyDown={handleKeyDown}
                placeholder={isListening ? 'Listening...' : 'Message Ultron'}
                className="flex-1 bg-transparent text-white text-xs sm:text-sm placeholder-neutral-500 focus:outline-none resize-none py-2.5 px-1 max-h-28 overflow-y-auto"
              />

              {/* Microphone Button */}
              <motion.button
                type="button"
                whileTap={{ scale: 0.9 }}
                onClick={handleToggleVoice}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition shrink-0 ${
                  isListening
                    ? 'bg-white text-black animate-pulse'
                    : 'text-neutral-300 hover:text-white hover:bg-white/10'
                }`}
                aria-label={isListening ? 'Stop listening' : 'Start voice input'}
                title={isListening ? 'Stop listening' : 'Voice input'}
              >
                {isListening ? <MicOff className="w-[18px] h-[18px]" /> : <Mic className="w-[18px] h-[18px]" />}
              </motion.button>

              {/* Send Button */}
              <motion.button
                type="button"
                whileTap={{ scale: 0.9 }}
                animate={{
                  scale: canSend ? 1 : 0.92,
                  opacity: canSend ? 1 : 0.4,
                }}
                transition={IOS_SPRING_SNAPPY}
                onClick={handleSend}
                disabled={!canSend}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition shrink-0 ${
                  canSend
                    ? 'bg-white text-black hover:bg-neutral-200 cursor-pointer shadow-lg'
                    : 'bg-white/10 text-neutral-500 cursor-not-allowed'
                }`}
                aria-label="Send message"
              >
                <ArrowUp className="w-[18px] h-[18px] stroke-[2.25]" />
              </motion.button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
