import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Menu,
  MessageSquare,
  Mic,
  Smartphone,
  Search,
  ChevronDown,
  Check,
  User,
  Maximize2,
  ArrowUpRight,
  Download,
} from 'lucide-react';
import { QuantumCoreVisualizer } from './QuantumCoreVisualizer';
import { AppSettings, ChatMessage, UltronCoreState } from '../types';
import { UserProfile } from '../services/firestoreSync';
import { popoverVariants, IOS_SPRING, IOS_SPRING_GENTLE } from '../utils/motionSystem';
import { triggerHaptic } from './ios/IOSControls';

interface HomeViewProps {
  onOpenSidebar: () => void;
  coreState: UltronCoreState;
  audioAmplitude: number;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleQuickVoice: () => void;
  latestUltronMessage?: ChatMessage | null;
  settings: AppSettings;
  onUpdateSettings: (vals: Partial<AppSettings>) => void;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  onOpenChat: () => void;
  onOpenVoiceMode: () => void;
  onOpenDeviceApps: (appId?: string) => void;
  onOpenDownloadModal: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onOpenSidebar,
  coreState,
  audioAmplitude,
  isListening,
  isSpeaking,
  onToggleQuickVoice,
  latestUltronMessage,
  settings,
  onUpdateSettings,
  currentUser,
  onOpenAuth,
  onOpenChat,
  onOpenVoiceMode,
  onOpenDeviceApps,
  onOpenDownloadModal,
}) => {
  const [isModelOpen, setIsModelOpen] = useState(false);

  const availableModels = [
    { id: 'gemini-3.1-flash-lite', label: '3.1 Lite', desc: 'Default · Fastest' },
    { id: 'gemini-3.8-flash', label: '3.8 Flash', desc: 'Balanced' },
    { id: 'gemini-3.1-pro-preview', label: '3.1 Pro', desc: 'Deep Reasoning' },
  ];

  const activeModel = availableModels.find((m) => m.id === settings.geminiModel) || availableModels[0];

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const statusLine =
    coreState === 'LISTENING'
      ? 'Listening to your voice...'
      : coreState === 'THINKING'
      ? 'Processing neural request...'
      : coreState === 'SPEAKING'
      ? 'Speaking response...'
      : settings.operatingMode === 'OFFLINE'
      ? 'Offline Neural Core Ready'
      : 'Ready whenever you are';

  const glowIntensity = settings.orbGlowIntensity ?? 0.85;
  const haptic = settings.hapticFeedback ?? true;

  const quickActions = [
    {
      title: 'Chat',
      subtitle: 'iOS Messaging',
      icon: MessageSquare,
      onClick: () => {
        triggerHaptic(haptic);
        onOpenChat();
      },
    },
    {
      title: 'Voice',
      subtitle: 'Live Conversation',
      icon: Mic,
      onClick: () => {
        triggerHaptic(haptic);
        onOpenVoiceMode();
      },
    },
    {
      title: 'Phone Actions',
      subtitle: 'Camera & Apps',
      icon: Smartphone,
      onClick: () => {
        triggerHaptic(haptic);
        onOpenDeviceApps();
      },
    },
    {
      title: 'Search',
      subtitle: 'Instant Lookup',
      icon: Search,
      onClick: () => {
        triggerHaptic(haptic);
        onOpenDeviceApps('search');
      },
    },
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-black text-white relative overflow-hidden select-none">
      {/* Subtle monochrome top illumination */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-80 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.06),transparent_70%)]"
      />

      {/* Minimal Glass Top Bar */}
      <header
        className="w-full px-4 sm:px-6 py-3 flex items-center justify-between gap-3 z-20 shrink-0"
        style={{ paddingTop: 'max(0.75rem, var(--sat))' }}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => {
              triggerHaptic(haptic);
              onOpenSidebar();
            }}
            className="lg:hidden min-h-[40px] min-w-[40px] rounded-full ios-glass text-white flex items-center justify-center shrink-0 hover:bg-white/10 transition"
            aria-label="Open conversations drawer"
          >
            <Menu className="w-4 h-4" />
          </motion.button>

          <span className="text-sm font-semibold tracking-[0.22em] text-white uppercase whitespace-nowrap">
            ULTRON
          </span>

          {/* Model Picker */}
          <div className="relative">
            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                triggerHaptic(haptic);
                setIsModelOpen((v) => !v);
              }}
              className="min-h-[34px] px-3 py-1 rounded-full ios-glass text-xs font-medium text-neutral-200 hover:text-white flex items-center gap-1 transition whitespace-nowrap"
            >
              <span>{activeModel.label}</span>
              <ChevronDown
                className={`w-3 h-3 text-neutral-400 transition-transform duration-200 ${
                  isModelOpen ? 'rotate-180' : ''
                }`}
              />
            </motion.button>

            <AnimatePresence>
              {isModelOpen && (
                <>
                  <div onClick={() => setIsModelOpen(false)} className="fixed inset-0 z-30" />
                  <motion.div
                    variants={popoverVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    className="absolute left-0 mt-2 w-56 rounded-2xl ios-glass-elevated p-1.5 z-40 origin-top-left space-y-1"
                  >
                    <div className="px-3 py-1.5 text-[11px] font-medium text-neutral-400 border-b border-white/10">
                      Neural Model
                    </div>
                    {availableModels.map((m) => {
                      const isSelected = settings.geminiModel === m.id;
                      return (
                        <button
                          key={m.id}
                          onClick={() => {
                            triggerHaptic(haptic);
                            onUpdateSettings({
                              geminiModel: m.id,
                              thinkingMode: m.id === 'gemini-3.1-pro-preview',
                            });
                            setIsModelOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-left transition ${
                            isSelected
                              ? 'bg-white/15 text-white font-semibold'
                              : 'text-neutral-300 hover:bg-white/[0.06] hover:text-white'
                          }`}
                        >
                          <div>
                            <p className="text-xs">{m.label}</p>
                            <p className="text-[11px] text-neutral-400">{m.desc}</p>
                          </div>
                          {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                        </button>
                      );
                    })}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => {
              triggerHaptic(haptic);
              onOpenDownloadModal();
            }}
            className="min-h-[38px] px-3 py-1.5 rounded-full ios-glass text-xs font-medium text-neutral-200 hover:text-white transition flex items-center gap-1.5 whitespace-nowrap"
            title="Download App"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">App</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => {
              triggerHaptic(haptic);
              onOpenAuth();
            }}
            className="min-h-[38px] px-3 py-1.5 rounded-full ios-glass text-xs font-medium text-white transition flex items-center gap-1.5 whitespace-nowrap"
            title={currentUser ? currentUser.email || 'Guest' : 'Sign In'}
          >
            <User className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {currentUser
                ? currentUser.isGuest
                  ? 'Guest'
                  : currentUser.email?.split('@')[0]
                : 'Account'}
            </span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={() => {
              try {
                if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
                  document.documentElement.requestFullscreen().catch(() => {});
                } else if (document.exitFullscreen) {
                  document.exitFullscreen().catch(() => {});
                }
              } catch {}
            }}
            className="hidden sm:flex min-h-[38px] min-w-[38px] rounded-full ios-glass text-neutral-300 hover:text-white transition items-center justify-center"
            aria-label="Toggle Fullscreen"
          >
            <Maximize2 className="w-4 h-4" />
          </motion.button>
        </div>
      </header>

      {/* Scrollable Centerpiece Content */}
      <main className="flex-1 overflow-y-auto px-4 sm:px-6 pb-4 flex flex-col items-center justify-between">
        {/* Clean Greeting Section */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={IOS_SPRING_GENTLE}
          className="text-center pt-2 sm:pt-4 space-y-1.5 max-w-md mx-auto"
        >
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-white">
            {getGreeting()}
            {currentUser?.displayName && !currentUser.isGuest
              ? `, ${currentUser.displayName.split(' ')[0]}`
              : ''}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400">
            {statusLine}
          </p>
        </motion.div>

        {/* Central Animated Monochrome AI Orb */}
        <div className="relative flex flex-col items-center justify-center my-2 sm:my-4">
          {/* Subtle Monochrome Radial Aura */}
          <motion.div
            aria-hidden="true"
            animate={{
              scale:
                coreState === 'LISTENING'
                  ? 1.08 + audioAmplitude * 0.25
                  : coreState === 'SPEAKING'
                  ? 1.05 + audioAmplitude * 0.2
                  : coreState === 'THINKING'
                  ? [0.98, 1.06, 0.98]
                  : [1, 1.03, 1],
              opacity:
                coreState === 'IDLE'
                  ? 0.28 * glowIntensity
                  : 0.55 * glowIntensity,
            }}
            transition={
              coreState === 'IDLE' || coreState === 'THINKING'
                ? { duration: coreState === 'THINKING' ? 1.4 : 4, repeat: Infinity, ease: 'easeInOut' }
                : IOS_SPRING
            }
            className="absolute w-64 h-64 sm:w-80 sm:h-80 rounded-full bg-[radial-gradient(circle,rgba(255,255,255,0.22)_0%,rgba(255,255,255,0.06)_45%,transparent_72%)] blur-2xl pointer-events-none"
          />

          <QuantumCoreVisualizer
            state={coreState}
            audioAmplitude={audioAmplitude}
            onClick={() => {
              triggerHaptic(haptic, 10);
              onToggleQuickVoice();
            }}
            className="w-[220px] h-[220px] sm:w-[270px] sm:h-[270px] md:w-[300px] md:h-[300px]"
          />

          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={() => {
              triggerHaptic(haptic);
              onToggleQuickVoice();
            }}
            className="mt-1 px-4 py-1.5 rounded-full ios-glass text-xs font-medium text-neutral-200 hover:text-white hover:bg-white/10 transition flex items-center gap-2"
          >
            <span
              className={`w-1.5 h-1.5 rounded-full bg-white ${
                isListening || isSpeaking ? 'animate-ping' : 'opacity-60'
              }`}
            />
            <span>{isListening ? 'Tap to stop listening' : 'Tap core to speak'}</span>
          </motion.button>
        </div>

        {/* Bottom Home Cards Stack: Subtle Preview + 4 Quick-Action Glass Cards */}
        <div className="w-full max-w-2xl mx-auto space-y-3 pb-1">
          {latestUltronMessage && (
            <motion.button
              type="button"
              whileTap={{ scale: 0.985 }}
              onClick={() => {
                triggerHaptic(haptic);
                onOpenChat();
              }}
              className="w-full text-left rounded-[22px] ios-glass px-4 py-3 flex items-center justify-between gap-3 hover:border-white/20 transition group"
            >
              <div className="min-w-0">
                <p className="text-[11px] font-medium text-neutral-400">Latest from Ultron</p>
                <p className="text-xs sm:text-sm text-white/90 truncate mt-0.5">
                  {latestUltronMessage.content}
                </p>
              </div>
              <ArrowUpRight className="w-4 h-4 text-neutral-400 group-hover:text-white shrink-0 transition" />
            </motion.button>
          )}

          {/* 4 Glass Quick-Action Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
            {quickActions.map((action, idx) => {
              const Icon = action.icon;
              return (
                <motion.button
                  key={action.title}
                  type="button"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ ...IOS_SPRING, delay: idx * 0.04 }}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={action.onClick}
                  className="rounded-[22px] ios-glass-card hover:border-white/25 p-3.5 sm:p-4 text-left flex flex-col justify-between min-h-[92px] sm:min-h-[104px] transition group"
                >
                  <div className="w-9 h-9 rounded-full bg-white/[0.08] border border-white/10 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-colors">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="mt-3">
                    <p className="text-xs sm:text-sm font-semibold text-white">{action.title}</p>
                    <p className="text-[11px] text-neutral-400 truncate">{action.subtitle}</p>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>
      </main>
    </div>
  );
};
