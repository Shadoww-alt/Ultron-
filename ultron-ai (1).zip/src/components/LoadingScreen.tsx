import React, { useState, useEffect } from 'react';
import { Zap, Code2, Sparkles, ShieldCheck } from 'lucide-react';

interface LoadingScreenProps {
  onComplete: () => void;
  minDurationMs?: number;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({
  onComplete,
  minDurationMs = 5000,
}) => {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('BOOTING QUANTUM NEURAL MATRIX...');
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const rawPct = Math.min(100, Math.floor((elapsed / minDurationMs) * 100));

      setProgress(rawPct);

      if (rawPct < 20) {
        setStatusText('INITIALIZING QUANTUM RUNTIME...');
      } else if (rawPct < 45) {
        setStatusText('CORE ARCHITECTURE • CODED BY SIBTAIN');
      } else if (rawPct < 70) {
        setStatusText('NEURAL ASSISTANT ENGINE • ASSISTANT CODE BY SHREYASH');
      } else if (rawPct < 90) {
        setStatusText('CONNECTING ULTRON 3.1 LITE...');
      } else if (rawPct < 100) {
        setStatusText('SYNCHRONIZING SECURE CLOUD MATRIX...');
      } else {
        setStatusText('SYSTEM ONLINE • WELCOME TO ULTRON');
        clearInterval(interval);
        try {
          if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
            document.documentElement.requestFullscreen().catch(() => {});
          }
        } catch (e) {}
        setTimeout(() => {
          setIsFadingOut(true);
          setTimeout(() => {
            onComplete();
          }, 450);
        }, 300);
      }
    }, 40);

    return () => clearInterval(interval);
  }, [minDurationMs, onComplete]);

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black text-white select-none transition-opacity duration-500 ease-out overflow-hidden px-4 ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background: Pure pitch black with subtle white grid outline */}
      <div className="absolute inset-0 bg-black pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff0a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff0a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" />

      {/* Hologram Rings & App Logo Core with White Outline */}
      <div className="relative mb-8 flex items-center justify-center">
        {/* Pulsing Outer Rings (Pure White outlines) */}
        <div className="absolute w-44 h-44 sm:w-48 sm:h-48 rounded-full border border-white/30 animate-[spin_10s_linear_infinite]" />
        <div className="absolute w-56 h-56 sm:w-64 sm:h-64 rounded-full border border-dashed border-white/20 animate-[spin_14s_linear_infinite_reverse]" />
        <div className="absolute w-72 h-72 sm:w-80 sm:h-80 rounded-full border border-white/10 animate-ping opacity-20 pointer-events-none" />

        {/* Center Card with App Logo (Black background, White outline) */}
        <div className="relative w-32 h-32 sm:w-36 sm:h-36 rounded-3xl bg-black border-2 border-white flex items-center justify-center overflow-hidden shadow-[0_0_35px_rgba(255,255,255,0.2)]">
          <img
            src="/assets/aistudio/Ultron_AI_Agent_Icon_f1242b8c.png"
            alt="Ultron AI Logo"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Main Title & Subtitle (Black & White) */}
      <div className="text-center space-y-2 mb-6 max-w-md relative z-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-black border border-white text-white text-xs font-mono tracking-wider mb-1 shadow-[0_0_15px_rgba(255,255,255,0.15)]">
          <Zap className="w-3.5 h-3.5 text-white" />
          <span>DEFAULT ENGINE: ULTRON 3.1 LITE</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
          ULTRON AI
        </h1>
        <p className="text-xs text-white/80 font-mono tracking-wider uppercase">
          Cross-Platform Neural Voice & Intelligence Core
        </p>
      </div>

      {/* Developer Credits Card (Black background, White outline & White text) */}
      <div className="relative z-10 w-full max-w-md p-4 rounded-2xl bg-black border border-white shadow-[0_0_30px_rgba(255,255,255,0.1)] mb-6">
        <div className="flex items-center justify-between border-b border-white pb-2.5 mb-3">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-white" />
            <span className="text-[11px] font-mono font-bold tracking-wider text-white uppercase">
              System Engineering & Architecture
            </span>
          </div>
          <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-black text-white border border-white">
            ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-black border border-white/60 hover:border-white transition">
            <div className="w-8 h-8 rounded-lg bg-black border border-white flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] text-white/70 font-mono uppercase tracking-wide">
                Core Development
              </p>
              <p className="text-xs font-bold text-white tracking-wide truncate">
                Coded by sibtain
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-black border border-white/60 hover:border-white transition">
            <div className="w-8 h-8 rounded-lg bg-black border border-white flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] text-white/70 font-mono uppercase tracking-wide">
                Assistant Core
              </p>
              <p className="text-xs font-bold text-white tracking-wide truncate">
                assistant code by shreyash
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar & Status Text (Black & White) */}
      <div className="w-full max-w-md relative z-10 space-y-2">
        <div className="flex justify-between items-center text-[11px] font-mono text-white px-1">
          <span className="truncate pr-2 font-medium">{statusText}</span>
          <span className="text-white font-bold">{progress}%</span>
        </div>

        <div className="h-2 w-full bg-black rounded-full overflow-hidden border border-white p-[1px]">
          <div
            className="h-full rounded-full bg-white transition-all duration-100 ease-out shadow-[0_0_10px_rgba(255,255,255,0.9)]"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Skip button with white text and underline */}
        <div className="flex justify-end pt-1">
          <button
            onClick={() => {
              try {
                if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
                  document.documentElement.requestFullscreen().catch(() => {});
                }
              } catch (e) {}
              setIsFadingOut(true);
              setTimeout(onComplete, 200);
            }}
            className="text-[10px] font-mono text-white/70 hover:text-white transition tracking-wider uppercase underline underline-offset-4"
          >
            Skip to App &rarr;
          </button>
        </div>
      </div>

      {/* Footer Security Badge (Black & White) */}
      <div className="absolute bottom-4 flex items-center gap-1.5 px-3 py-1 rounded-full bg-black border border-white/40 text-[10px] font-mono text-white">
        <ShieldCheck className="w-3.5 h-3.5 text-white" />
        <span>ULTRON 3.1 LITE • CLOUD SYNC ACTIVE</span>
      </div>
    </div>
  );
};
