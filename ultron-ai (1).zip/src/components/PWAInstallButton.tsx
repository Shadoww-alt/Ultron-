import React, { useState } from 'react';
import { Download, WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/usePWAInstall';
import { AppDownloadModal } from './AppDownloadModal';

interface PWAInstallButtonProps {
  variant?: 'compact' | 'full' | 'banner';
  className?: string;
  onOpenDownloadModal?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'compact',
  className = '',
  onOpenDownloadModal,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleClick = () => {
    if (onOpenDownloadModal) {
      onOpenDownloadModal();
    } else {
      setIsModalOpen(true);
    }
  };

  if (variant === 'banner') {
    return (
      <>
        <div
          className={`flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 bg-neutral-900/95 border border-white/20 rounded-xl text-white ${className}`}
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center border border-white/20">
              <Download className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-xs font-semibold">Download Ultron AI (Android APK & Windows)</p>
              <p className="text-[11px] text-neutral-400">
                Get native APK for Android or desktop application for Windows.
              </p>
            </div>
          </div>
          <button
            onClick={handleClick}
            className="w-full sm:w-auto px-4 py-2 rounded-lg bg-white text-black hover:bg-neutral-200 transition font-bold text-xs flex items-center justify-center gap-1.5 shadow"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download APK / PC</span>
          </button>
        </div>
        <AppDownloadModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </>
    );
  }

  return (
    <>
      <button
        onClick={handleClick}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white border border-white/20 hover:border-white/40 transition text-xs font-medium ${className}`}
        title="Download APK for Android or Application for Windows"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Download App</span>
        <span className="sm:hidden">App</span>
      </button>

      <AppDownloadModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-20 right-4 z-40 flex items-center gap-2 px-3.5 py-1.5 rounded-full ios-glass-elevated text-white text-xs font-medium shadow-xl"
    >
      <WifiOff className="w-3.5 h-3.5 text-neutral-300" />
      <span>Offline Mode</span>
    </div>
  );
};
