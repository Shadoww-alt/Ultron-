import React from 'react';
import { motion } from 'motion/react';
import { IOS_SPRING_SNAPPY } from '../../utils/motionSystem';

export function triggerHaptic(enabled = true, duration = 7) {
  if (!enabled) return;
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(duration);
    }
  } catch {
    // Ignore vibration errors on unsupported browsers
  }
}

interface IOSSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  ariaLabel?: string;
  hapticEnabled?: boolean;
  disabled?: boolean;
}

export const IOSSwitch: React.FC<IOSSwitchProps> = ({
  checked,
  onChange,
  ariaLabel,
  hapticEnabled = true,
  disabled = false,
}) => {
  return (
    <motion.button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      disabled={disabled}
      whileTap={{ scale: 0.94 }}
      onClick={() => {
        if (disabled) return;
        triggerHaptic(hapticEnabled, 6);
        onChange(!checked);
      }}
      className={`relative inline-flex h-[28px] w-[48px] shrink-0 cursor-pointer items-center rounded-full border transition-colors duration-200 ${
        checked
          ? 'bg-white border-white'
          : 'bg-white/[0.12] border-white/[0.14] hover:bg-white/[0.18]'
      } ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
    >
      <motion.span
        layout
        transition={IOS_SPRING_SNAPPY}
        className={`pointer-events-none inline-block h-[22px] w-[22px] rounded-full shadow-md ${
          checked ? 'translate-x-[22px] bg-black' : 'translate-x-[2px] bg-white'
        }`}
      />
    </motion.button>
  );
};

interface IOSGroupedSectionProps {
  title?: string;
  footer?: string;
  children: React.ReactNode;
  className?: string;
}

export const IOSGroupedSection: React.FC<IOSGroupedSectionProps> = ({
  title,
  footer,
  children,
  className = '',
}) => {
  return (
    <section className={className}>
      {title && (
        <h3 className="text-xs font-medium text-neutral-400 px-3.5 mb-2 tracking-tight">
          {title}
        </h3>
      )}
      <div className="rounded-[22px] ios-glass-card overflow-hidden divide-y divide-white/[0.08]">
        {children}
      </div>
      {footer && (
        <p className="text-[11px] text-neutral-500 px-3.5 mt-2 leading-relaxed">
          {footer}
        </p>
      )}
    </section>
  );
};
