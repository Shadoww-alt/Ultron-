import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  modalBackdropVariants,
  modalSheetVariants,
  IOS_SPRING_SNAPPY,
} from '../utils/motionSystem';
import {
  Download,
  X,
  Smartphone,
  Monitor,
  Share2,
  Check,
  CheckCircle2,
  Copy,
  ExternalLink,
  Laptop,
  FolderArchive,
  Terminal,
  Shield,
  Apple,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { getCurrentAppUrl, APP_URLS } from '../utils/appUrl';

interface AppDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppDownloadModal: React.FC<AppDownloadModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'ANDROID' | 'WINDOWS' | 'IOS'>('ANDROID');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const { isInstallable, install } = usePWAInstall();
  const appUrl = getCurrentAppUrl();

  const handleCopy = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleDownloadAndroidApk = () => {
    const origin = encodeURIComponent(window.location.origin || APP_URLS.SHARED_URL);
    window.location.href = `/api/download/android?origin=${origin}`;
  };

  const handleDownloadWindowsExe = () => {
    const origin = encodeURIComponent(window.location.origin || APP_URLS.SHARED_URL);
    window.location.href = `/api/download/windows-exe?origin=${origin}`;
  };

  const handleDownloadWindowsZip = () => {
    const origin = encodeURIComponent(window.location.origin || APP_URLS.SHARED_URL);
    window.location.href = `/api/download/windows-zip?origin=${origin}`;
  };

  const downloadTabs: { id: 'ANDROID' | 'WINDOWS' | 'IOS'; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'ANDROID', label: 'Android (APK)', icon: Smartphone },
    { id: 'WINDOWS', label: 'Windows (PC)', icon: Monitor },
    { id: 'IOS', label: 'iOS (Apple)', icon: Apple },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          variants={modalBackdropVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
          onClick={onClose}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
        >
          <motion.div
            variants={modalSheetVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xl ios-glass-elevated rounded-3xl text-white overflow-hidden flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-black/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center">
                  <Download className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-base font-bold tracking-tight">Download Ultron AI</h2>
                  <p className="text-xs text-neutral-400">
                    Native Android APK & Windows Desktop Applications
                  </p>
                </div>
              </div>
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={onClose}
                className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 transition"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </motion.button>
            </div>

            {/* Segmented Tab Selection */}
            <div className="flex border-b border-white/10 bg-black/30 p-1.5 gap-1.5">
              {downloadTabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`relative flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                      isActive ? 'text-black' : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {isActive && (
                      <motion.span
                        layoutId="downloadTabPill"
                        transition={IOS_SPRING_SNAPPY}
                        className="absolute inset-0 rounded-xl bg-white shadow"
                      />
                    )}
                    <Icon className="w-4 h-4 relative z-10" />
                    <span className="relative z-10">{tab.label}</span>
                  </button>
                );
              })}
            </div>

        {/* Body Content */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs text-neutral-300">
          {/* ANDROID TAB */}
          {activeTab === 'ANDROID' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white font-mono">UltronAI-v3.8-universal.apk</span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-white/10 text-neutral-200 border border-white/15">
                      APK Package
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400">
                    Universal Android Package • Works on all Android 8.0+ phones and tablets (Samsung, Pixel, Xiaomi, OnePlus, Motorola).
                  </p>
                </div>

                <button
                  onClick={handleDownloadAndroidApk}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white text-black font-bold text-xs hover:bg-neutral-200 transition flex items-center justify-center gap-2 shadow-lg shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>Download APK (.apk)</span>
                </button>
              </div>

              {/* Instant Browser Install Option */}
              {isInstallable && (
                <div className="p-3.5 rounded-xl bg-neutral-900 border border-white/15 flex items-center justify-between gap-3">
                  <div>
                    <p className="font-semibold text-white text-xs">Direct WebAPK Install (Chrome)</p>
                    <p className="text-[11px] text-neutral-400">Install directly onto home screen without manual APK installation.</p>
                  </div>
                  <button
                    onClick={install}
                    className="px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white border border-white/20 transition font-medium text-xs whitespace-nowrap"
                  >
                    Install WebAPK
                  </button>
                </div>
              )}

              {/* Android Installation Instructions */}
              <div className="p-4 rounded-xl bg-neutral-900/80 border border-white/10 space-y-2.5">
                <p className="font-semibold text-white font-mono text-[11px] uppercase tracking-wider">
                  How to Install APK on Android:
                </p>
                <ol className="space-y-2 text-[11px] text-neutral-400 list-decimal list-inside leading-relaxed">
                  <li>
                    Tap <strong>Download APK (.apk)</strong> above. The file will be saved to your device Downloads folder.
                  </li>
                  <li>
                    Open your Android notification bar or Files app and tap on <strong className="text-white">UltronAI-v3.8-universal.apk</strong>.
                  </li>
                  <li>
                    If Android asks to allow app installs from your browser, toggle <em>"Allow from this source"</em>.
                  </li>
                  <li>
                    Tap <strong>Install</strong>. Once complete, tap <strong>Open</strong> to start Ultron AI with voice and cloud sync!
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* WINDOWS TAB */}
          {activeTab === 'WINDOWS' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white font-mono">UltronAI-Setup.exe</span>
                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-white/10 text-neutral-200 border border-white/15">
                        Windows App
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400">
                      Standalone Windows 10 & 11 application launcher. Runs in a dedicated native borderless window with GPU acceleration.
                    </p>
                  </div>

                  <button
                    onClick={handleDownloadWindowsExe}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white text-black font-bold text-xs hover:bg-neutral-200 transition flex items-center justify-center gap-2 shadow-lg shrink-0"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download for Windows (.exe)</span>
                  </button>
                </div>
              </div>

              {/* Windows Portable ZIP Package */}
              <div className="p-4 rounded-xl bg-neutral-900 border border-white/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-white font-mono">UltronAI-Windows-x64.zip</span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-white/10 text-neutral-300">
                      Portable Suite
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400">
                    Includes desktop launcher script, shortcut installer, and Windows icon package.
                  </p>
                </div>

                <button
                  onClick={handleDownloadWindowsZip}
                  className="w-full sm:w-auto px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-white font-medium text-xs transition flex items-center justify-center gap-2 shrink-0"
                >
                  <FolderArchive className="w-3.5 h-3.5" />
                  <span>Download .zip Package</span>
                </button>
              </div>

              {/* Windows Instructions */}
              <div className="p-4 rounded-xl bg-neutral-900/80 border border-white/10 space-y-2 text-[11px] text-neutral-400">
                <p className="font-semibold text-white font-mono uppercase tracking-wider">
                  Windows Setup Instructions:
                </p>
                <p>
                  1. Click <strong>Download for Windows (.exe)</strong> or the <strong>.zip Package</strong>.
                </p>
                <p>
                  2. Double-click to launch Ultron AI in a dedicated, distraction-free desktop application window.
                </p>
                <p>
                  3. Use <em>Setup-Desktop-Icon.vbs</em> inside the zip to pin Ultron AI to your Windows Desktop and Start Menu.
                </p>
              </div>
            </div>
          )}

          {/* IOS TAB */}
          {activeTab === 'IOS' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-3">
                <p className="font-semibold text-white text-xs">Install on Apple iOS (iPhone & iPad)</p>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Apple does not support direct sideloading of third-party APKs on iOS, but Ultron AI installs natively as a Progressive Web App directly through Safari.
                </p>

                <div className="space-y-2.5 pt-2 border-t border-white/10 text-[11px] text-neutral-300">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center shrink-0 font-mono text-[10px] font-bold">1</span>
                    <span>Open this app in <strong>Safari</strong> on your iPhone or iPad.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center shrink-0 font-mono text-[10px] font-bold">2</span>
                    <span>Tap the <strong>Share</strong> button at the bottom of the screen (the square with an arrow pointing up).</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center shrink-0 font-mono text-[10px] font-bold">3</span>
                    <span>Scroll down and tap <strong>Add to Home Screen</strong>, then tap <strong>Add</strong>.</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Share App Link across devices */}
          <div className="p-3.5 rounded-xl bg-black border border-white/15 flex items-center justify-between gap-2">
            <div className="min-w-0 pr-2">
              <p className="text-[11px] font-semibold text-white truncate">App Link for Other Devices</p>
              <p className="text-[10px] text-neutral-500 font-mono truncate">{appUrl}</p>
            </div>
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-mono flex items-center gap-1.5 transition shrink-0"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedUrl ? 'Copied!' : 'Copy Link'}</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-black flex items-center justify-between">
          <div className="flex items-center gap-2 text-[11px] text-neutral-400 font-mono">
            <Shield className="w-3.5 h-3.5 text-white" />
            <span>Offline fallback enabled • v3.8</span>
          </div>
          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition"
          >
            Close
          </motion.button>
        </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
