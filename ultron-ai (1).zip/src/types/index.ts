export type Sender = 'USER' | 'ULTRON';

export type OperatingMode = 'ONLINE' | 'OFFLINE' | 'AUTO';

export type PersonalityTone = 'CASUAL_WIT' | 'BALANCED_SMART' | 'DEEP_MENTOR' | 'SERIOUS_WORK';

export type UltronCoreState = 'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING';

export type ActiveScreen = 'HOME' | 'ASSISTANT' | 'PRODUCTIVITY' | 'VOICE_MODE' | 'SETTINGS';

export interface ChatMessage {
  id: string;
  conversationId: string;
  sender: Sender;
  content: string;
  thinkingText?: string | null;
  modelUsed: string;
  isOffline?: boolean;
  actionTriggered?: string | null;
  actionLabel?: string | null;
  actionPayload?: string | null;
  timestamp: number;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  isPinned?: boolean;
}

export interface ProductivityTask {
  id: string;
  title: string;
  description: string;
  category: 'Task' | 'Learning' | 'Project' | 'Note';
  isCompleted: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface AgentPermissions {
  microphoneAccess: boolean;
  cameraAccess: boolean;
  webSearchAccess: boolean;
  taskAutomation: boolean;
  backgroundSync: boolean;
}

export interface AppSettings {
  operatingMode: OperatingMode;
  geminiModel: string;
  thinkingMode: boolean;
  ollamaUrl: string;
  ollamaModel: string;
  personalityTone: PersonalityTone;
  autoSpeak: boolean;
  speechRate: number;
  speechPitch: number;
  selectedVoice: string;
  elevenLabsApiKey: string;
  elevenLabsVoiceId: string;
  cloudSyncKey: string;
  autoCloudSync: boolean;
  lastSyncedAt: number | null;
  orbGlowIntensity?: number;
  hapticFeedback?: boolean;
  reducedBlur?: boolean;
  agentPermissions?: AgentPermissions;
}

export interface SyncPayload {
  syncKey: string;
  deviceId: string;
  deviceName: string;
  deviceType: 'mobile' | 'tablet' | 'laptop' | 'desktop';
  conversations: Conversation[];
  messages: ChatMessage[];
  tasks: ProductivityTask[];
  settings: Partial<AppSettings>;
  timestamp: number;
}

export interface DeviceAppInfo {
  id: string;
  label: string;
  category: string;
  icon: string;
  actionRemark: string;
}
