export const APP_URLS = {
  DEV_URL: 'https://ais-dev-cu6qwjez3ye5vukc7ycgbh-451274073242.asia-southeast1.run.app',
  SHARED_URL: 'https://ais-pre-cu6qwjez3ye5vukc7ycgbh-451274073242.asia-southeast1.run.app',
};

export function getCurrentAppUrl(): string {
  if (typeof window !== 'undefined' && window.location.origin) {
    return window.location.origin;
  }
  return APP_URLS.SHARED_URL;
}
