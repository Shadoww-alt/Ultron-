import type { Transition, Variants } from 'motion/react';

/**
 * iOS 20 Liquid Glass Physics & Motion System
 * Compositor-first springs (transform & opacity) tuned for zero-jitter, fluid settling.
 */

export const IOS_EASE: [number, number, number, number] = [0.22, 1, 0.36, 1];

export const IOS_SPRING: Transition = {
  type: 'spring',
  stiffness: 400,
  damping: 32,
  mass: 0.85,
};

export const IOS_SPRING_GENTLE: Transition = {
  type: 'spring',
  stiffness: 300,
  damping: 28,
  mass: 0.9,
};

export const IOS_SPRING_SNAPPY: Transition = {
  type: 'spring',
  stiffness: 520,
  damping: 36,
  mass: 0.72,
};

export const chatBubbleVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 12,
    scale: 0.965,
  },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: 'spring',
      stiffness: 390,
      damping: 30,
      mass: 0.82,
    },
  },
  exit: {
    opacity: 0,
    y: -6,
    scale: 0.97,
    transition: {
      duration: 0.16,
      ease: IOS_EASE,
    },
  },
};

export const taskItemVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 10,
    scale: 0.98,
  },
  visible: (index: number = 0) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: 'spring',
      stiffness: 410,
      damping: 32,
      mass: 0.8,
      delay: Math.min(index * 0.025, 0.16),
    },
  }),
  exit: {
    opacity: 0,
    x: -14,
    scale: 0.97,
    transition: {
      duration: 0.16,
      ease: IOS_EASE,
    },
  },
};

export const screenVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 8,
    scale: 0.992,
  },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.24,
      ease: IOS_EASE,
    },
  },
  exit: {
    opacity: 0,
    y: -6,
    scale: 0.994,
    transition: {
      duration: 0.16,
      ease: IOS_EASE,
    },
  },
};

export const modalBackdropVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: 0.2, ease: IOS_EASE },
  },
  exit: {
    opacity: 0,
    transition: { duration: 0.16, ease: IOS_EASE },
  },
};

export const modalSheetVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 18,
    scale: 0.96,
  },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: 'spring',
      stiffness: 380,
      damping: 30,
      mass: 0.85,
    },
  },
  exit: {
    opacity: 0,
    y: 12,
    scale: 0.97,
    transition: {
      duration: 0.16,
      ease: IOS_EASE,
    },
  },
};

export const popoverVariants: Variants = {
  hidden: {
    opacity: 0,
    y: -6,
    scale: 0.96,
  },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: 'spring',
      stiffness: 460,
      damping: 32,
      mass: 0.75,
    },
  },
  exit: {
    opacity: 0,
    y: -4,
    scale: 0.97,
    transition: {
      duration: 0.12,
      ease: IOS_EASE,
    },
  },
};
