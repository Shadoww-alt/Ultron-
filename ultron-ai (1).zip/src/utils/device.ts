export function getDeviceType(): 'mobile' | 'tablet' | 'laptop' | 'desktop' {
  if (typeof window === 'undefined') return 'desktop';
  const ua = navigator.userAgent.toLowerCase();
  const width = window.innerWidth;

  if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
    return 'tablet';
  }
  if (/mobile|iphone|ipod|blackberry|opera mini|iemobile/i.test(ua) || width < 640) {
    return 'mobile';
  }
  if (width < 1200) {
    return 'laptop';
  }
  return 'desktop';
}

export function isIOS(): boolean {
  if (typeof window === 'undefined') return false;
  return /iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase());
}

export function isAndroid(): boolean {
  if (typeof window === 'undefined') return false;
  return /android/.test(navigator.userAgent.toLowerCase());
}

export function isStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

export function getDevicePlatformName(): string {
  if (typeof window === 'undefined') return 'Web Client';
  const ua = navigator.userAgent;
  if (/iPad|iPhone|iPod/.test(ua)) return 'Apple iOS';
  if (/Android/.test(ua)) return 'Google Android';
  if (/Macintosh|Mac OS X/.test(ua)) return 'Apple macOS';
  if (/Windows/.test(ua)) return 'Microsoft Windows';
  if (/Linux/.test(ua)) return 'Linux';
  return 'Web Platform';
}
