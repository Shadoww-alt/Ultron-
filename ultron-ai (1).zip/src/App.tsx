import React, { useState, useEffect, useRef } from 'react';
import { MotionConfig, AnimatePresence, motion } from 'motion/react';
import { screenVariants } from './utils/motionSystem';
import {
  Conversation,
  ChatMessage,
  ProductivityTask,
  AppSettings,
  UltronCoreState,
  ActiveScreen,
} from './types';
import {
  loadSettings,
  saveSettings,
  loadConversations,
  saveConversations,
  loadMessages,
  saveMessages,
  loadTasks,
  saveTasks,
  DEFAULT_SETTINGS,
} from './services/storage';
import { CloudSyncService, SyncState } from './services/cloudSync';
import { VoiceService } from './services/voice';
import {
  auth,
  onAuthStateChanged,
  signOut,
  testFirestoreConnection,
  FirebaseUser,
} from './services/firebase';
import {
  UserProfile,
  syncUserProfile,
  subscribeToUserData,
  saveConversationToCloud,
  deleteConversationFromCloud,
  saveMessageToCloud,
  saveTaskToCloud,
  deleteTaskFromCloud,
  saveSettingsToCloud,
  migrateGuestDataToUser,
  isAllowedGmail,
  GUEST_TRIAL_DURATION_MS,
} from './services/firestoreSync';
import { getCurrentAppUrl, APP_URLS } from './utils/appUrl';
import { Sidebar } from './components/Sidebar';
import { HomeView } from './components/HomeView';
import { AssistantView } from './components/AssistantView';
import { ProductivityView } from './components/ProductivityView';
import { VoiceModeView } from './components/VoiceModeView';
import { SettingsView } from './components/SettingsView';
import { FloatingBottomNav } from './components/FloatingBottomNav';
import { DeviceAppsModal } from './components/DeviceAppsModal';
import { AuthModal } from './components/AuthModal';
import { AppDownloadModal } from './components/AppDownloadModal';
import { GuestTrialBanner } from './components/GuestTrialBanner';
import { OfflineIndicator } from './components/PWAInstallButton';
import { LoadingScreen } from './components/LoadingScreen';

const DEFAULT_CONVERSATION_ID = 'main_session';

export default function App() {
  // 0. Loading Screen State
  const [showLoadingScreen, setShowLoadingScreen] = useState(true);

  // 1. Persistent State
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    const loaded = loadConversations();
    if (loaded.length === 0) {
      return [
        {
          id: DEFAULT_CONVERSATION_ID,
          title: 'Main Intelligence Feed',
          createdAt: Date.now(),
          updatedAt: Date.now(),
        },
      ];
    }
    return loaded;
  });

  const [activeConversationId, setActiveConversationId] = useState<string>(() => {
    const loaded = loadConversations();
    return loaded[0]?.id || DEFAULT_CONVERSATION_ID;
  });

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const loaded = loadMessages();
    if (loaded.length === 0) {
      return [
        {
          id: 'msg_welcome',
          conversationId: DEFAULT_CONVERSATION_ID,
          sender: 'ULTRON',
          content:
            "Hey. I'm Ultron — ready with real-time cross-device sync. What are we tackling today?",
          modelUsed: 'ultron-3.1-lite',
          isOffline: false,
          timestamp: Date.now(),
        },
      ];
    }
    return loaded;
  });

  const [tasks, setTasks] = useState<ProductivityTask[]>(() => {
    const loaded = loadTasks();
    if (loaded.length === 0) {
      return [
        {
          id: 'task_init_1',
          title: 'Install Ultron AI as standalone PWA on mobile or PC',
          description: 'Tap Install App in header for iOS or Android.',
          category: 'Task',
          isCompleted: false,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        },
        {
          id: 'task_init_2',
          title: 'Connect Cloud Data Synchronization with @gmail',
          description: 'Authenticate with your @gmail account to sync securely in Firestore.',
          category: 'Project',
          isCompleted: false,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        },
      ];
    }
    return loaded;
  });

  // 2. Authentication & Guest Trial state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [guestTimeRemainingMs, setGuestTimeRemainingMs] = useState<number>(GUEST_TRIAL_DURATION_MS);
  const [isTrialExpired, setIsTrialExpired] = useState<boolean>(false);
  const prevGuestUidRef = useRef<string | null>(null);

  // 3. Navigation & UI state
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('HOME');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [settingsInitialSection, setSettingsInitialSection] = useState('general');
  const [isDeviceAppsOpen, setIsDeviceAppsOpen] = useState(false);
  const [activeDeviceAppId, setActiveDeviceAppId] = useState<string | null>(null);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // 4. Core & Voice state
  const [coreState, setCoreState] = useState<UltronCoreState>('IDLE');
  const [audioAmplitude, setAudioAmplitude] = useState<number>(0);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  // 5. Cloud Sync State
  const [cloudSyncState, setCloudSyncState] = useState<SyncState>('idle');
  const [lastSyncedAt, setLastSyncedAt] = useState<number | null>(settings.lastSyncedAt);
  const appUrl = getCurrentAppUrl();

  // Singletons
  const voiceServiceRef = useRef<VoiceService | null>(null);
  const cloudSyncRef = useRef<CloudSyncService | null>(null);

  if (!voiceServiceRef.current) {
    voiceServiceRef.current = new VoiceService();
  }

  if (!cloudSyncRef.current) {
    cloudSyncRef.current = new CloudSyncService(settings.cloudSyncKey);
  }

  // Verify Firestore connection on boot
  useEffect(() => {
    testFirestoreConnection();
  }, []);

  // Firebase Auth Observer & Real-time Firestore synchronization
  useEffect(() => {
    let unsubscribeFirestore: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
      if (unsubscribeFirestore) {
        unsubscribeFirestore();
        unsubscribeFirestore = null;
      }

      if (!user) {
        setCurrentUser(null);
        setIsTrialExpired(false);
        return;
      }

      const isGuest = user.isAnonymous;
      const email = user.email;

      // Enforce: only @gmail.com accounts allowed
      if (!isGuest && !isAllowedGmail(email)) {
        await signOut(auth);
        alert('Access Restricted: Only @gmail.com accounts are permitted.');
        setIsAuthModalOpen(true);
        return;
      }

      // Sync user profile in Firestore
      try {
        const profile = await syncUserProfile(
          user.uid,
          email,
          user.displayName,
          user.photoURL,
          isGuest
        );
        setCurrentUser(profile);

        // If user just upgraded from a guest account to a Gmail account, migrate local data
        if (!isGuest && prevGuestUidRef.current && prevGuestUidRef.current !== user.uid) {
          await migrateGuestDataToUser(
            prevGuestUidRef.current,
            user.uid,
            conversations,
            messages,
            tasks
          );
          prevGuestUidRef.current = null;
        }

        if (isGuest) {
          prevGuestUidRef.current = user.uid;
        }

        // Subscribe to real-time Firestore synchronization
        unsubscribeFirestore = subscribeToUserData(user.uid, {
          onConversations: (cloudConvs) => {
            if (cloudConvs && cloudConvs.length > 0) {
              setConversations((prev) => {
                const map = new Map<string, Conversation>();
                prev.forEach((c) => map.set(c.id, c));
                cloudConvs.forEach((c) => {
                  const existing = map.get(c.id);
                  if (!existing || (c.updatedAt || 0) >= (existing.updatedAt || 0)) {
                    map.set(c.id, c);
                  }
                });
                return Array.from(map.values()).sort((a, b) => b.updatedAt - a.updatedAt);
              });
            }
          },
          onTasks: (cloudTasks) => {
            if (cloudTasks && cloudTasks.length > 0) {
              setTasks((prev) => {
                const map = new Map<string, ProductivityTask>();
                prev.forEach((t) => map.set(t.id, t));
                cloudTasks.forEach((t) => {
                  const existing = map.get(t.id);
                  if (!existing || (t.updatedAt || 0) >= (existing.updatedAt || 0)) {
                    map.set(t.id, t);
                  }
                });
                return Array.from(map.values()).sort((a, b) => b.createdAt - a.createdAt);
              });
            }
          },
          onSettings: (cloudSettings) => {
            if (cloudSettings) {
              setSettings((prev) => ({ ...prev, ...cloudSettings }));
            }
          },
        });
      } catch (err) {
        console.warn('Error setting up user profile / Firestore sync:', err);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeFirestore) {
        unsubscribeFirestore();
      }
    };
  }, []);

  // Guest 10-Minute Trial Countdown Timer
  useEffect(() => {
    if (!currentUser?.isGuest) {
      setIsTrialExpired(false);
      return;
    }

    const expiresAt = currentUser.guestTrialExpiresAt || Date.now() + GUEST_TRIAL_DURATION_MS;

    const interval = setInterval(() => {
      const remaining = expiresAt - Date.now();
      if (remaining <= 0) {
        setGuestTimeRemainingMs(0);
        setIsTrialExpired(true);
        setIsAuthModalOpen(true);
      } else {
        setGuestTimeRemainingMs(remaining);
        setIsTrialExpired(false);
      }
    }, 1000);

    // Initial check
    const diff = expiresAt - Date.now();
    if (diff <= 0) {
      setGuestTimeRemainingMs(0);
      setIsTrialExpired(true);
    } else {
      setGuestTimeRemainingMs(diff);
      setIsTrialExpired(false);
    }

    return () => clearInterval(interval);
  }, [currentUser]);

  // Voice Service listener & Cloud Sync subscriber
  useEffect(() => {
    const vs = voiceServiceRef.current;
    if (vs) {
      vs.setAmplitudeListener((amp) => {
        setAudioAmplitude(amp);
      });
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        const updateVoices = () => {
          setAvailableVoices(vs.getAvailableVoices());
        };
        updateVoices();
        window.speechSynthesis.onvoiceschanged = updateVoices;
      }
    }

    const syncService = cloudSyncRef.current;
    if (syncService) {
      syncService.setSyncKey(settings.cloudSyncKey);
      const unsubscribe = syncService.subscribe((state, lastSynced) => {
        setCloudSyncState(state);
        setLastSyncedAt(lastSynced);
      });

      return () => {
        unsubscribe();
      };
    }
  }, []);

  // Save changes locally to localStorage
  useEffect(() => {
    saveConversations(conversations);
  }, [conversations]);

  useEffect(() => {
    saveMessages(messages);
  }, [messages]);

  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  useEffect(() => {
    saveSettings(settings);
    if (cloudSyncRef.current) {
      cloudSyncRef.current.setSyncKey(settings.cloudSyncKey);
    }
    if (currentUser?.uid) {
      saveSettingsToCloud(currentUser.uid, settings);
    }
  }, [settings]);

  // Trigger debounced cloud auto-sync
  const triggerAutoSync = () => {
    if (cloudSyncRef.current) {
      cloudSyncRef.current.scheduleAutoSync(conversations, messages, tasks, settings);
    }
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSidebarOpen(true);
      }
      if (e.key === 'Escape') {
        setIsDeviceAppsOpen(false);
        setIsSidebarOpen(false);
        if (!isTrialExpired) {
          setIsAuthModalOpen(false);
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isTrialExpired]);

  // Cloud Manual Push
  const handleManualSyncPush = async () => {
    if (!cloudSyncRef.current) return false;
    const ok = await cloudSyncRef.current.push(conversations, messages, tasks, settings);
    if (ok) {
      setSettings((prev) => ({ ...prev, lastSyncedAt: Date.now() }));
    }
    if (currentUser?.uid) {
      saveSettingsToCloud(currentUser.uid, settings);
    }
    return ok;
  };

  // Manual Trigger: Connect to another Sync Key
  const handlePullFromSyncKey = async (targetKey: string) => {
    if (!cloudSyncRef.current) return { success: false, error: 'Sync service not ready' };
    const res = await cloudSyncRef.current.pull(targetKey);
    if (res.success && res.data) {
      setConversations((prev) => {
        const map = new Map<string, Conversation>();
        prev.forEach((c) => map.set(c.id, c));
        res.data?.conversations?.forEach((c) => map.set(c.id, c));
        return Array.from(map.values()).sort((a, b) => b.updatedAt - a.updatedAt);
      });
      setMessages((prev) => {
        const map = new Map<string, ChatMessage>();
        prev.forEach((m) => map.set(m.id, m));
        res.data?.messages?.forEach((m) => map.set(m.id, m));
        return Array.from(map.values()).sort((a, b) => a.timestamp - b.timestamp);
      });
      setTasks((prev) => {
        const map = new Map<string, ProductivityTask>();
        prev.forEach((t) => map.set(t.id, t));
        res.data?.tasks?.forEach((t) => map.set(t.id, t));
        return Array.from(map.values()).sort((a, b) => b.createdAt - a.createdAt);
      });
      setSettings((prev) => ({
        ...prev,
        cloudSyncKey: targetKey.trim().toUpperCase(),
        lastSyncedAt: Date.now(),
      }));
      return { success: true };
    }
    return { success: false, error: res.error };
  };

  // Conversation Actions
  const handleNewConversation = () => {
    const newId = 'conv_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6);
    const newConv: Conversation = {
      id: newId,
      title: 'New Neural Session',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setConversations((prev) => [newConv, ...prev]);
    setActiveConversationId(newId);

    if (currentUser?.uid) {
      saveConversationToCloud(currentUser.uid, newConv);
    }
    triggerAutoSync();
  };

  const handleRenameConversation = (id: string, newTitle: string) => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const updated = { ...c, title: newTitle, updatedAt: Date.now() };
          if (currentUser?.uid) {
            saveConversationToCloud(currentUser.uid, updated);
          }
          return updated;
        }
        return c;
      })
    );
    triggerAutoSync();
  };

  const handleDeleteConversation = (id: string) => {
    setConversations((prev) => {
      const remaining = prev.filter((c) => c.id !== id);
      if (activeConversationId === id) {
        setActiveConversationId(remaining[0]?.id || DEFAULT_CONVERSATION_ID);
      }
      return remaining;
    });
    setMessages((prev) => prev.filter((m) => m.conversationId !== id));

    if (currentUser?.uid) {
      deleteConversationFromCloud(currentUser.uid, id);
    }
    triggerAutoSync();
  };

  // Send Prompt Message to Ultron
  const handleSendMessage = async (promptText: string) => {
    // Check if guest trial has expired
    if (isTrialExpired) {
      setIsAuthModalOpen(true);
      return;
    }

    const text = promptText.trim();
    if (!text) return;

    let convId = activeConversationId;
    const currentConv = conversations.find((c) => c.id === convId);
    if (!currentConv) {
      handleNewConversation();
      convId = activeConversationId;
    }

    if (currentConv && (currentConv.title === 'New Neural Session' || currentConv.title === 'Main Intelligence Feed')) {
      const generatedTitle = text.length > 28 ? text.slice(0, 28) + '...' : text;
      handleRenameConversation(convId, generatedTitle);
    }

    // 1. Add User Message
    const userMsg: ChatMessage = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      conversationId: convId,
      sender: 'USER',
      content: text,
      modelUsed: 'user',
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (currentUser?.uid) {
      saveMessageToCloud(currentUser.uid, userMsg);
    }
    setCoreState('THINKING');

    // 2. Navigation Commands
    const lower = text.toLowerCase();
    if (lower === 'go home' || lower === 'open home') {
      setCoreState('IDLE');
      setActiveScreen('HOME');
      const reply: ChatMessage = {
        id: 'msg_' + Date.now(),
        conversationId: convId,
        sender: 'ULTRON',
        content: 'Returning to Home.',
        modelUsed: 'ultron:system',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, reply]);
      if (currentUser?.uid) saveMessageToCloud(currentUser.uid, reply);
      handleSpeak(reply.content);
      triggerAutoSync();
      return;
    }

    if (lower === 'go to settings' || lower === 'open settings') {
      setCoreState('IDLE');
      setActiveScreen('SETTINGS');
      const reply: ChatMessage = {
        id: 'msg_' + Date.now(),
        conversationId: convId,
        sender: 'ULTRON',
        content: 'Yep. Opening system settings and cloud configuration.',
        modelUsed: 'ultron:system',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, reply]);
      if (currentUser?.uid) saveMessageToCloud(currentUser.uid, reply);
      handleSpeak(reply.content);
      triggerAutoSync();
      return;
    }

    if (lower === 'open tasks' || lower === 'show tasks' || lower === 'open productivity') {
      setCoreState('IDLE');
      setActiveScreen('PRODUCTIVITY');
      const reply: ChatMessage = {
        id: 'msg_' + Date.now(),
        conversationId: convId,
        sender: 'ULTRON',
        content: 'Accessing your productivity and task matrix.',
        modelUsed: 'ultron:system',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, reply]);
      if (currentUser?.uid) saveMessageToCloud(currentUser.uid, reply);
      handleSpeak(reply.content);
      triggerAutoSync();
      return;
    }

    if (lower === 'voice mode' || lower === 'immersive mode') {
      setCoreState('IDLE');
      setActiveScreen('VOICE_MODE');
      return;
    }

    // 3. Send query to Express Backend
    try {
      const history = messages
        .filter((m) => m.conversationId === convId)
        .slice(-6)
        .map((m) => ({ sender: m.sender, content: m.content }));

      const isOfflineMode = settings.operatingMode === 'OFFLINE' || !navigator.onLine;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          conversationHistory: history,
          model: settings.geminiModel,
          thinkingMode: settings.thinkingMode,
          tone: settings.personalityTone,
          isOffline: isOfflineMode,
        }),
      });

      const data = await res.json();

      const ultronReply: ChatMessage = {
        id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        conversationId: convId,
        sender: 'ULTRON',
        content: data.text || data.fallbackText || 'Neural matrix ready.',
        thinkingText: data.thinkingText || null,
        modelUsed: data.modelUsed || settings.geminiModel,
        isOffline: data.isOffline || isOfflineMode,
        actionTriggered: data.actionTriggered || null,
        actionLabel: data.actionLabel || null,
        actionPayload: data.actionPayload || null,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, ultronReply]);
      if (currentUser?.uid) {
        saveMessageToCloud(currentUser.uid, ultronReply);
      }

      if (data.actionTriggered === 'ADD_TASK' && data.actionPayload) {
        handleAddTask(data.actionPayload, 'Task');
      }

      if (settings.autoSpeak) {
        handleSpeak(ultronReply.content);
      } else {
        setCoreState('IDLE');
      }

      triggerAutoSync();
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorReply: ChatMessage = {
        id: 'msg_' + Date.now(),
        conversationId: convId,
        sender: 'ULTRON',
        content:
          "Neural link active. Operating in resilient offline mode as remote sync reported a momentary hiccup.",
        modelUsed: 'offline-fallback',
        isOffline: true,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorReply]);
      if (currentUser?.uid) saveMessageToCloud(currentUser.uid, errorReply);
      setCoreState('IDLE');
    }
  };

  // Voice Interaction Handlers
  const handleStartVoice = async (
    onPartial: (text: string) => void,
    onEnd: (text: string) => void
  ) => {
    if (isTrialExpired) {
      setIsAuthModalOpen(true);
      return false;
    }

    if (settings.agentPermissions?.microphoneAccess === false) {
      return false;
    }

    const vs = voiceServiceRef.current;
    if (!vs) return false;
    setCoreState('LISTENING');
    setIsListening(true);

    const started = await vs.startListening(
      (finalText) => {
        setIsListening(false);
        setCoreState('IDLE');
        onEnd(finalText);
      },
      (partial) => {
        onPartial(partial);
      },
      (error) => {
        setIsListening(false);
        setCoreState('IDLE');
        console.warn('Voice error:', error);
      }
    );

    return started;
  };

  const handleStopVoice = () => {
    const vs = voiceServiceRef.current;
    if (vs) {
      vs.stopListening();
    }
    setIsListening(false);
    if (coreState === 'LISTENING') {
      setCoreState('IDLE');
    }
  };

  const handleSpeak = (text: string) => {
    const vs = voiceServiceRef.current;
    if (!vs) return;

    setCoreState('SPEAKING');
    setIsSpeaking(true);

    vs.speak(text, {
      elevenLabsApiKey: settings.elevenLabsApiKey,
      elevenLabsVoiceId: settings.elevenLabsVoiceId,
      onEnd: () => {
        setIsSpeaking(false);
        setCoreState('IDLE');
      },
    });
  };

  // Task Actions
  const handleAddTask = (title: string, category: ProductivityTask['category'], description?: string) => {
    const newTask: ProductivityTask = {
      id: 'task_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: title.trim(),
      category,
      description: description?.trim() || '',
      isCompleted: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setTasks((prev) => [newTask, ...prev]);
    if (currentUser?.uid) {
      saveTaskToCloud(currentUser.uid, newTask);
    }
    triggerAutoSync();
  };

  const handleToggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const updated = { ...t, isCompleted: !t.isCompleted, updatedAt: Date.now() };
          if (currentUser?.uid) {
            saveTaskToCloud(currentUser.uid, updated);
          }
          return updated;
        }
        return t;
      })
    );
    triggerAutoSync();
  };

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    if (currentUser?.uid) {
      deleteTaskFromCloud(currentUser.uid, id);
    }
    triggerAutoSync();
  };

  const activeMessages = messages.filter((m) => m.conversationId === activeConversationId);
  const latestUltronMessage = activeMessages.filter((m) => m.sender === 'ULTRON').slice(-1)[0] || null;

  return (
    <MotionConfig reducedMotion="user">
      {showLoadingScreen && (
        <LoadingScreen
          onComplete={() => setShowLoadingScreen(false)}
          minDurationMs={5000}
        />
      )}

      <div
        className={`flex flex-col h-screen h-[100dvh] w-full bg-black text-white overflow-hidden relative ${
          settings.reducedBlur ? 'reduced-blur' : ''
        }`}
      >
      {/* 1. Guest 10-Minute Trial Banner */}
      <GuestTrialBanner
        isGuest={!!currentUser?.isGuest}
        timeRemainingMs={guestTimeRemainingMs}
        isExpired={isTrialExpired}
        onOpenAuth={() => setIsAuthModalOpen(true)}
      />

      <div className="flex-1 flex overflow-hidden relative">
        {/* Responsive Collapsible Sidebar */}
        <Sidebar
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          conversations={conversations}
          activeConversationId={activeConversationId}
          activeScreen={activeScreen}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onSelectConversation={setActiveConversationId}
          onNewConversation={handleNewConversation}
          onRenameConversation={handleRenameConversation}
          onDeleteConversation={handleDeleteConversation}
          onNavigateScreen={setActiveScreen}
          onOpenSettings={(sec) => {
            if (sec) setSettingsInitialSection(sec);
            setActiveScreen('SETTINGS');
          }}
          onOpenDeviceApps={() => setIsDeviceAppsOpen(true)}
          cloudSyncState={cloudSyncState}
          lastSyncedAt={lastSyncedAt}
          cloudSyncKey={settings.cloudSyncKey}
          onTriggerSync={handleManualSyncPush}
          currentUser={currentUser}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          appUrl={appUrl}
          onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          hapticEnabled={settings.hapticFeedback}
        />

        {/* Main Content Area with Smooth iOS Screen Transitions */}
        <div className="flex-1 flex flex-col h-full overflow-hidden lg:pl-[300px]">
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            <AnimatePresence mode="wait">
              {activeScreen === 'HOME' && (
                <motion.div
                  key="HOME"
                  variants={screenVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="flex-1 flex flex-col h-full overflow-hidden"
                >
                  <HomeView
                    onOpenSidebar={() => setIsSidebarOpen(true)}
                    coreState={coreState}
                    audioAmplitude={audioAmplitude}
                    isListening={isListening}
                    isSpeaking={isSpeaking}
                    onToggleQuickVoice={() => {
                      if (isListening) {
                        handleStopVoice();
                      } else {
                        handleStartVoice(
                          () => {},
                          (finalText) => {
                            if (finalText.trim()) {
                              setActiveScreen('ASSISTANT');
                              handleSendMessage(finalText);
                            }
                          }
                        );
                      }
                    }}
                    latestUltronMessage={latestUltronMessage}
                    settings={settings}
                    onUpdateSettings={(newVals) => {
                      setSettings((prev) => ({ ...prev, ...newVals }));
                      triggerAutoSync();
                    }}
                    currentUser={currentUser}
                    onOpenAuth={() => setIsAuthModalOpen(true)}
                    onOpenChat={() => setActiveScreen('ASSISTANT')}
                    onOpenVoiceMode={() => setActiveScreen('VOICE_MODE')}
                    onOpenDeviceApps={(appId) => {
                      setActiveDeviceAppId(appId || null);
                      setIsDeviceAppsOpen(true);
                    }}
                    onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
                  />
                </motion.div>
              )}

              {activeScreen === 'ASSISTANT' && (
                <motion.div
                  key="ASSISTANT"
                  variants={screenVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="flex-1 flex flex-col h-full overflow-hidden"
                >
                  <AssistantView
                    onOpenSidebar={() => setIsSidebarOpen(true)}
                    coreState={coreState}
                    audioAmplitude={audioAmplitude}
                    messages={activeMessages}
                    latestUltronMessage={latestUltronMessage}
                    onSendMessage={handleSendMessage}
                    onNewConversation={handleNewConversation}
                    onStartVoice={handleStartVoice}
                    onStopVoice={handleStopVoice}
                    isListening={isListening}
                    isSpeaking={isSpeaking}
                    onSpeakText={handleSpeak}
                    onOpenDeviceApps={(appId) => {
                      setActiveDeviceAppId(appId || null);
                      setIsDeviceAppsOpen(true);
                    }}
                    settings={settings}
                    onUpdateSettings={(newVals) => {
                      setSettings((prev) => ({ ...prev, ...newVals }));
                      triggerAutoSync();
                    }}
                    onOpenAuth={() => setIsAuthModalOpen(true)}
                    isTrialExpired={isTrialExpired}
                    onOpenVoiceMode={() => setActiveScreen('VOICE_MODE')}
                  />
                </motion.div>
              )}

              {activeScreen === 'PRODUCTIVITY' && (
                <motion.div
                  key="PRODUCTIVITY"
                  variants={screenVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="flex-1 flex flex-col h-full overflow-hidden"
                >
                  <ProductivityView
                    tasks={tasks}
                    onToggleTask={handleToggleTask}
                    onDeleteTask={handleDeleteTask}
                    onAddTask={handleAddTask}
                    onAskUltron={(prompt) => {
                      setActiveScreen('ASSISTANT');
                      handleSendMessage(prompt);
                    }}
                    onBack={() => setActiveScreen('HOME')}
                    hapticEnabled={settings.hapticFeedback}
                  />
                </motion.div>
              )}

              {activeScreen === 'VOICE_MODE' && (
                <motion.div
                  key="VOICE_MODE"
                  variants={screenVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="flex-1 flex flex-col h-full overflow-hidden"
                >
                  <VoiceModeView
                    coreState={coreState}
                    audioAmplitude={audioAmplitude}
                    latestUltronMessage={latestUltronMessage}
                    onSendVoiceQuery={handleSendMessage}
                    onStartVoice={handleStartVoice}
                    onStopVoice={handleStopVoice}
                    isListening={isListening}
                    isSpeaking={isSpeaking}
                    onBack={() => setActiveScreen('HOME')}
                    hapticEnabled={settings.hapticFeedback}
                  />
                </motion.div>
              )}

              {activeScreen === 'SETTINGS' && (
                <motion.div
                  key="SETTINGS"
                  variants={screenVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="flex-1 flex flex-col h-full overflow-hidden"
                >
                  <SettingsView
                    settings={settings}
                    onUpdateSettings={(newVals) => {
                      setSettings((prev) => ({ ...prev, ...newVals }));
                      triggerAutoSync();
                    }}
                    cloudSyncState={cloudSyncState}
                    lastSyncedAt={lastSyncedAt}
                    onTriggerSync={handleManualSyncPush}
                    onPullFromSyncKey={handlePullFromSyncKey}
                    onClearHistory={() => {
                      setConversations([
                        {
                          id: DEFAULT_CONVERSATION_ID,
                          title: 'Main Intelligence Feed',
                          createdAt: Date.now(),
                          updatedAt: Date.now(),
                        },
                      ]);
                      setMessages([]);
                      setActiveConversationId(DEFAULT_CONVERSATION_ID);
                      triggerAutoSync();
                    }}
                    onClearTasks={() => {
                      setTasks([]);
                      triggerAutoSync();
                    }}
                    availableVoices={availableVoices}
                    initialSection={settingsInitialSection}
                    currentUser={currentUser}
                    onOpenAuth={() => setIsAuthModalOpen(true)}
                    appUrl={appUrl}
                    isTrialExpired={isTrialExpired}
                    onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
                    onBack={() => setActiveScreen('HOME')}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <FloatingBottomNav
            activeScreen={activeScreen}
            onNavigate={setActiveScreen}
            hapticEnabled={settings.hapticFeedback}
          />
        </div>
      </div>

      {/* Authentication & Guest Trial Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        guestTimeRemainingMs={guestTimeRemainingMs}
        isTrialExpired={isTrialExpired}
        onSignInSuccess={() => {
          setIsAuthModalOpen(false);
          setIsTrialExpired(false);
        }}
      />

      {/* Device Apps Hardware Simulator */}
      <DeviceAppsModal
        isOpen={isDeviceAppsOpen}
        onClose={() => {
          setIsDeviceAppsOpen(false);
          setActiveDeviceAppId(null);
        }}
        activeAppId={activeDeviceAppId}
        onTriggerCommand={(cmd) => {
          handleSendMessage(cmd);
        }}
      />

      {/* App Download Center Modal (Android APK & Windows) */}
      <AppDownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />

      {/* Offline Status Badge */}
      <OfflineIndicator />
    </div>
    </MotionConfig>
  );
}
