import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function crc32(buf) {
  let table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xFF];
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function createChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const typeAndData = Buffer.concat([typeBuf, data]);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(typeAndData), 0);
  return Buffer.concat([len, typeAndData, crcBuf]);
}

function generatePng(size, isMaskable = false) {
  const width = size;
  const height = size;
  const rawData = Buffer.alloc(height * (1 + width * 4));
  const cx = width / 2;
  const cy = height / 2;
  const maxR = width * (isMaskable ? 0.38 : 0.46);

  let offset = 0;
  for (let y = 0; y < height; y++) {
    rawData[offset++] = 0; // Filter byte: None
    for (let x = 0; x < width; x++) {
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Background is solid obsidian black #05070a
      let r = 5, g = 7, b = 10, a = 255;

      // Singularity core
      if (dist < maxR * 0.16) {
        // Bright pure white center
        r = 255; g = 255; b = 255;
      } else if (dist < maxR * 0.4) {
        // Soft white/cyan halo
        const factor = 1 - (dist - maxR * 0.16) / (maxR * 0.24);
        r = Math.round(220 * factor + 5 * (1 - factor));
        g = Math.round(240 * factor + 7 * (1 - factor));
        b = Math.round(255 * factor + 10 * (1 - factor));
      } else {
        // Orbital ring highlights
        const angle = Math.atan2(dy, dx);
        const rot1 = (angle + 0.4);
        const r1 = Math.abs(Math.sin(rot1) * dx - Math.cos(rot1) * dy);
        const rot2 = (angle - 0.4);
        const r2 = Math.abs(Math.sin(rot2) * dx - Math.cos(rot2) * dy);
        
        const onRing1 = Math.abs(dist - maxR * 0.72) < 2.5;
        const onRing2 = Math.abs(dist - maxR * 0.88) < 1.8;
        const onEllipse1 = Math.abs(r1) < 1.8 && dist < maxR * 0.95;
        const onEllipse2 = Math.abs(r2) < 1.8 && dist < maxR * 0.95;

        if (onRing1 || onRing2 || onEllipse1 || onEllipse2) {
          r = 240; g = 250; b = 255;
        }
      }

      rawData[offset++] = r;
      rawData[offset++] = g;
      rawData[offset++] = b;
      rawData[offset++] = a;
    }
  }

  const signature = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // Bit depth
  ihdr[9] = 6; // Color type: RGBA
  ihdr[10] = 0; // Compression
  ihdr[11] = 0; // Filter
  ihdr[12] = 0; // Interlace

  const compressed = zlib.deflateSync(rawData);
  const ihdrChunk = createChunk('IHDR', ihdr);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), generatePng(180));
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), generatePng(192));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), generatePng(512));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), generatePng(512, true));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), generatePng(48));

console.log('Successfully generated iOS, Android, and Web PWA icons in /public.');
